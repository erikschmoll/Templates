# HandHeld Api
Destinada para dar soporte a la aplicación glp.apk y a HandHeld BackOffice Api quien administra la gestión de las bases de datos.

## Tecnologías
|Name|Commnets|
|---|---|---|---|
|Net 6|Framework|
|Serilog|Servicio de log|
|HandFire|Servicio background: Generador de bases SQLite|
|AutoMapper|Servicio de mapeo entre clases|

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# learning about commands (EFC «Code First»)
[Fuente, fixedbuffer](https://www.fixedbuffer.com/entity-framework-core-2/)
[Fuente, code-maze](https://code-maze.com/migrations-and-seed-data-efcore/)

 Una vez tenemos el contexto creado en nuestro proyecto, iremos a la «Consola del Administrador de paquetes», y ahí dispondremos de estos comandos.

### add-migration {nombre} -Context {contexto}
Con este comando, generaremos la migración que lanzaremos a la base de datos. Este comando tiene 2 parámetros
1. {nombre}: Con este parámetro indicaremos el nombre que queremos indicarle a la migración, ademas, es obligatorio.
2. -Context {contexto}: En caso de tener más de un contexto de datos en nuestro programa, indicaremos cual de los contextos es mediante este parámetro. Si solo tenemos un contexto de datos, no es obligatorio usarlo.

### remove-migration
Con este comando, eliminaremos la ultima migración que hemos generado. Se puede utilizar varias veces consecutivamente para ir eliminando migraciones desde la última a la primera.

### update-database {nombre} -Context {contexto}
Con este comando, enviaremos a la base de datos los cambios de la migración, haciéndola efectiva:
1. {nombre}: Con este parámetro indicaremos el nombre de la migración que queremos aplicar.
2. -Context {contexto}: En caso de tener más de un contexto de datos en nuestro programa, indicaremos cual de los contextos es mediante este parámetro. Si solo tenemos un contexto de datos, no es obligatorio usarlo.

### drop-database -Context {contexto}
Con este comando, eliminaremos la base de datos. Este comando tiene 1 parámetro:
1. -Context {contexto}: En caso de tener más de un contexto de datos en nuestro programa, indicaremos cual de los contextos es mediante este parámetro. Si solo tenemos un contexto de datos, no es obligatorio usarlo.

## Generar Scripts por migración
### Script-Migration -From <PreviousMigration> -To <LastMigration>
[Ref](https://stackoverflow.com/questions/39644544/can-i-generate-script-of-a-migration-with-ef-code-first-and-net-core)
