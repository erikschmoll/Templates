﻿

namespace HandHeld.Shared.Abstractions.Models
{
    public class ShowException : Exception
    {
        public static int BAD_REQUEST = 400;
        public ShowException(string message): base(message)
        {
        }
        public ShowException(string message, int statusCode) : base(message)
        {
            StatusCode = statusCode;
        }
        public int? StatusCode { get; set; } = null;
    }
}
