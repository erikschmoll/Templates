﻿namespace HandHeld.Shared.Abstractions
{
    public class Class1
    {

    }
}