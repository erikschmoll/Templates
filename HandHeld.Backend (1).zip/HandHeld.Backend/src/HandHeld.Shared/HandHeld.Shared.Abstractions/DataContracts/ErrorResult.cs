﻿
using System.Text.Json;

namespace HandHeld.Shared.Abstractions.DataContracts
{
    public class ErrorResult
    {
        public string? MensajeError { set; get; }
        public bool ErrorMostrable { set; get; }
        public override string ToString()
        {
            return JsonSerializer.Serialize(this);
        }
    }
}
