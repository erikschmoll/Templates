using HandHeld.Shared.Infrastructure.Middlewares;
using HandHeld.Shared.Infrastructure.Services.Implementations;
using HandHeld.Shared.Infrastructure.Services.Interfaces;
using Microsoft.AspNetCore.Builder;
using HandHeld.Shared.Abstractions.Models;
using HandHeld.Shared.Infrastructure.Jwt.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.Security.Cryptography;

namespace HandHeld.Shared.Infrastructure
{
    public static class InfrastructureModule
    {
        public static IConfiguration? StaticConfig { get; private set; }
        public static IServiceCollection AddInfrastructureModule(this IServiceCollection services, IConfiguration configuration)
        {
            StaticConfig = configuration;

            var jwt = configuration.GetSection("Jwt");
            services.Configure<ConfigJwt>(jwt);
            var appSetings = jwt.Get<ConfigJwt>();

            ////CUSTOM
            var rsaCustom = RSA.Create();
            string key = File.ReadAllText(path: appSetings.CustomAuthServer.PublicKey);
            rsaCustom.ImportFromPem(key);

            //YPF
            var rsaAzure = RSA.Create();
            string keyAzure = File.ReadAllText(path: appSetings.Azure.PublicKey);
            rsaAzure.ImportFromPem(keyAzure);


            services.AddAuthentication().AddJwtBearer("Custom", options =>
            {
                options.RequireHttpsMetadata = false;//En producción debe estar en true para usar https
                options.SaveToken = false;

                options.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context => Task.CompletedTask,
                    OnAuthenticationFailed = context => Task.CompletedTask,
                    OnTokenValidated = context => Task.CompletedTask,
                };

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero,
                    ValidIssuer = appSetings.Azure.Issuer,
                    ValidAudience = appSetings.Azure.Audience,
                    IssuerSigningKey = new RsaSecurityKey(rsaAzure)
                };
            })
            .AddJwtBearer("Azure", options =>
            {
                options.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context => Task.CompletedTask,
                    OnAuthenticationFailed = context => Task.CompletedTask,
                    OnTokenValidated = context => Task.CompletedTask,
                };

                options.RequireHttpsMetadata = false;//En producción debe estar en true para usar https
                options.SaveToken = false;

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero,
                    ValidIssuer = appSetings.CustomAuthServer.Issuer,
                    ValidAudience = appSetings.CustomAuthServer.Audience,
                    IssuerSigningKey = new RsaSecurityKey(rsaCustom)
                };
            });

            services.AddAuthorization(options =>
            {
                options.DefaultPolicy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .AddAuthenticationSchemes("Custom", "Azure")
                    .Build();
                options.AddPolicy("TEST_POLICY", policy => policy.Requirements.Add(new ItemRequierement("https://localhost:8080/api/Token/UsersAuth")));
            });

            services.AddSingleton<IAuthorizationHandler, ClaimHandler>();
            //services.AddTransient<IAuthorizationMiddlewareResultHandler, PolicyResult>();


            services.AddSingleton<ErrorMiddleware>();
            services.AddHttpContextAccessor();
            services.AddSingleton<IIdentityService, IdentityService>();
            

            return services;
        }
        public static IApplicationBuilder UseInfrastructureModule(this IApplicationBuilder app)
        {
            app.UseAuthentication();
            //app.UseAuthorization();
            app.UseMiddleware<ErrorMiddleware>();
            return app;
        }
        public static string GetEnvironment()
        {
            var handheldEnvironment = Environment.GetEnvironmentVariable("HANDHELD_ENVIRONMENT");
            var aspnetcoreEnvironment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            var result = string.Empty;
            if (!string.IsNullOrEmpty(handheldEnvironment)
                && !string.IsNullOrEmpty(aspnetcoreEnvironment)
                && handheldEnvironment.Equals("SOFREDIGITAL")
                && aspnetcoreEnvironment.Equals("Development"))
            {
                //En sofre trabajamos con Development
                result = "Development";
            }
            else if (string.IsNullOrEmpty(handheldEnvironment)
                && !string.IsNullOrEmpty(aspnetcoreEnvironment)
                && aspnetcoreEnvironment.Equals("Development"))
            {
                //En la vdi trabajamos con DevelopmentYPF
                result = "DevelopmentYPF";
            }
            else if (!string.IsNullOrEmpty(aspnetcoreEnvironment))
            {
                //cualquier otro caso
                result = aspnetcoreEnvironment;
            }
            return result;
        }

        
    }
}
