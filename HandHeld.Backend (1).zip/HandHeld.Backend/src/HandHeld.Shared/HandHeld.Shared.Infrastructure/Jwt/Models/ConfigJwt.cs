﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.Shared.Infrastructure.Jwt.Models
{
    public class ConfigJwt
    {
        public CustomAuthServer? CustomAuthServer { get; set;}
        public Azure? Azure { get; set; }
    }

    public class CustomAuthServer
    {
      public string? Issuer { get; set;}
      public string? Audience {get;set;}
      public string? PublicKey {get;set;}
    }

    public class Azure
    {
        public string? Issuer { get; set;}
        public string? Audience { get; set;}
        public string? PublicKey { get; set;}
    }
}
