﻿using HandHeld.Shared.Infrastructure.Services.Interfaces;
using Microsoft.AspNetCore.Http;

namespace HandHeld.Shared.Infrastructure.Services.Implementations
{
    public class IdentityService : IIdentityService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public IdentityService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        public string UserName()
        {
            var context = _httpContextAccessor.HttpContext;
            if (context is null
            || context.User is null
            || context.User.Identity is null
            || context.User.Identity.Name is null)
            {
                //Sacar cuando el Auth ya esté activo en el ambiente
                return "UserTest";
                throw new Exception("Identity.Name no puede ser nulo");
            }
            return context.User.Identity.Name;
        }
    }
}
