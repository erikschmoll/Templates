﻿
namespace HandHeld.Shared.Infrastructure.Services.Interfaces
{
    public interface IIdentityService
    {
        string UserName();
    }
}
