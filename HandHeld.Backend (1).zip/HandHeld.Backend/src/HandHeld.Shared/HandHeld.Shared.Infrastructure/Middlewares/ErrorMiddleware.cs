﻿using HandHeld.Shared.Abstractions.DataContracts;
using HandHeld.Shared.Abstractions.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Net;

namespace HandHeld.Shared.Infrastructure.Middlewares
{

    public class ErrorMiddleware : IMiddleware
    {
        private readonly ILogger<ErrorMiddleware> _logger;
        public ErrorMiddleware( ILogger<ErrorMiddleware> logger)
        {
            _logger = logger;
        }
        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            try
            {
                await next(context);
            }
            catch(ShowException sex)
            {
                await handleError(context, sex, true, sex.StatusCode);
            }
            catch (Exception ex)
            {
                await handleError(context, ex);
            }
        }

        #region private
        private async Task handleError(HttpContext context, 
            Exception ex, 
            bool showError = false,
            int? statusCode = null)
        {
            string mensaje = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            _logger.LogCritical(exception: ex, message: mensaje);
            context.Response.StatusCode = (statusCode is null) ? 
                (int)HttpStatusCode.InternalServerError : (int)statusCode;
            context.Response.ContentType = "application/json";
            string response = new ErrorResult()
            {
                ErrorMostrable = showError,
                MensajeError = mensaje
            }.ToString();
            await context.Response.WriteAsync(response);
        }
        #endregion

    }
}