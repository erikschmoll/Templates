﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.Shared.Infrastructure.Middlewares
{
    public class ItemRequierement : IAuthorizationRequirement
    {
        public string Items { get; set; }

        public ItemRequierement(string items)
        {
            Items = items;
        }
    }

    public class ClaimHandler : AuthorizationHandler<ItemRequierement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ItemRequierement requirement)
        {
            var claim = context.User.Claims.Where(c => c.Type.Equals("iis")).FirstOrDefault();
            if (claim!=null && claim.Value == requirement.Items)
            {
                context.Succeed(requirement);
                return Task.CompletedTask;
            }
            else
            {
                context.Fail(); 
                return Task.CompletedTask;
            }
        }
    }
}
