﻿using HandHeld.PDAManagement.Business.Layer;
using HandHeld.PDAManagement.Business.Layer.Services.Implementations;
using HandHeld.PDAManagement.Business.Layer.Services.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace HandHeld.PDAManagement.Presentation.Layer
{
    public static class PDAManagementModule
    {
        public static IServiceCollection AddPDAManagementModule(this IServiceCollection services, IConfiguration configuration)
        {
            #region Services
            services.AddScoped<IInicializadorService, InicializadorService>();
            #endregion
            services.AddBusinessModule(configuration);
            return services;
        }
        public static IApplicationBuilder UsePDAManagementModule(this IApplicationBuilder app, IConfiguration configuration)
        {
            app.UseBusinessModule(configuration);
            return app;
        }
    }
}
