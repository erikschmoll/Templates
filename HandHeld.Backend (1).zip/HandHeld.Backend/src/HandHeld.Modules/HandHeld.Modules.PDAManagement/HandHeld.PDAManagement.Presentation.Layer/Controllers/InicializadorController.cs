﻿using HandHeld.PDAManagement.Business.Layer.Services.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Request;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.YPFGas;
using HandHeld.PDAManagement.Presentation.Layer.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using Dapper;
using System.Reflection;
using System.ComponentModel;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.YPFGas;
using Microsoft.Extensions.Configuration;
using HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.SqlServerConnection.Implementations;
using HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Implementations;

namespace HandHeld.PDAManagement.Presentation.Layer.Controllers
{
    /*
    TODO: Johan: como el backoffice aun no tiene autheticacion
    no puedo llegar a integrar estos endpints por ello comente
    la annotation del auth
    */
    //[Authorize(AuthenticationSchemes = "Azure,Custom")]
    public class InicializadorController : BaseController
    {
        private readonly IConfiguration _configuration;
        private readonly IInicializadorService _inicializadorService;
        private readonly ILogger<InicializadorController> _logger;
        private static string MIMETYPE = "application/x-sqlite3"; //https://mimetype.io/application/vnd.sqlite3
        private static string NAMEDB = "glp.db";

        public InicializadorController(IInicializadorService inicializadorService, ILogger<InicializadorController> logger, IConfiguration config)
        {
            _inicializadorService = inicializadorService;
            _logger = logger;
            _configuration = config;
        }
        [HttpGet("Descarga")]
        public async Task<ActionResult> Descarga(int nroActualizacion, long version = 0)
        {
            byte[] data;
            var dispositivo = HttpContext.Connection.RemoteIpAddress?.ToString();
            var info = $"id: {HttpContext.Connection.Id}, local: {HttpContext.Connection.LocalIpAddress?.ToString()}"
                + $"remote: {HttpContext.Connection.RemoteIpAddress?.ToString()}";
            _logger.LogInformation(info);
            data = await _inicializadorService.Descargar(nroActualizacion, version, dispositivo);
            return File(data, MIMETYPE, NAMEDB);
        }

        [HttpGet("actualizaciones")]
        public async Task<ActionResult> BuscarActualizacionesConFiltros([FromQuery]
            string? filtros = null,
            int limite = 10,
            int pagina = 1,
            string? ordenadoPor = null,
            string? tipoDeOrden = "asc"
            )
        {
            if (pagina == 0)
                pagina = 1;

            var filters = (filtros is null) ? null : JsonConvert.DeserializeObject<FiltrosBuscarActualizaciones>(filtros);
            return Ok(await _inicializadorService.BuscarActualizacionesPorFiltrosAsync(filters, limite, pagina, ordenadoPor, tipoDeOrden));
        }

        [HttpGet("actualizaciones/{id}")]
        public async Task<ActionResult> BuscarActualizacionesById(string id)
        {
            if (id == string.Empty)
                return BadRequest();

            return Ok(await _inicializadorService.BuscarActualizacionPorIdAsync(id));
        }

        [HttpPost("actualizaciones")]
        public async Task<ActionResult> AltaActualizaciones([FromBody] AltaActualizaciones model)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            if (model == null)
                return BadRequest("No hay body en el request");

            return Ok(await _inicializadorService.AltaActualizacionesAsync(model));
        }

        [HttpDelete("actualizaciones/{id}")]
        public async Task<ActionResult> BajaActualizaciones(string id)
        {
            if (id == string.Empty)
                return BadRequest();

            return Ok(await _inicializadorService.BajaActualizacionAsync(id));
        }

        [HttpPut("actualizaciones/{id}")]
        public async Task<ActionResult> ModificarActualizacionesAsync(string id, [FromBody] ModificarActualizaciones? model)
        {
            if (id == string.Empty)
                return BadRequest("El id es requerido");

            if (model == null)
                return BadRequest("No hay body en el request");

            return Ok(await _inicializadorService.ModificarActualizacionAsync(id, model));
        }

        [HttpPost("actualizaciones/{id}/nroActualizacion")]
        public async Task<ActionResult> BlanqueoNroActualizacionAsync(string id)
        {
            if (id == string.Empty)
                return BadRequest();

            return Ok(await _inicializadorService.BlanqueoNroActualizacion(id));
        }

        [HttpGet("actualizaciones/usuarios/autocompletado")]
        public async Task<ActionResult> BuscarUsuariosAutocompletado([FromQuery] string? patron)
        {
            return Ok(await _inicializadorService.BuscarUsuarios(patron));
        }

        [HttpGet("patentes/autocompletado")]
        public async Task<ActionResult> BuscarPatentes([FromQuery] string? patron)
        {
            return Ok(await _inicializadorService.BuscarPatentes(patron));
        }

        [HttpGet("plantas")]
        public async Task<ActionResult> BuscarPlantas()
        {
            return Ok(await _inicializadorService.BuscarPlantas());
        }

        [HttpGet("estados")]
        public async Task<ActionResult> BuscarEstados()
        {
            return Ok(await _inicializadorService.BuscarEstados());
        } 
        
        //[HttpGet("test")]
        //public async Task<ActionResult> Testing()
        //{
        //    var dict = new UnitOfWorkDapper(new DbSqlConnection(_configuration));
        //    var re = await dict._boca.GetDataByIdPlanta(31);
        //    dict.Dispose();
        //    return Ok(re);
        //}
    }
}

