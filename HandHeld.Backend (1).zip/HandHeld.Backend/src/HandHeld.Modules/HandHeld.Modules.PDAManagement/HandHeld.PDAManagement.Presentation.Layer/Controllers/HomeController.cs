﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HandHeld.PDAManagement.Presentation.Layer.Controllers
{
    [Route(BasePath)]
    public class HomeController : BaseController
    {
        //[Authorize(AuthenticationSchemes = "Azure,Custom", Policy = "TEST_POLICY")]
        [HttpGet]
        public ActionResult<string> Get() => "Modulo Gestión de PDA's";
    }
}
