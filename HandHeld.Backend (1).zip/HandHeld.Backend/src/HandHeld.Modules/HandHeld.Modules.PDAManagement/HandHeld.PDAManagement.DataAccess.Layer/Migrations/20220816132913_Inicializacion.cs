﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HandHeld.PDAManagement.DataAccess.Layer.Migrations
{
    public partial class Inicializacion : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "Modulo_Inicializacion");

            migrationBuilder.EnsureSchema(
                name: "Modulo_Compartido");

            migrationBuilder.CreateTable(
                name: "Configuraciones",
                schema: "Modulo_Compartido",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Valor = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Descripcion = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                    CreadoPor = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ModificadoPor = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    FechaCreacion = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    FechaModificacion = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    Del = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Configuraciones", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EstadosActualizaciones",
                schema: "Modulo_Inicializacion",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Nombre = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CreadoPor = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ModificadoPor = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    FechaCreacion = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    FechaModificacion = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    Del = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EstadosActualizaciones", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Actualizaciones",
                schema: "Modulo_Inicializacion",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Planta = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Patente = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Chofer = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    IdEstado = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Url = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: true),
                    Version = table.Column<long>(type: "bigint", nullable: true),
                    NroActualizacion = table.Column<int>(type: "int", maxLength: 6, nullable: true),
                    CreadoPor = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ModificadoPor = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    FechaCreacion = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    FechaModificacion = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    Del = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Actualizaciones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Actualizaciones_EstadosActualizaciones_IdEstado",
                        column: x => x.IdEstado,
                        principalSchema: "Modulo_Inicializacion",
                        principalTable: "EstadosActualizaciones",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Instalaciones",
                schema: "Modulo_Inicializacion",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    IdActualizacion = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    NroActualizacionUsado = table.Column<int>(type: "int", nullable: false),
                    Chofer = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Dispositivo = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CreadoPor = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ModificadoPor = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    FechaCreacion = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    FechaModificacion = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    Del = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Instalaciones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_INSTALACION_ACTUALIZACION",
                        column: x => x.IdActualizacion,
                        principalSchema: "Modulo_Inicializacion",
                        principalTable: "Actualizaciones",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                schema: "Modulo_Compartido",
                table: "Configuraciones",
                columns: new[] { "Id", "CreadoPor", "Del", "Descripcion", "FechaCreacion", "FechaModificacion", "ModificadoPor", "Valor" },
                values: new object[,]
                {
                    { "cape", "Admin", false, "Cantidad de Actualizaciones a Procesar por Ejecución", new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)), "Admin", "5" },
                    { "cpina", "Admin", false, "Cantidad Permitida de Instalaciones por Número de Actualización", new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)), "Admin", "1" },
                    { "vr", "Admin", false, "Versión del Release", new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)), "Admin", "1" }
                });

            migrationBuilder.InsertData(
                schema: "Modulo_Inicializacion",
                table: "EstadosActualizaciones",
                columns: new[] { "Id", "CreadoPor", "Del", "FechaCreacion", "FechaModificacion", "ModificadoPor", "Nombre" },
                values: new object[,]
                {
                    { "1", "Admin", false, new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), "Admin", "Pendiente" },
                    { "2", "Admin", false, new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), "Admin", "Procesando..." },
                    { "3", "Admin", false, new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), "Admin", "Listo para sincronizar" },
                    { "4", "Admin", false, new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), "Admin", "Error" },
                    { "5", "Admin", false, new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), "Admin", "Obsoleto" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Actualizaciones_IdEstado",
                schema: "Modulo_Inicializacion",
                table: "Actualizaciones",
                column: "IdEstado");

            migrationBuilder.CreateIndex(
                name: "IX_Instalaciones_IdActualizacion",
                schema: "Modulo_Inicializacion",
                table: "Instalaciones",
                column: "IdActualizacion");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Configuraciones",
                schema: "Modulo_Compartido");

            migrationBuilder.DropTable(
                name: "Instalaciones",
                schema: "Modulo_Inicializacion");

            migrationBuilder.DropTable(
                name: "Actualizaciones",
                schema: "Modulo_Inicializacion");

            migrationBuilder.DropTable(
                name: "EstadosActualizaciones",
                schema: "Modulo_Inicializacion");
        }
    }
}
