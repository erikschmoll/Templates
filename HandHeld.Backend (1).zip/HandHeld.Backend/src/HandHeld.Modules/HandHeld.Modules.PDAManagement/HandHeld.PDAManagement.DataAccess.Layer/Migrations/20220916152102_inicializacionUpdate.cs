﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HandHeld.PDAManagement.DataAccess.Layer.Migrations
{
    public partial class inicializacionUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Planta",
                schema: "Modulo_Inicializacion",
                table: "Actualizaciones",
                newName: "IdPlanta");

            migrationBuilder.RenameColumn(
                name: "Patente",
                schema: "Modulo_Inicializacion",
                table: "Actualizaciones",
                newName: "IdPatente");

            migrationBuilder.RenameColumn(
                name: "Chofer",
                schema: "Modulo_Inicializacion",
                table: "Actualizaciones",
                newName: "IdChofer");

            migrationBuilder.UpdateData(
                schema: "Modulo_Compartido",
                table: "Configuraciones",
                keyColumn: "Id",
                keyValue: "cape",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 764, DateTimeKind.Unspecified).AddTicks(4096), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 764, DateTimeKind.Unspecified).AddTicks(4096), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Compartido",
                table: "Configuraciones",
                keyColumn: "Id",
                keyValue: "cpina",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 764, DateTimeKind.Unspecified).AddTicks(4096), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 764, DateTimeKind.Unspecified).AddTicks(4096), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Compartido",
                table: "Configuraciones",
                keyColumn: "Id",
                keyValue: "vr",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 764, DateTimeKind.Unspecified).AddTicks(4096), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 764, DateTimeKind.Unspecified).AddTicks(4096), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Inicializacion",
                table: "EstadosActualizaciones",
                keyColumn: "Id",
                keyValue: "1",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 763, DateTimeKind.Unspecified).AddTicks(1026), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 763, DateTimeKind.Unspecified).AddTicks(1026), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Inicializacion",
                table: "EstadosActualizaciones",
                keyColumn: "Id",
                keyValue: "2",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 763, DateTimeKind.Unspecified).AddTicks(1026), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 763, DateTimeKind.Unspecified).AddTicks(1026), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Inicializacion",
                table: "EstadosActualizaciones",
                keyColumn: "Id",
                keyValue: "3",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 763, DateTimeKind.Unspecified).AddTicks(1026), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 763, DateTimeKind.Unspecified).AddTicks(1026), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Inicializacion",
                table: "EstadosActualizaciones",
                keyColumn: "Id",
                keyValue: "4",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 763, DateTimeKind.Unspecified).AddTicks(1026), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 763, DateTimeKind.Unspecified).AddTicks(1026), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Inicializacion",
                table: "EstadosActualizaciones",
                keyColumn: "Id",
                keyValue: "5",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 763, DateTimeKind.Unspecified).AddTicks(1026), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 9, 16, 15, 21, 1, 763, DateTimeKind.Unspecified).AddTicks(1026), new TimeSpan(0, 0, 0, 0, 0)) });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "IdPlanta",
                schema: "Modulo_Inicializacion",
                table: "Actualizaciones",
                newName: "Planta");

            migrationBuilder.RenameColumn(
                name: "IdPatente",
                schema: "Modulo_Inicializacion",
                table: "Actualizaciones",
                newName: "Patente");

            migrationBuilder.RenameColumn(
                name: "IdChofer",
                schema: "Modulo_Inicializacion",
                table: "Actualizaciones",
                newName: "Chofer");

            migrationBuilder.UpdateData(
                schema: "Modulo_Compartido",
                table: "Configuraciones",
                keyColumn: "Id",
                keyValue: "cape",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Compartido",
                table: "Configuraciones",
                keyColumn: "Id",
                keyValue: "cpina",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Compartido",
                table: "Configuraciones",
                keyColumn: "Id",
                keyValue: "vr",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 145, DateTimeKind.Unspecified).AddTicks(4928), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Inicializacion",
                table: "EstadosActualizaciones",
                keyColumn: "Id",
                keyValue: "1",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Inicializacion",
                table: "EstadosActualizaciones",
                keyColumn: "Id",
                keyValue: "2",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Inicializacion",
                table: "EstadosActualizaciones",
                keyColumn: "Id",
                keyValue: "3",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Inicializacion",
                table: "EstadosActualizaciones",
                keyColumn: "Id",
                keyValue: "4",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)) });

            migrationBuilder.UpdateData(
                schema: "Modulo_Inicializacion",
                table: "EstadosActualizaciones",
                keyColumn: "Id",
                keyValue: "5",
                columns: new[] { "FechaCreacion", "FechaModificacion" },
                values: new object[] { new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)), new DateTimeOffset(new DateTime(2022, 8, 16, 13, 29, 13, 144, DateTimeKind.Unspecified).AddTicks(5290), new TimeSpan(0, 0, 0, 0, 0)) });
        }
    }
}
