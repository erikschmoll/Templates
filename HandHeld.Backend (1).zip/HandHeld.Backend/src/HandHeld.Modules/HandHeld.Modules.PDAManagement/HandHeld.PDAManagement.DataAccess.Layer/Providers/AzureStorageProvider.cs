﻿using HandHeld.PDAManagement.DataAccess.Layer.Options;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.WebServices;
using Microsoft.Extensions.Options;

namespace HandHeld.PDAManagement.DataAccess.Layer.Providers
{
    public class AzureStorageProvider : IStorageService
    {
        private readonly StoragesOptions _storagesOptions;
        public AzureStorageProvider(IOptions<StoragesOptions> sharedOptions)
        {
            _storagesOptions = sharedOptions.Value;
        }
        public Task<byte[]> GetStorageAsync(string url)
        {
            throw new NotImplementedException();
        }

        public Task<string> PushToStorageAsync(string path, string fileName)
        {
            throw new NotImplementedException();
        }
    }
}
