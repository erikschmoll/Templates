﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockCategoriaSegunFiscoConfiguration : IEntityTypeConfiguration<CategoriaSegunFisco>
    {
        public void Configure(EntityTypeBuilder<CategoriaSegunFisco> builder)
        {
            builder.ToTable("CategoriaSegunFisco");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idCategoriaSegunFisco");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("categoriaSegunFisco");
            builder.Property(x => x.IdAFIP).HasMaxLength(50);
            builder.Property(x => x.TipoFactura).HasMaxLength(50);
        }
    }
}
