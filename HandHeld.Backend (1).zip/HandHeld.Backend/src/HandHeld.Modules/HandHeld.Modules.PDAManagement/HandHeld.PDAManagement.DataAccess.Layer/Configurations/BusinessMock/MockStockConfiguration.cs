﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockStockConfiguration : IEntityTypeConfiguration<Stock>
    {
        public void Configure(EntityTypeBuilder<Stock> builder)
        {
            builder.ToTable("Stock");
            builder.HasKey(x => new
            {
                x.IdArticulo,
                x.IdEstadoArticulo,
                x.IdViaje
            });
            builder.Property(x => x.IdArticulo).HasMaxLength(50);
            builder.Property(x => x.IdEstadoArticulo).HasMaxLength(50);
            builder.Property(x => x.IdUnidadCantidad).HasMaxLength(50);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.Cantidad).HasPrecision(13,4);
            /*builder.HasOne(x => x.Articulo).WithMany().HasForeignKey(x => x.IdArticulo);
            builder.HasOne(x => x.EstadoArticulo).WithMany().HasForeignKey(x => x.IdEstadoArticulo);
            builder.HasOne(x => x.UnidadCantidad).WithMany().HasForeignKey(x => x.IdUnidadCantidad);
            builder.HasOne(x => x.Viaje).WithMany().HasForeignKey(x => x.IdViaje);*/
            builder.Ignore(x => x.Articulo);
            builder.Ignore(x => x.EstadoArticulo);
            builder.Ignore(x => x.UnidadCantidad);
            builder.Ignore(x => x.Viaje);
        }
    }
}
