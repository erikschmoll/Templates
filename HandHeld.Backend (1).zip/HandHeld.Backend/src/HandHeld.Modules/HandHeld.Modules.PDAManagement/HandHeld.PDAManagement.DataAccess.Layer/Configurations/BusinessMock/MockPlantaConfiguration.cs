﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockPlantaConfiguration : IEntityTypeConfiguration<Planta>
    {
        public void Configure(EntityTypeBuilder<Planta> builder)
        {
            builder.ToTable("Planta");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idPlanta");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("planta");
            builder.Property(x => x.Direccion).HasMaxLength(50);
            builder.Property(x => x.CodigoPostal).HasMaxLength(50);
            builder.Property(x => x.Poblacion).HasMaxLength(50);
            builder.Property(x => x.Telefono).HasMaxLength(50);
            builder.Property(x => x.RazonSocialEmpresa).HasMaxLength(50);
            builder.Property(x => x.RazonSocialSucursal).HasMaxLength(50);
            builder.Property(x => x.IdentificadorFiscal).HasMaxLength(50);
            builder.Property(x => x.NumeroIngresosBrutos).HasMaxLength(50);
            builder.Property(x => x.NumeroDeAgentePercepcion).HasMaxLength(50);
            builder.Property(x => x.SedeTimbrado).HasMaxLength(50);
            builder.Property(x => x.CodigoRegionGeografica).HasMaxLength(50);
            builder.Property(x => x.TipoRegionGeografica).HasMaxLength(50);
            builder.Property(x => x.IdPais).HasMaxLength(50);
            builder.Property(x => x.TasaSegundoVencimiento).HasPrecision(13, 4);
            builder.Property(x => x.IvaFinanciero).HasPrecision(13, 4);
            //builder.HasOne(x => x.Pais).WithMany().HasForeignKey(x => x.IdPais);
            builder.Ignore(x => x.Pais);
        }
    }
}
