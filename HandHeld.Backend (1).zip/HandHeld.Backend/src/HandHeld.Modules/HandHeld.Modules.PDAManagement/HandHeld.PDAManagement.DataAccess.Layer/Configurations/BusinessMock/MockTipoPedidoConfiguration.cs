﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockTipoPedidoConfiguration : IEntityTypeConfiguration<TipoPedido>
    {
        public void Configure(EntityTypeBuilder<TipoPedido> builder)
        {
            builder.ToTable("TipoPedido");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idTipoPedido");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("tipoPedido");
        }
    }
}
