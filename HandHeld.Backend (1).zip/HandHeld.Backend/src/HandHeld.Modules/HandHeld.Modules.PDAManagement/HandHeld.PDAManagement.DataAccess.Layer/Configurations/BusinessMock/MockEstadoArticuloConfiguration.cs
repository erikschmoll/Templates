﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockEstadoArticuloConfiguration : IEntityTypeConfiguration<EstadoArticulo>
    {
        public void Configure(EntityTypeBuilder<EstadoArticulo> builder)
        {
            builder.ToTable("EstadoArticulo");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idEstadoArticulo");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("estadoArticulo");
        }
    }
}
