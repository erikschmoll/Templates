﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockGeoPosicionConfiguration : IEntityTypeConfiguration<GeoPosicion>
    {
        public void Configure(EntityTypeBuilder<GeoPosicion> builder)
        {
            builder.ToTable("GeoPosicion");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasColumnName("idGeoPosicion");
            builder.Property(x => x.Latitud).HasPrecision(13, 4);
            builder.Property(x => x.Longitud).HasPrecision(13, 4);
        }
    }
}
