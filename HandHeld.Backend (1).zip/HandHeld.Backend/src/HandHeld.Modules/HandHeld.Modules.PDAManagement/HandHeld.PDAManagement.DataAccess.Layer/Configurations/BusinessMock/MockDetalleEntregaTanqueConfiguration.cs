﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockDetalleEntregaTanqueConfiguration : IEntityTypeConfiguration<DetalleEntregaTanque>
    {
        public void Configure(EntityTypeBuilder<DetalleEntregaTanque> builder)
        {
            builder.ToTable("DetalleEntregaTanque");
            builder.HasKey(x => new
            {
                x.IdViaje,
                x.IdEntrega,
                x.IdArticulo,
                x.IdMotivoEntrega,
                x.IdBoca,
                x.IdTanque
            });
            builder.Property(x => x.PrecintoNuevo).HasMaxLength(50);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.IdArticulo).HasMaxLength(50);
            builder.Property(x => x.IdMotivoEntrega).HasMaxLength(50);
            builder.Property(x => x.IdBoca).HasMaxLength(50);
            builder.Property(x => x.IdTanque).HasMaxLength(50);
            builder.Property(x => x.PorcentajeFinal).HasPrecision(13,4);
            /*builder.HasOne(x => x.Tanque).WithMany().HasForeignKey(x => new
            {
                x.IdBoca,
                x.IdTanque
            });
            builder.HasOne(x => x.DetalleEntrega).WithMany().HasForeignKey(x => new
            {
                x.IdViaje,
                x.IdEntrega,
                x.IdArticulo,
                x.IdMotivoEntrega
            });*/
            builder.Ignore(x => x.Tanque);
            builder.Ignore(x => x.DetalleEntrega);
        }
    }
}
