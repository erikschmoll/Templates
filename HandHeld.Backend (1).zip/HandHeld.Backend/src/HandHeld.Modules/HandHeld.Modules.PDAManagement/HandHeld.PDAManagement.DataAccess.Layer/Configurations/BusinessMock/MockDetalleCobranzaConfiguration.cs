﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockDetalleCobranzaConfiguration : IEntityTypeConfiguration<DetalleCobranza>
    {
        public void Configure(EntityTypeBuilder<DetalleCobranza> builder)
        {
            builder.ToTable("DetalleCobranza");
            builder.HasKey(x => new
            {
                x.IdViaje,
                x.IdCobranza,
                x.IdDocumentoGenerado
            });
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            /*builder.HasOne(x => x.Documento).WithMany().HasForeignKey(x => new
            {
                x.IdDocumentoGenerado,
                x.IdViaje
            });
            builder.HasOne(x => x.Cobranza).WithMany().HasForeignKey(x => new
            {
                x.IdCobranza,
                x.IdViaje
            });*/
            builder.Ignore(x => x.Documento);
            builder.Ignore(x => x.Cobranza);
        }
    }
}
