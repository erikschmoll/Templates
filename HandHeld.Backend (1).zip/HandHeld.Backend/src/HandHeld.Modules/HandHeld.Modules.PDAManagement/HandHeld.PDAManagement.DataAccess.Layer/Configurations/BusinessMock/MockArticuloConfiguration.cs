﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockArticuloConfiguration : IEntityTypeConfiguration<Articulo>
    {
        public void Configure(EntityTypeBuilder<Articulo> builder)
        {
            builder.ToTable("Articulo");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idArticulo");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("articulo");
            builder.Property(x => x.IdUnidadPreferidaCompra).HasMaxLength(50);
            builder.Property(x => x.IdUnidadPreferidaVenta).HasMaxLength(50);
            builder.Property(x => x.IdUnidadPreferidaStock).HasMaxLength(50);
            builder.Property(x => x.TipoArticulo).HasMaxLength(50);
            builder.Property(x => x.DensidadOficial).HasPrecision(13,4);
            //builder.HasOne(x => x.UnidadPreferidaCompra).WithMany().HasForeignKey(x => x.IdUnidadPreferidaCompra);
            //builder.HasOne(x => x.UnidadPreferidaVenta).WithMany().HasForeignKey(x => x.IdUnidadPreferidaVenta);
            //builder.HasOne(x => x.UnidadPreferidaStock).WithMany().HasForeignKey(x => x.IdUnidadPreferidaStock);
            builder.Ignore(x => x.UnidadPreferidaCompra);
            builder.Ignore(x => x.UnidadPreferidaVenta);
            builder.Ignore(x => x.UnidadPreferidaStock);
        }
    }
}
