﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockNumeradorConfiguration : IEntityTypeConfiguration<Numerador>
    {
        public void Configure(EntityTypeBuilder<Numerador> builder)
        {
            builder.ToTable("Numerador");
            builder.HasKey(x => new { x.IdTipoDocumento, x.IdViaje });
            builder.Property(x => x.Serie).HasMaxLength(50);
            builder.Property(x => x.IdTipoDocumento).HasMaxLength(50);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.TipoNumerador).HasMaxLength(50);
            builder.Property(x => x.NumeroCAI).HasMaxLength(50);
            builder.Property(x => x.NumeroDesde).HasPrecision(13, 0);
            builder.Property(x => x.NumeroHasta).HasPrecision(13, 0);
            //builder.HasOne(x => x.Viaje).WithMany().HasForeignKey(x => x.IdViaje);
            //builder.HasOne(x => x.TipoDocumento).WithMany().HasForeignKey(x => x.IdTipoDocumento);
            builder.Ignore(x => x.Viaje);
            builder.Ignore(x => x.TipoDocumento);
        }
    }
}
