﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockProntoPagoConfiguration : IEntityTypeConfiguration<ProntoPago>
    {
        public void Configure(EntityTypeBuilder<ProntoPago> builder)
        {
            builder.ToTable("ProntoPago");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idProntoPago");
            builder.Property(x => x.PorcentajeDescuento).HasPrecision(13, 4);
        }
    }
}
