﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockCobranzaConfiguration : IEntityTypeConfiguration<Cobranza>
    {
        public void Configure(EntityTypeBuilder<Cobranza> builder)
        {
            builder.ToTable("Cobranza");
            builder.HasKey(x => new
            {
                x.Id,
                x.IdViaje
            });
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idCobranza");
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.IdBoca).HasMaxLength(50);
            //builder.HasOne(x => x.Viaje).WithMany().HasForeignKey(x => x.IdViaje);
            //builder.HasOne(x => x.Boca).WithMany().HasForeignKey(x => x.IdBoca);
            builder.Ignore(x => x.Viaje);
            builder.Ignore(x => x.Boca);
        }
    }
}
