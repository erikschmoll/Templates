﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockSucursalConfiguration : IEntityTypeConfiguration<Sucursal>
    {
        public void Configure(EntityTypeBuilder<Sucursal> builder)
        {
            builder.ToTable("Sucursal");
            builder.HasKey(x => new
            {
                x.Id,
                x.IdBanco
            });
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idSucursal");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("sucursal");
            builder.Property(x => x.IdBanco).HasMaxLength(50);
            //builder.HasOne(x => x.Banco).WithMany().HasForeignKey(x => x.IdBanco);
            builder.Ignore(x => x.Banco);
        }
    }
}
