﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockTraduccionConfiguration : IEntityTypeConfiguration<Traduccion>
    {
        public void Configure(EntityTypeBuilder<Traduccion> builder)
        {
            builder.ToTable("Traduccion");
            builder.HasKey(x => new { x.IdElemento, x.IdPantalla });
            builder.Property(x => x.IdElemento).HasMaxLength(50);
            builder.Property(x => x.ValorTraduccion).HasMaxLength(50).HasColumnName("traduccion");
            builder.Property(x => x.IdPantalla).HasMaxLength(50);
            //builder.HasOne(x => x.Pantalla).WithMany().HasForeignKey(x => x.IdPantalla);
            builder.Ignore(x => x.Pantalla);
        }
    }
}
