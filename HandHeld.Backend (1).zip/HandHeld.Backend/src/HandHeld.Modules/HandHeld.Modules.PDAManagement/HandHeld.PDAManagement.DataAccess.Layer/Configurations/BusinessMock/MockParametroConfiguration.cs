﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockParametroConfiguration : IEntityTypeConfiguration<Parametro>
    {
        public void Configure(EntityTypeBuilder<Parametro> builder)
        {
            builder.ToTable("Parametro");
            builder.HasKey(x => new
            {
                x.IdPais,
                x.IdNegocio,
                x.IdProceso,
                x.IdPantalla,
                x.IdParametro
            });
            builder.Property(x => x.IdPais).HasMaxLength(50);
            builder.Property(x => x.IdNegocio).HasMaxLength(50);
            builder.Property(x => x.IdProceso).HasMaxLength(50);
            builder.Property(x => x.IdPantalla).HasMaxLength(50);
            builder.Property(x => x.IdParametro).HasMaxLength(50);
            builder.Property(x => x.Valor).HasMaxLength(500);
            /*builder.HasOne(x => x.Negocio).WithMany().HasForeignKey(x => x.IdNegocio);
            builder.HasOne(x => x.Proceso).WithMany().HasForeignKey(x => x.IdProceso);
            builder.HasOne(x => x.Pantalla).WithMany().HasForeignKey(x => x.IdPantalla);
            builder.HasOne(x => x.Pais).WithMany().HasForeignKey(x => x.IdPais);*/
            builder.Ignore(x => x.Negocio);
            builder.Ignore(x => x.Proceso);
            builder.Ignore(x => x.Pantalla);
            builder.Ignore(x => x.Pais);
        }
    }
}
