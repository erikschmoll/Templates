﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockBocaConfiguration : IEntityTypeConfiguration<Boca>
    {
        public void Configure(EntityTypeBuilder<Boca> builder)
        {
            builder.ToTable("Boca");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idBoca");
            builder.Property(x => x.Direccion).HasMaxLength(50);
            builder.Property(x => x.Poblacion).HasMaxLength(50);
            builder.Property(x => x.Telefono).HasMaxLength(50);
            builder.Property(x => x.IdTitular).HasMaxLength(50);
            builder.Property(x => x.CodigoPostal).HasMaxLength(50);
            builder.Property(x => x.InstruccionesDeAcceso).HasMaxLength(50);
            builder.Property(x => x.IdZona).HasMaxLength(50);
            builder.Property(x => x.IdProntoPago).HasMaxLength(50);
            builder.Property(x => x.RazonSocial).HasMaxLength(500);
            builder.Property(x => x.IdRegionComercial).HasMaxLength(50);
            builder.Property(x => x.IdTipoRegionComercial).HasMaxLength(50);
            builder.Property(x => x.IdPlanta).HasMaxLength(50);
            builder.Property(x => x.ResolucionDGE).HasMaxLength(50).IsRequired(false);
            /*builder.HasOne(x => x.Titular).WithMany().HasForeignKey(x => x.IdTitular);
            builder.HasOne(x => x.Zona).WithMany().HasForeignKey(x => x.IdZona);
            builder.HasOne(x => x.ProntoPago).WithMany().HasForeignKey(x => x.IdProntoPago);
            builder.HasOne(x => x.Planta).WithMany().HasForeignKey(x => x.IdPlanta);
            builder.HasOne(x => x.RegionComercial).WithMany().HasForeignKey(x => new
            {
                x.IdRegionComercial,
                x.IdTipoRegionComercial
            });*/
            builder.Ignore(x => x.Titular);
            builder.Ignore(x => x.Zona);
            builder.Ignore(x => x.ProntoPago);
            builder.Ignore(x => x.Planta);
            builder.Ignore(x => x.RegionComercial);
        }
    }
}
