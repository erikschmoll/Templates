﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockViajeConfiguration : IEntityTypeConfiguration<Viaje>
    {
        public void Configure(EntityTypeBuilder<Viaje> builder)
        {
            builder.ToTable("Viaje");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idViaje");
            builder.Property(x => x.LitrajeInicial).HasPrecision(13, 4);
            builder.Property(x => x.LitrajeFinal).HasPrecision(13, 4);
            builder.Property(x => x.PesadaInicial).HasPrecision(13, 4);
            builder.Property(x => x.PesadaFinal).HasPrecision(13, 4);
            builder.Property(x => x.PresionInicial).HasPrecision(13, 4);
            builder.Property(x => x.PresionFinal).HasPrecision(13, 4);
            builder.Property(x => x.TemperaturaInicial).HasPrecision(13, 4);
            builder.Property(x => x.TemperaturaFinal).HasPrecision(13, 4);
            builder.Property(x => x.PorcentajeDeRotaryInicial).HasPrecision(13, 4);
            builder.Property(x => x.PorcentajeDeRotaryFinal).HasPrecision(13, 4);
            builder.Property(x => x.IdUsuario).HasMaxLength(50);
            builder.Property(x => x.IdTipoDeViaje).HasMaxLength(50);
            builder.Property(x => x.EmpresaTransportista).HasMaxLength(50);
            builder.Property(x => x.DensidadInicial).HasPrecision(13, 4);
            builder.Property(x => x.DensidadFinal).HasPrecision(13, 4);
            //builder.HasOne(x => x.Usuario).WithMany().HasForeignKey(x => x.IdUsuario);
            //builder.HasOne(x => x.TipoDeViaje).WithMany().HasForeignKey(x => x.IdTipoDeViaje);
            builder.Ignore(x => x.Usuario);
            builder.Ignore(x => x.TipoDeViaje);
        }
    }
}
