﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockDocumentoConfiguration : IEntityTypeConfiguration<Documento>
    {
        public void Configure(EntityTypeBuilder<Documento> builder)
        {
            builder.ToTable("Documento");
            builder.HasKey(x => new
            {
                x.Id,
                x.IdViaje
            });
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idDocumento");
            builder.Property(x => x.IdTipoDocumento).HasMaxLength(50);
           // builder.HasOne(x => x.TipoDocumento).WithMany().HasForeignKey(x => x.IdTipoDocumento);
           // builder.HasOne(x => x.Viaje).WithMany().HasForeignKey(x => x.IdViaje);
            builder.Ignore(x => x.TipoDocumento);
            builder.Ignore(x => x.Viaje);
        }
    }
}
