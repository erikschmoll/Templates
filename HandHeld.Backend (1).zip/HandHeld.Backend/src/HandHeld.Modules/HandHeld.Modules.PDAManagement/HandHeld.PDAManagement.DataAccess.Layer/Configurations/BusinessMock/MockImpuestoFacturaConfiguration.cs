﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockImpuestoFacturaConfiguration : IEntityTypeConfiguration<ImpuestoFactura>
    {
        public void Configure(EntityTypeBuilder<ImpuestoFactura> builder)
        {
            builder.ToTable("ImpuestoFactura");
            builder.HasKey(x => new
            {
                x.IdViaje,
                x.IdDocumentoFactura,
                x.IdImpuesto
            });
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.IdImpuesto).HasMaxLength(50);
            builder.Property(x => x.IdUnidad).HasMaxLength(50);
            builder.Property(x => x.Importe).HasPrecision(13, 4);
            builder.Property(x => x.Porcentaje).HasPrecision(13, 4);
            /*builder.HasOne(x => x.Impuesto).WithMany().HasForeignKey(x => x.IdImpuesto);
            builder.HasOne(x => x.Unidad).WithMany().HasForeignKey(x => x.IdUnidad);
            builder.HasOne(x => x.Factura).WithMany().HasForeignKey(x => new
            {
                x.IdDocumentoFactura,
                x.IdViaje
            });*/
            builder.Ignore(x => x.Impuesto);
            builder.Ignore(x => x.Unidad);
            builder.Ignore(x => x.Factura);
        }
    }
}
