﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockTipoDeViajeConfiguration : IEntityTypeConfiguration<TipoDeViaje>
    {
        public void Configure(EntityTypeBuilder<TipoDeViaje> builder)
        {
            builder.ToTable("TipoDeViaje");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idTipoDeViaje");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("tipoDeViaje");
            builder.Property(x => x.IdClaseSAP).HasMaxLength(50);
        }
    }
}
