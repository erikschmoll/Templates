﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockMovimientoStockAnuladoConfiguration : IEntityTypeConfiguration<MovimientoStockAnulado>
    {
        public void Configure(EntityTypeBuilder<MovimientoStockAnulado> builder)
        {
            builder.ToTable("MovimientoStockAnulado");
            builder.HasKey(x => new
            {
                x.IdMovimiento,
                x.IdViaje
            });
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            /*builder.HasOne(x => x.GeoPosicion).WithMany().HasForeignKey(x => x.IdGeoPosicion);
            builder.HasOne(x => x.MovimientoStock).WithMany().HasForeignKey(x => new
            {
                x.IdMovimiento,
                x.IdViaje
            });*/
            builder.Ignore(x => x.GeoPosicion);
            builder.Ignore(x => x.MovimientoStock);
        }
    }
}
