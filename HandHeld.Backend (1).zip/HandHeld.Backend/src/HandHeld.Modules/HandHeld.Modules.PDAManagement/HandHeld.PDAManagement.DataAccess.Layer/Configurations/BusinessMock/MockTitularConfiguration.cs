﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockTitularConfiguration : IEntityTypeConfiguration<Titular>
    {
        public void Configure(EntityTypeBuilder<Titular> builder)
        {
            builder.ToTable("Titular");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idTitular");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("titular");
            builder.Property(x => x.Direccion).HasMaxLength(500);
            builder.Property(x => x.IdFiscal).HasMaxLength(50);
            builder.Property(x => x.CodigoPostal).HasMaxLength(50);
            builder.Property(x => x.Poblacion).HasMaxLength(50);
            builder.Property(x => x.IdTipoIdFiscal).HasMaxLength(50);
            builder.Property(x => x.IdCategoriaSegunFisco).HasMaxLength(50);
            builder.Property(x => x.IdRegionComercial).HasMaxLength(50);
            builder.Property(x => x.IdTipoRegionComercial).HasMaxLength(50);
            /*builder.HasOne(x => x.CategoriaSegunFisco).WithMany().HasForeignKey(x => x.IdCategoriaSegunFisco);
            builder.HasOne(x => x.RegionComercial).WithMany().HasForeignKey(x => new
            {
                x.IdRegionComercial,
                x.IdTipoRegionComercial
            });*/
            builder.Ignore(x => x.CategoriaSegunFisco);
            builder.Ignore(x => x.RegionComercial);
        }
    }
}
