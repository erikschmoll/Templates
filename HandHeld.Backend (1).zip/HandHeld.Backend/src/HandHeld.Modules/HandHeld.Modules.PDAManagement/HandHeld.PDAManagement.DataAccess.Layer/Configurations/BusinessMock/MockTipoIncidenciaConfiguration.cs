﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockTipoIncidenciaConfiguration : IEntityTypeConfiguration<TipoIncidencia>
    {
        public void Configure(EntityTypeBuilder<TipoIncidencia> builder)
        {
            builder.ToTable("TipoIncidencia");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idTipoIncidencia");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("tipoIncidencia");
        }
    }
}
