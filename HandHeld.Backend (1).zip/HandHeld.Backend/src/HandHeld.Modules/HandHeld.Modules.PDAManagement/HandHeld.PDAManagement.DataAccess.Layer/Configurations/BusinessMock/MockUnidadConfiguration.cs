﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockUnidadConfiguration : IEntityTypeConfiguration<Unidad>
    {
        public void Configure(EntityTypeBuilder<Unidad> builder)
        {
            builder.ToTable("Unidad");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idUnidad");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("unidad");
            builder.Property(x => x.Simbolo).HasMaxLength(50);
            builder.Property(x => x.TipoUnidad).HasMaxLength(50);
        }
    }
}
