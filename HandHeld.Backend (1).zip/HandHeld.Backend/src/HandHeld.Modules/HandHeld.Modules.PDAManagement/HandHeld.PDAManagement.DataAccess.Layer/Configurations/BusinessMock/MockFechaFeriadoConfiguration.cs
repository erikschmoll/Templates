﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockFechaFeriadoConfiguration : IEntityTypeConfiguration<FechaFeriado>
    {
        public void Configure(EntityTypeBuilder<FechaFeriado> builder)
        {
            builder.ToTable("FechaFeriado");
            builder.HasKey(x => new
            {
                x.Fecha,
                x.IdPlanta
            });
            builder.Property(x => x.IdPlanta).HasMaxLength(50);
            //builder.HasOne(x => x.Planta).WithMany().HasForeignKey(x => x.IdPlanta);
            builder.Ignore(x => x.Planta);
        }
    }
}
