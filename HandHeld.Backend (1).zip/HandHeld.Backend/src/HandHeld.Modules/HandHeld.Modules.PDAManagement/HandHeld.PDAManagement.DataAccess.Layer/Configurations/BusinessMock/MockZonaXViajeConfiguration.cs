﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockZonaXViajeConfiguration : IEntityTypeConfiguration<ZonaXViaje>
    {
        public void Configure(EntityTypeBuilder<ZonaXViaje> builder)
        {
            builder.ToTable("ZonaXViaje");
            builder.HasKey(x => new { x.IdZona, x.IdViaje });
            builder.Property(x => x.IdZona).HasMaxLength(50);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            //builder.HasOne(x => x.Zona).WithMany().HasForeignKey(x => x.IdZona);
            //builder.HasOne(x => x.Viaje).WithMany().HasForeignKey(x => x.IdViaje);
            builder.Ignore(x => x.Zona);
            builder.Ignore(x => x.Viaje);
        }
    }
}
