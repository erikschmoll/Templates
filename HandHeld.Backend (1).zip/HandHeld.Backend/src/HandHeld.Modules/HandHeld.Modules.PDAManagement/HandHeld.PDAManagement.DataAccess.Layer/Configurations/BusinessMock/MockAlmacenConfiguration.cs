﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockAlmacenConfiguration : IEntityTypeConfiguration<Almacen>
    {
        public void Configure(EntityTypeBuilder<Almacen> builder)
        {
            builder.ToTable("Almacen");
            builder.HasKey(x => new
            {
                x.Id,
                x.IdPlanta
            });
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idAlmacen");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("almacen");
            builder.Property(x => x.IdPlanta).HasMaxLength(50);
            //builder.HasOne(x => x.Planta).WithMany().HasForeignKey(x => x.IdPlanta);
            builder.Ignore(x => x.Planta);
        }
    }
}