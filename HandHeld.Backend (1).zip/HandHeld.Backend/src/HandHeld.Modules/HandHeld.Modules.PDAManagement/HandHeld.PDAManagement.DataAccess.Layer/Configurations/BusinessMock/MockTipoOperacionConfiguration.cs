﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockTipoOperacionConfiguration : IEntityTypeConfiguration<TipoOperacion>
    {
        public void Configure(EntityTypeBuilder<TipoOperacion> builder)
        {
            builder.ToTable("TipoOperacion");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idTipoOperacion");
            builder.Property(x => x.Nombre).HasMaxLength(50).HasColumnName("tipoOperacion");
            //builder.HasOne(x => x.Unidad).WithMany().HasForeignKey(x => x.IdUnidadPreferida);
            builder.Ignore(x => x.Unidad);
        }
    }
}
