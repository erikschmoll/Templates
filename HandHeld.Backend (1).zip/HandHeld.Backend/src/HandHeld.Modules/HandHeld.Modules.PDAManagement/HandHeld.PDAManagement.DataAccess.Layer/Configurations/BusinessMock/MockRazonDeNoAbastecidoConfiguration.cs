﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockRazonDeNoAbastecidoConfiguration : IEntityTypeConfiguration<RazonDeNoAbastecido>
    {
        public void Configure(EntityTypeBuilder<RazonDeNoAbastecido> builder)
        {
            builder.ToTable("RazonDeNoAbastecido");
            builder.HasKey(x => new { 
                x.Secuencia,
                x.IdViaje,
                x.IdPedido
            });
            builder.Property(x => x.Observaciones).HasMaxLength(500);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.IdPedido).HasMaxLength(50);
            builder.Property(x => x.IdTipoRazonDeNoAbastecido).HasMaxLength(50);
            /*builder.HasOne(x => x.GeoPosicion).WithMany().HasForeignKey(x => x.IdGeoPosicion);
            builder.HasOne(x => x.TipoRazonDeNoAbastecido).WithMany().HasForeignKey(x => x.IdTipoRazonDeNoAbastecido);
            builder.HasOne(x => x.Pedido).WithMany().HasForeignKey(x => new
            {
                x.IdPedido,
                x.IdViaje
            });*/
            builder.Ignore(x => x.GeoPosicion);
            builder.Ignore(x => x.TipoRazonDeNoAbastecido);
            builder.Ignore(x => x.Pedido);
        }
    }
}
