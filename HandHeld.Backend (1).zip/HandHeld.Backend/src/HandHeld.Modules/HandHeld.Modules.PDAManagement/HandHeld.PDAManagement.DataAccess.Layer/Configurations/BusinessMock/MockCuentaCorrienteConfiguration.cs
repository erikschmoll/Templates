﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockCuentaCorrienteConfiguration : IEntityTypeConfiguration<CuentaCorriente>
    {
        public void Configure(EntityTypeBuilder<CuentaCorriente> builder)
        {
            builder.ToTable("CuentaCorriente");
            builder.HasKey(x => new
            {
                x.NroDocumentoSAP,
                x.Ejercicio,
                x.Posicion
            });
            builder.Property(x => x.IdBoca).HasMaxLength(50);
            builder.Property(x => x.NroDocumentoSAP).HasMaxLength(50);
            builder.Property(x => x.ClaseDocumentoSAP).HasMaxLength(50);
            builder.Property(x => x.Serie).HasMaxLength(50);
            builder.Property(x => x.IdTipoDocumento).HasMaxLength(50);
            builder.Property(x => x.IdMonedaImportes).HasMaxLength(50);
            //builder.HasOne(x => x.Boca).WithMany().HasForeignKey(x => x.IdBoca);
            //builder.HasOne(x => x.TipoDocumento).WithMany().HasForeignKey(x => x.IdTipoDocumento);
            //builder.HasOne(x => x.MonedaImportes).WithMany().HasForeignKey(x => x.IdMonedaImportes);

            builder.Ignore(x => x.Boca);
            builder.Ignore(x => x.TipoDocumento);
            builder.Ignore(x => x.MonedaImportes);
        }
    }
}
