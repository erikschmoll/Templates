﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockPatenteConfiguration : IEntityTypeConfiguration<Patente>
    {
        public void Configure(EntityTypeBuilder<Patente> builder)
        {
            builder.ToTable("Patente");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).HasColumnName("idPatente");
            builder.Property(x => x.TipoVehiculo).HasMaxLength(50);
            builder.Property(x => x.EmpresaTransportista).HasMaxLength(50);
            builder.Property(x => x.CapacidadDeCarga).HasPrecision(13, 4);
        }
    }
}
