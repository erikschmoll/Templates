﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock
{
    internal class MockIncidenciaConfiguration : IEntityTypeConfiguration<Incidencia>
    {
        public void Configure(EntityTypeBuilder<Incidencia> builder)
        {
            builder.ToTable("Incidencia");
            builder.HasKey(x => new
            {
                x.IdIncidencia,
                x.IdViaje
            });
            builder.Property(x => x.Observaciones).HasMaxLength(500);
            builder.Property(x => x.IdTipoIncidencia).HasMaxLength(50);
            builder.Property(x => x.IdBoca).HasMaxLength(50);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            //builder.HasOne(x => x.TipoIncidencia).WithMany().HasForeignKey(x => x.IdTipoIncidencia);
            //builder.HasOne(x => x.Boca).WithMany().HasForeignKey(x => x.IdBoca);
            //builder.HasOne(x => x.Viaje).WithMany().HasForeignKey(x => x.IdViaje);
            //builder.HasOne(x => x.GeoPosicion).WithMany().HasForeignKey(x => x.IdGeoPosicion);
            builder.Ignore(x => x.TipoIncidencia);
            builder.Ignore(x => x.Boca);
            builder.Ignore(x => x.Viaje);
            builder.Ignore(x => x.GeoPosicion);
        }
    }
}
