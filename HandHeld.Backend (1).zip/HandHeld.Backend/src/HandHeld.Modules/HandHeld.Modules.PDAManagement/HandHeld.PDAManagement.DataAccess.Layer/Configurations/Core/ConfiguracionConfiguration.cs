﻿using HandHeld.PDAManagement.DataAccess.Layer.Configurations.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Core
{
    internal class ConfiguracionConfiguration : AuditoriaConfiguration<Configuracion>
    {
        public override void Configure(EntityTypeBuilder<Configuracion> builder)
        {
            base.Configure(builder);
            builder.ToTable("Configuraciones", "Modulo_Compartido");
            builder.Property(x => x.Valor).HasMaxLength(50).IsRequired();
            builder.Property(x => x.Descripcion).HasMaxLength(300).IsRequired();
            builder.HasData(Seed());
        }
        private IEnumerable<Configuracion> Seed()
        {
            DateTimeOffset fechaCreacion = DateTimeOffset.UtcNow;
            return new List<Configuracion>(){
                   new Configuracion() {
                        Id = "vr",
                        Valor = "1",
                        Descripcion = "Versión del Release",
                        CreadoPor = "Admin",
                        ModificadoPor = "Admin",
                        FechaCreacion = fechaCreacion,
                        FechaModificacion = fechaCreacion,
                        Del = false
                    },
                   new Configuracion() {
                        Id = "cape",
                        Valor = "5",
                        Descripcion = "Cantidad de Actualizaciones a Procesar por Ejecución",
                        CreadoPor = "Admin",
                        ModificadoPor = "Admin",
                        FechaCreacion = fechaCreacion,
                        FechaModificacion = fechaCreacion,
                        Del = false
                    },
                   new Configuracion() {
                        Id = "cpina",
                        Valor = "1",
                        Descripcion = "Cantidad Permitida de Instalaciones por Número de Actualización",
                        CreadoPor = "Admin",
                        ModificadoPor = "Admin",
                        FechaCreacion = fechaCreacion,
                        FechaModificacion = fechaCreacion,
                        Del = false
                    }
               };
        }
    }
}
