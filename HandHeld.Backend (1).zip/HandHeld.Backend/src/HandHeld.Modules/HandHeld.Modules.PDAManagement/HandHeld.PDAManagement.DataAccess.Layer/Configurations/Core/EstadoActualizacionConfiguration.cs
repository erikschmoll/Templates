﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Core
{
    internal class EstadoActualizacionConfiguration : AuditoriaConfiguration<EstadoActualizacion>
    {
        public override void Configure(EntityTypeBuilder<EstadoActualizacion> builder)
        {
            base.Configure(builder);
            builder.ToTable("EstadosActualizaciones", "Modulo_Inicializacion");
            builder.Property(x => x.Nombre).HasMaxLength(50).IsRequired();
            builder.HasData(Seed());
        }

        private IEnumerable<EstadoActualizacion> Seed()
        {
            DateTimeOffset fechaCreacion = DateTimeOffset.UtcNow;
            return new List<EstadoActualizacion>(){
                   new EstadoActualizacion() {
                        Id = "1",
                        Nombre = "Pendiente",
                        CreadoPor = "Admin",
                        ModificadoPor = "Admin",
                        FechaCreacion = fechaCreacion,
                        FechaModificacion = fechaCreacion,
                        Del = false
                    },
                    new EstadoActualizacion()
                    {
                        Id = "2",
                        Nombre = "Procesando...",
                        CreadoPor = "Admin",
                        ModificadoPor = "Admin",
                        FechaCreacion = fechaCreacion,
                        FechaModificacion = fechaCreacion,
                        Del = false
                    },
                    new EstadoActualizacion()
                    {
                        Id = "3",
                        Nombre = "Listo para sincronizar",
                        CreadoPor = "Admin",
                        ModificadoPor = "Admin",
                        FechaCreacion = fechaCreacion,
                        FechaModificacion = fechaCreacion,
                        Del = false
                    },
                    new EstadoActualizacion()
                    {
                        Id = "4",
                        Nombre = "Error",
                        CreadoPor = "Admin",
                        ModificadoPor = "Admin",
                        FechaCreacion = fechaCreacion,
                        FechaModificacion = fechaCreacion,
                        Del = false
                    },
                    new EstadoActualizacion()
                    {
                        Id = "5",
                        Nombre = "Obsoleto",
                        CreadoPor = "Admin",
                        ModificadoPor = "Admin",
                        FechaCreacion = fechaCreacion,
                        FechaModificacion = fechaCreacion,
                        Del = false
                    }
               };
        }
    }
}
