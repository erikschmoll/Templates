﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Core
{
    internal class InstalacionConfiguration : AuditoriaConfiguration<Instalacion>
    {
        public override void Configure(EntityTypeBuilder<Instalacion> builder)
        {
            base.Configure(builder);
            builder.ToTable("Instalaciones", "Modulo_Inicializacion");
            builder.Property(x => x.IdActualizacion).HasMaxLength(50).IsRequired();
            builder.Property(x => x.Chofer).HasMaxLength(50).IsRequired();
            builder.Property(x => x.Dispositivo).HasMaxLength(100).IsRequired(false);
            builder.HasOne(x => x.Actualizacion)
                .WithMany()
                .HasForeignKey(x => x.IdActualizacion)
                .HasConstraintName("FK_INSTALACION_ACTUALIZACION");
        }
    }
}
