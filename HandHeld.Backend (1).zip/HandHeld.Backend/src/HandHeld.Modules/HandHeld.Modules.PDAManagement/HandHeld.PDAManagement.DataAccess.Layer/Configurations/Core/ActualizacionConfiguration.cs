﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Core
{
    internal class ActualizacionConfiguration : AuditoriaConfiguration<Actualizacion>
    {
        public override void Configure(EntityTypeBuilder<Actualizacion> builder)
        {
            base.Configure(builder);
            builder.ToTable("Actualizaciones", "Modulo_Inicializacion");
            builder.Property(x => x.IdPlanta).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdPatente).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdChofer).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdEstado).HasMaxLength(50).IsRequired();
            builder.Property(x => x.Url).HasMaxLength(300).IsRequired(false);
            builder.Property(x => x.Version).IsRequired(false);
            builder.Property(x => x.NroActualizacion).HasMaxLength(6).IsRequired(false);
            builder.HasOne(x => x.Estado).WithMany().HasForeignKey(x => x.IdEstado);
            builder.Ignore(x => x.Planta);
            builder.Ignore(x => x.Patente);
            builder.Ignore(x => x.Chofer);
        }
    }
}
