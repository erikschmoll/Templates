﻿using HandHeld.PDAManagement.DataAccess.Layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Core
{
    internal class AuditoriaConfiguration<T> : IEntityTypeConfiguration<T> where T : Auditoria
    {
        public virtual void Configure(EntityTypeBuilder<T> builder)
        {
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50).IsRequired().ValueGeneratedNever();
            builder.Property(x => x.FechaCreacion).IsRequired();
            builder.Property(x => x.ModificadoPor).IsRequired(false);
            builder.Property(x => x.CreadoPor).HasMaxLength(50).IsRequired();
            builder.Property(x => x.ModificadoPor).HasMaxLength(50).IsRequired(false);
            builder.Property(x => x.Del).IsRequired();
        }
    }
}
