﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class TipoPedidoConfiguration : IEntityTypeConfiguration<TipoPedido>
    {
        public void Configure(EntityTypeBuilder<TipoPedido> builder)
        {
            builder.ToTable("TipoPedido");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50);
            builder.Property(x => x.Nombre).HasMaxLength(50);
        }
    }
}
