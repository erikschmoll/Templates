﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class FactorDeConversionConfiguration : IEntityTypeConfiguration<FactorDeConversion>
    {
        public void Configure(EntityTypeBuilder<FactorDeConversion> builder)
        {
            builder.ToTable("FactorDeConversion");
            builder.HasKey(x => new
            {
                x.IdUnidadDesde,
                x.IdUnidadHacia
            });
            builder.Property(x => x.IdUnidadDesde).HasMaxLength(50);
            builder.Property(x => x.IdUnidadHacia).HasMaxLength(50);
            builder.HasOne(x => x.UnidadDesde).WithMany().HasForeignKey(x => x.IdUnidadDesde);
            builder.HasOne(x => x.UnidadHacia).WithMany().HasForeignKey(x => x.IdUnidadHacia);
        }
    }
}
