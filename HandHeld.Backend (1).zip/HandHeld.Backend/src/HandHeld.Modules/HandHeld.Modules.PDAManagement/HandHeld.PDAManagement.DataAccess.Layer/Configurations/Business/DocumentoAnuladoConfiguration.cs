﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class DocumentoAnuladoConfiguration : IEntityTypeConfiguration<DocumentoAnulado>
    {
        public void Configure(EntityTypeBuilder<DocumentoAnulado> builder)
        {
            builder.ToTable("DocumentoAnulado");
            builder.HasKey(x => x.IdDocumento);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.HasOne(x => x.GeoPosicion).WithMany().HasForeignKey(x => x.IdGeoPosicion);
            builder.HasOne(x => x.Documento).WithMany().HasForeignKey(x => new
            {
                x.IdDocumento,
                x.IdViaje
            });
        }
    }
}
