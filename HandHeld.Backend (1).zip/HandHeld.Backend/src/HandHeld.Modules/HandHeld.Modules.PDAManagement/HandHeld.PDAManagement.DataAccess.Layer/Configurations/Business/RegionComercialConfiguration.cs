﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class RegionComercialConfiguration : IEntityTypeConfiguration<RegionComercial>
    {
        public void Configure(EntityTypeBuilder<RegionComercial> builder)
        {
            builder.ToTable("RegionComercial");
            builder.HasKey(x => new { x.Id, x.IdTipoRegionComercial });
            builder.Property(x => x.Id).HasMaxLength(50);
            builder.Property(x => x.Nombre).HasMaxLength(50);
            builder.Property(x => x.IdTipoRegionComercial).HasMaxLength(50);
            builder.Property(x => x.IdTipoRegionComercialRef).HasMaxLength(50);
            builder.Property(x => x.IdRegionComercialRef).HasMaxLength(50);
            //builder.HasOne(x => x.RegionComercialRef).WithMany().HasForeignKey(x => new { x.IdRegionComercialRef, x.IdTipoRegionComercialRef });
        }
    }
}
