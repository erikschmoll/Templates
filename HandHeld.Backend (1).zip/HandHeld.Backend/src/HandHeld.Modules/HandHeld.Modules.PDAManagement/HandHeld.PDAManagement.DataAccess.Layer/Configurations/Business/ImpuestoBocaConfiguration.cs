﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class ImpuestoBocaConfiguration : IEntityTypeConfiguration<ImpuestoBoca>
    {
        public void Configure(EntityTypeBuilder<ImpuestoBoca> builder)
        {
            builder.ToTable("ImpuestoBoca");
            builder.HasKey(x =>new
            {
                x.IdImpuesto,
                x.IdBoca,
                x.FechaSujetoDesde
            });
            builder.Property(x => x.IdImpuesto).HasMaxLength(50);
            builder.Property(x => x.IdBoca).HasMaxLength(50);
            builder.Property(x => x.IdUnidadImporteMinimo).HasMaxLength(50);
            builder.Property(x => x.PorcentajeImpuesto).HasPrecision(13,4);
            builder.Property(x => x.ImporteMinimo).HasPrecision(13,4);
            builder.Property(x => x.PorcentajeExento).HasPrecision(13,4);
            builder.HasOne(x => x.Impuesto).WithMany().HasForeignKey(x => x.IdImpuesto);
            builder.HasOne(x => x.Boca).WithMany().HasForeignKey(x => x.IdBoca);
            builder.HasOne(x => x.UnidadImporteMinimo).WithMany().HasForeignKey(x => x.IdUnidadImporteMinimo);
        }
    }
}
