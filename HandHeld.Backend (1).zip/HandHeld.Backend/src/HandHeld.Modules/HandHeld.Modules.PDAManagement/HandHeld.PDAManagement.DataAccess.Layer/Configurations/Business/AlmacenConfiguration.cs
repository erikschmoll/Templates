﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class AlmacenConfiguration : IEntityTypeConfiguration<Almacen>
    {
        public void Configure(EntityTypeBuilder<Almacen> builder)
        {
            builder.ToTable("Almacen");
            builder.HasKey(x => new
            {
                Id = x.Id,
                IdPlanta = x.IdPlanta
            }).HasName("PK_ALMACEN_ID");
            builder.Property(x => x.Id).HasMaxLength(50).IsRequired();
            builder.Property(x => x.Nombre).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdPlanta).HasMaxLength(50).IsRequired();
            builder.HasOne(x => x.Planta)
                .WithMany()
                .HasForeignKey(x => x.IdPlanta)
                .HasConstraintName("FK_ALMACEN_PLANTA");
        }
    }
}