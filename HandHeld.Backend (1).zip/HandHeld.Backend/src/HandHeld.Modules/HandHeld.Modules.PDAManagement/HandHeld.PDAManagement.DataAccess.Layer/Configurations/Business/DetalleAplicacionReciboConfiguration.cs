﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class DetalleAplicacionReciboConfiguration : IEntityTypeConfiguration<DetalleAplicacionRecibo>
    {
        public void Configure(EntityTypeBuilder<DetalleAplicacionRecibo> builder)
        {
            builder.ToTable("DetalleAplicacionRecibo");
            builder.HasKey(x => new
            {
                x.IdDocumentoRecibo,
                x.Orden,
                x.IdViaje
            });
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.NroDocumentoSAP).HasMaxLength(50);
            builder.Property(x => x.Estado).HasMaxLength(50);
            builder.HasOne(x => x.CuentaCorriente).WithMany().HasForeignKey(x => new
            {
                x.NroDocumentoSAP,
                x.Ejercicio,
                x.Posicion
            });
            builder.HasOne(x => x.Documento).WithMany().HasForeignKey(x => new
            {
                x.IdDocumento,
                x.IdViaje
            });
            builder.HasOne(x => x.Recibo).WithMany().HasForeignKey(x => new
            {
                x.IdDocumentoRecibo,
                x.IdViaje
            });
        }
    }
}
