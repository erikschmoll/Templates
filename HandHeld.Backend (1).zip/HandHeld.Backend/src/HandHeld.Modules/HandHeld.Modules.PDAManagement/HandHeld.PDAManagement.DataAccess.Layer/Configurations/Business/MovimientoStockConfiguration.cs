﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class MovimientoStockConfiguration : IEntityTypeConfiguration<MovimientoStock>
    {
        public void Configure(EntityTypeBuilder<MovimientoStock> builder)
        {
            builder.ToTable("MovimientoStock");
            builder.HasKey(x => new
            {
                x.Id,
                x.IdViaje
            });
            builder.Property(x => x.IdAlmacenOrigen).HasMaxLength(50);
            builder.Property(x => x.IdAlmacenDestino).HasMaxLength(50);
            builder.Property(x => x.IdPlantaOrigen).HasMaxLength(50);
            builder.Property(x => x.IdPlantaDestino).HasMaxLength(50);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.IdPatenteTractor).HasMaxLength(50);
            builder.Property(x => x.IdPatenteTanque).HasMaxLength(50);
            builder.Property(x => x.RemitoReferencia).HasMaxLength(50);
            builder.Property(x => x.IdTipoOperacion).HasMaxLength(50);
            builder.Property(x => x.IdBocaDespacho).HasMaxLength(50);
            builder.Property(x => x.Kilometros).HasPrecision(13,4);
            builder.Property(x => x.KilosFinal).HasPrecision(13,4);
            builder.Property(x => x.KilosInicial).HasPrecision(13,4);
            builder.Property(x => x.LitrajeInicial).HasPrecision(13,4);
            builder.Property(x => x.LitrajeFinal).HasPrecision(13,4);
            builder.Property(x => x.Temperatura).HasPrecision(13,4);
            builder.HasOne(x => x.BocaDespacho).WithMany().HasForeignKey(x => x.IdBocaDespacho);
            builder.HasOne(x => x.TipoOperacion).WithMany().HasForeignKey(x => x.IdTipoOperacion);
            builder.HasOne(x => x.Viaje).WithMany().HasForeignKey(x => x.IdViaje);
            builder.HasOne(x => x.GeoPosicionInicial).WithMany().HasForeignKey(x => x.IdGeoPosicionInicial);
            builder.HasOne(x => x.GeoPosicionFinal).WithMany().HasForeignKey(x => x.IdGeoPosicionFinal);
            builder.HasOne(x => x.PatenteTanque).WithMany().HasForeignKey(x => x.IdPatenteTanque);
            builder.HasOne(x => x.PatenteTractor).WithMany().HasForeignKey(x => x.IdPatenteTractor);
            builder.HasOne(x => x.Documento).WithMany().HasForeignKey(x => new
            {
                x.IdDocumento,
                x.IdViaje
            });
            builder.HasOne(x => x.AlmacenDestino).WithMany().HasForeignKey(x => new
            {
                x.IdAlmacenDestino,
                x.IdPlantaDestino
            });
            builder.HasOne(x => x.AlmacenOrigen).WithMany().HasForeignKey(x => new
            {
                x.IdAlmacenOrigen,
                x.IdPlantaOrigen
            });
        }
    }
}
