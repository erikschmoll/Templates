﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class ValorConfiguration : IEntityTypeConfiguration<Valor>
    {
        public void Configure(EntityTypeBuilder<Valor> builder)
        {
            builder.ToTable("Valor");
            builder.HasKey(x => new
            {
                x.IdDocumentoRecibo,
                x.IdViaje,
                x.IdValor
            });
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.Numero).HasMaxLength(50);
            builder.Property(x => x.IdUnidadImporte).HasMaxLength(50);
            builder.Property(x => x.IdViaDePago).HasMaxLength(50);
            builder.Property(x => x.IdBanco).HasMaxLength(50);
            builder.Property(x => x.IdSucursal).HasMaxLength(50);
            builder.Property(x => x.Importe).HasPrecision(13,4);
            builder.HasOne(x => x.Sucursal).WithMany().HasForeignKey(x => new
            {
                x.IdSucursal,
                x.IdBanco
            });
            builder.HasOne(x => x.ViaDePago).WithMany().HasForeignKey(x => x.IdViaDePago);
            builder.HasOne(x => x.UnidadImporte).WithMany().HasForeignKey(x => x.IdUnidadImporte);
            builder.HasOne(x => x.Recibo).WithMany().HasForeignKey(x => new
            {
                x.IdDocumentoRecibo,
                x.IdViaje
            });
        }
    }
}
