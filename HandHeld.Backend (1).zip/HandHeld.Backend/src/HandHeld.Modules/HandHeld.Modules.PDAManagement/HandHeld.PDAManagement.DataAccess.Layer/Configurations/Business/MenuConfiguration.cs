﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class MenuConfiguration : IEntityTypeConfiguration<Menu>
    {
        public void Configure(EntityTypeBuilder<Menu> builder)
        {
            builder.ToTable("Menu");
            builder.HasKey(x => new
            {
                x.Id,
                x.IdPais,
                x.IdNegocio
            });
            builder.Property(x => x.Id).HasMaxLength(50);
            builder.Property(x => x.Nombre).HasMaxLength(50);
            builder.Property(x => x.Mediador).HasMaxLength(50);
            builder.Property(x => x.IdPais).HasMaxLength(50);
            builder.Property(x => x.IdNegocio).HasMaxLength(50);
            builder.HasOne(x => x.Pais).WithMany().HasForeignKey(x => x.IdPais);
            builder.HasOne(x => x.Negocio).WithMany().HasForeignKey(x => x.IdNegocio);
            /*builder.HasOne(x => x.MenuPadre1).WithMany().HasForeignKey(x => new
            {
                x.IdMenuPadre,
                x.IdPais,
                x.IdNegocio
            });*/
        }
    }
}
