﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class PantallaConfiguration : IEntityTypeConfiguration<Pantalla>
    {
        public void Configure(EntityTypeBuilder<Pantalla> builder)
        {
            builder.ToTable("Pantalla");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50);
            builder.Property(x => x.Nombre).HasMaxLength(50);
        }
    }
}
