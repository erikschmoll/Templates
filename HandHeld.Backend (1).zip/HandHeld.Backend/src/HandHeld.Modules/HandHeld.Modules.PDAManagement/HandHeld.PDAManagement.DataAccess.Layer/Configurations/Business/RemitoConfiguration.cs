﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class RemitoConfiguration : IEntityTypeConfiguration<Remito>
    {
        public void Configure(EntityTypeBuilder<Remito> builder)
        {
            builder.ToTable("Remito");
            builder.HasKey(x => new
            {
                x.IdViaje,
                x.IdDocumentoRemito
            });
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.IdBoca).HasMaxLength(50);
            builder.Property(x => x.Serie).HasMaxLength(50);
            builder.Property(x => x.Numero).HasPrecision(31, 0);
            builder.HasOne(x => x.Boca).WithMany().HasForeignKey(x => x.IdBoca);
            builder.HasOne(x => x.Documento).WithMany().HasForeignKey(x => new
            {
                x.IdDocumentoRemito,
                x.IdViaje
            });
        }
    }
}
