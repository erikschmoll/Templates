﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class BocaConfiguration : IEntityTypeConfiguration<Boca>
    {
        public void Configure(EntityTypeBuilder<Boca> builder)
        {
            builder.ToTable("Boca");
            builder.HasKey(x => x.Id).HasName("PK_BOCA_ID");
            builder.Property(x => x.Id).HasMaxLength(50).IsRequired();
            builder.Property(x => x.Direccion).HasMaxLength(50).IsRequired();
            builder.Property(x => x.Poblacion).HasMaxLength(50).IsRequired();
            builder.Property(x => x.Telefono).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdTitular).HasMaxLength(50).IsRequired();
            builder.Property(x => x.CodigoPostal).HasMaxLength(50).IsRequired();
            builder.Property(x => x.InstruccionesDeAcceso).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdZona).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdProntoPago).HasMaxLength(50).IsRequired(false);
            builder.Property(x => x.RazonSocial).HasMaxLength(500).IsRequired();
            builder.Property(x => x.IdRegionComercial).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdTipoRegionComercial).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdPlanta).HasMaxLength(50).IsRequired();
            builder.Property(x => x.ResolucionDGE).HasMaxLength(50).IsRequired(false);
            builder.Property(x => x.UsaSegundoVencimiento).IsRequired();
            builder.Property(x => x.UsaProntoPago).IsRequired();
            builder.Property(x => x.EstaEnZonaFranca).IsRequired();
            builder.Property(x => x.DiasPlazoPago).IsRequired();
            builder.Property(x => x.UsaDebitoAutomatico).IsRequired();
            builder.Property(x => x.EsFacturable).IsRequired();
            builder.Property(x => x.EstaActiva).IsRequired();
            builder.HasOne(x => x.Titular)
                .WithMany()
                .HasForeignKey(x => x.IdTitular)
                .HasConstraintName("FK_BOCA_TITULAR");
            builder.HasOne(x => x.Zona)
                .WithMany()
                .HasForeignKey(x => x.IdZona)
                .HasConstraintName("FK_BOCA_ZONA");
            builder.HasOne(x => x.ProntoPago)
                .WithMany()
                .HasForeignKey(x => x.IdProntoPago)
                .HasConstraintName("FK_BOCA_PRONTOPAGO");
            builder.HasOne(x => x.Planta)
                .WithMany()
                .HasForeignKey(x => x.IdPlanta)
                .HasConstraintName("FK_BOCA_PLANTA");
            builder.HasOne(x => x.RegionComercial)
                .WithMany()
                .HasForeignKey(x => new
            {
                    IdRegionComercial = x.IdRegionComercial,
                    IdTipoRegionComercial = x.IdTipoRegionComercial
            }).HasConstraintName("FK_BOCA_REGIONCOMERCIAL");
        }
    }
}
