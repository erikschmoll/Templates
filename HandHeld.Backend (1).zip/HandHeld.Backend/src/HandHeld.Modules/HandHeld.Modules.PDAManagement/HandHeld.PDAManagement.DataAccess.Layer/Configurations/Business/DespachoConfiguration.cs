﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class DespachoConfiguration : IEntityTypeConfiguration<Despacho>
    {
        public void Configure(EntityTypeBuilder<Despacho> builder)
        {
            builder.ToTable("Despacho");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Temperatura).HasPrecision(13,4);
            builder.Property(x => x.Densidad).HasPrecision(13,4);
            builder.Property(x => x.LitrosInicial).HasPrecision(13,4);
            builder.Property(x => x.LitrosFinal).HasPrecision(13,4);
            builder.Property(x => x.LitrosDespachados).HasPrecision(13,4);
            builder.Property(x => x.KilosDespachados).HasPrecision(13,4);
        }
    }
}
