﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class TipoOperacionConfiguration : IEntityTypeConfiguration<TipoOperacion>
    {
        public void Configure(EntityTypeBuilder<TipoOperacion> builder)
        {
            builder.ToTable("TipoOperacion");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50);
            builder.Property(x => x.Nombre).HasMaxLength(50);
            builder.HasOne(x => x.Unidad).WithMany().HasForeignKey(x => x.IdUnidadPreferida);
        }
    }
}
