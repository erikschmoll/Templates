﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class ViaDePagoConfiguration : IEntityTypeConfiguration<ViaDePago>
    {
        public void Configure(EntityTypeBuilder<ViaDePago> builder)
        {
            builder.ToTable("ViaDePago");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50);
            builder.Property(x => x.Nombre).HasMaxLength(50);
            builder.Property(x => x.IdUnidad).HasMaxLength(50);
            builder.HasOne(x => x.Unidad).WithMany().HasForeignKey(x => x.IdUnidad);
        }
    }
}
