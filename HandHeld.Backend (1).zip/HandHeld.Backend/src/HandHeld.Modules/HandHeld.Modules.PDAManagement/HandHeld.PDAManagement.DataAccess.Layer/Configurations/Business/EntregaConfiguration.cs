﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class EntregaConfiguration : IEntityTypeConfiguration<Entrega>
    {
        public void Configure(EntityTypeBuilder<Entrega> builder)
        {
            builder.ToTable("Entrega");
            builder.HasKey(x => new
            {
                x.Id,
                x.IdViaje
            });
            builder.Property(x => x.Id).HasMaxLength(50);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.IdPedido).HasMaxLength(50);
            builder.Property(x => x.IdBoca).HasMaxLength(50);
            builder.Property(x => x.Kilometros).HasPrecision(13, 4);
            builder.Property(x => x.KilosInicial).HasPrecision(13, 4);
            builder.Property(x => x.KilosFinal).HasPrecision(13, 4);
            builder.Property(x => x.LitrajeInicial).HasPrecision(13, 4);
            builder.Property(x => x.LitrajeFinal).HasPrecision(13, 4);
            builder.HasOne(x => x.Viaje).WithMany().HasForeignKey(x => x.IdViaje);
            builder.HasOne(x => x.GeoPosicionInicial).WithMany().HasForeignKey(x => x.IdGeoPosicionInicial);
            builder.HasOne(x => x.Boca).WithMany().HasForeignKey(x => x.IdBoca);
            builder.HasOne(x => x.GeoPosicionFinal).WithMany().HasForeignKey(x => x.IdGeoPosicionFinal);
            builder.HasOne(x => x.Pedido).WithMany().HasForeignKey(x => new 
            { 
                x.IdPedido,
                x.IdViaje
            });
        }
    }
}
