﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class ArticuloConfiguration : IEntityTypeConfiguration<Articulo>
    {
        public void Configure(EntityTypeBuilder<Articulo> builder)
        {
            builder.ToTable("Articulo");
            builder.HasKey(x => x.Id).HasName("PK_ARTICULO_ID");
            builder.Property(x => x.Id).HasMaxLength(50).IsRequired();
            builder.Property(x => x.Nombre).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdUnidadPreferidaCompra).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdUnidadPreferidaVenta).HasMaxLength(50).IsRequired();
            builder.Property(x => x.IdUnidadPreferidaStock).HasMaxLength(50).IsRequired();
            builder.Property(x => x.TipoArticulo).HasMaxLength(50).IsRequired();
            builder.Property(x => x.DensidadOficial).HasPrecision(13,4);
            builder.Property(x => x.EsEnvasado).IsRequired();
            builder.HasOne(x => x.UnidadPreferidaCompra)
                .WithMany()
                .HasForeignKey(x => x.IdUnidadPreferidaCompra)
                .HasConstraintName("FK_ARTICULO_UNIDADPREFERIDACOMPRA");
            builder.HasOne(x => x.UnidadPreferidaVenta)
                .WithMany()
                .HasForeignKey(x => x.IdUnidadPreferidaVenta)
                .HasConstraintName("FK_ARTICULO_UNIDADPREFERIDAVENTA");
            builder.HasOne(x => x.UnidadPreferidaStock)
                .WithMany()
                .HasForeignKey(x => x.IdUnidadPreferidaStock)
                .HasConstraintName("FK_ARTICULO_UNIDADPREFERIDASTOCK");
        }
    }
}
