﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class PDAConfiguration : IEntityTypeConfiguration<PDA>
    {
        public void Configure(EntityTypeBuilder<PDA> builder)
        {
            builder.ToTable("PDA");
            //TODO: la tabla no tiene key, pero a efc se le debe definir una
            builder.HasKey(x => new { x.IdPais, x.IdNegocio, x.IdPatenteTractor, x.IdPlanta, x.IdPatenteTanque });
            builder.Property(x => x.IdPais).HasMaxLength(50);
            builder.Property(x => x.IdNegocio).HasMaxLength(50);
            builder.Property(x => x.IdPatenteTractor).HasMaxLength(50);
            builder.Property(x => x.IdPlanta).HasMaxLength(50);
            builder.Property(x => x.IdPatenteTanque).HasMaxLength(50);
            builder.HasOne(x => x.Pais).WithMany().HasForeignKey(x => x.IdPais);
            builder.HasOne(x => x.Negocio).WithMany().HasForeignKey(x => x.IdNegocio);
            builder.HasOne(x => x.PatenteTractor).WithMany().HasForeignKey(x => x.IdPatenteTractor);
            builder.HasOne(x => x.Planta).WithMany().HasForeignKey(x => x.IdPlanta);
            builder.HasOne(x => x.PatenteTanque).WithMany().HasForeignKey(x => x.IdPatenteTanque);
        }
    }
}
