﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class DetalleRemitoConfiguration : IEntityTypeConfiguration<DetalleRemito>
    {
        public void Configure(EntityTypeBuilder<DetalleRemito> builder)
        {
            builder.ToTable("DetalleRemito");
            builder.HasKey(x => new
            {
                x.IdViaje,
                x.IdDocumentoRemito,
                x.IdArticulo
            });
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.IdArticulo).HasMaxLength(50);
            builder.Property(x => x.IdUnidadCantidadDespachada).HasMaxLength(50);
            builder.HasOne(x => x.UnidadCantidadDespachada).WithMany().HasForeignKey(x => x.IdUnidadCantidadDespachada);
            builder.HasOne(x => x.Articulo).WithMany().HasForeignKey(x => x.IdArticulo);
            builder.HasOne(x => x.Remito).WithMany().HasForeignKey(x => new
            {
                x.IdViaje,
                x.IdDocumentoRemito
            });
        }
    }
}
