﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class MovimientoStockAnuladoConfiguration : IEntityTypeConfiguration<MovimientoStockAnulado>
    {
        public void Configure(EntityTypeBuilder<MovimientoStockAnulado> builder)
        {
            builder.ToTable("MovimientoStockAnulado");
            builder.HasKey(x => new
            {
                x.IdMovimiento,
                x.IdViaje
            });
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.HasOne(x => x.GeoPosicion).WithMany().HasForeignKey(x => x.IdGeoPosicion);
            builder.HasOne(x => x.MovimientoStock).WithMany().HasForeignKey(x => new
            {
                x.IdMovimiento,
                x.IdViaje
            });
        }
    }
}
