﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class ProntoPagoConfiguration : IEntityTypeConfiguration<ProntoPago>
    {
        public void Configure(EntityTypeBuilder<ProntoPago> builder)
        {
            builder.ToTable("ProntoPago");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50);
            builder.Property(x => x.PorcentajeDescuento).HasPrecision(13, 4);
        }
    }
}
