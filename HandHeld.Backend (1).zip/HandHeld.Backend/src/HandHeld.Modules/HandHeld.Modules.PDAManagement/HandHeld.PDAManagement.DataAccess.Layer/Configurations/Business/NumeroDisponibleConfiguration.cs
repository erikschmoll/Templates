﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class NumeroDisponibleConfiguration : IEntityTypeConfiguration<NumeroDisponible>
    {
        public void Configure(EntityTypeBuilder<NumeroDisponible> builder)
        {
            builder.ToTable("NumeroDisponible");
            builder.HasKey(x => new
            {
                x.NumeroDisp,
                x.IdViaje,
                x.IdTipoDocumento
            });
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.IdTipoDocumento).HasMaxLength(50);
            builder.Property(x => x.IdBoca).HasMaxLength(50).IsRequired(false);
            builder.Property(x => x.Serie).HasMaxLength(50);
            builder.Property(x => x.NumeroDisp).HasPrecision(13,0);
            builder.HasOne(x => x.Boca).WithMany().HasForeignKey(x => x.IdBoca);
            builder.HasOne(x => x.Numerador).WithMany().HasForeignKey(x => new
            {
                x.IdTipoDocumento,
                x.IdViaje
            });
        }
    }
}
