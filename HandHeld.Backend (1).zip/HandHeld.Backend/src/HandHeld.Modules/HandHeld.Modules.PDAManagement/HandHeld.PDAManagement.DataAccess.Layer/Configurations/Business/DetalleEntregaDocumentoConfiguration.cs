﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class DetalleEntregaDocumentoConfiguration : IEntityTypeConfiguration<DetalleEntregaDocumento>
    {
        public void Configure(EntityTypeBuilder<DetalleEntregaDocumento> builder)
        {
            builder.ToTable("DetalleEntregaDocumento");
            builder.HasKey(x => new
            {
                x.IdViaje,
                x.IdEntrega,
                x.IdDocumento
            });
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.HasOne(x => x.Documento).WithMany().HasForeignKey(x => new
            {
                x.IdDocumento,
                x.IdViaje
            });
            builder.HasOne(x => x.Entrega).WithMany().HasForeignKey(x => new
            {
                x.IdEntrega,
                x.IdViaje
            });
        }
    }
}
