﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class FacturaConfiguration : IEntityTypeConfiguration<Factura>
    {
        public void Configure(EntityTypeBuilder<Factura> builder)
        {
            builder.ToTable("Factura");
            builder.HasKey(x => new
            {
                x.Id,
                x.IdViaje
            });
            builder.Property(x => x.Id).HasMaxLength(50);
            builder.Property(x => x.Serie).HasMaxLength(50);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.IdBoca).HasMaxLength(50);
            builder.Property(x => x.Numero).HasPrecision(13, 0);
            builder.Property(x => x.BonificacionProntoPago).HasPrecision(13, 4);
            builder.Property(x => x.InteresSegundoVencimiento).HasPrecision(13, 4);
            builder.Property(x => x.MontoNeto).HasPrecision(13, 4);
            builder.Property(x => x.MontoTotal).HasPrecision(13, 4);
            builder.HasOne(x => x.GeoPosicion).WithMany().HasForeignKey(x => x.IdGeoPosicion);
            builder.HasOne(x => x.Boca).WithMany().HasForeignKey(x => x.IdBoca);
            builder.HasOne(x => x.Documento).WithMany().HasForeignKey(x => new
            {
                x.Id,
                x.IdViaje
            });
            builder.HasOne(x => x.Entrega).WithMany().HasForeignKey(x => new
            {
                x.IdEntrega,
                x.IdViaje
            });
        }
    }
}
