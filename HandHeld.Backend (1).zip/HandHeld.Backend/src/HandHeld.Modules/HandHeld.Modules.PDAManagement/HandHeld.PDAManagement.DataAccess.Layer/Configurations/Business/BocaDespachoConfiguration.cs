﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class BocaDespachoConfiguration : IEntityTypeConfiguration<BocaDespacho>
    {
        public void Configure(EntityTypeBuilder<BocaDespacho> builder)
        {
            builder.ToTable("BocaDespacho");
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).HasMaxLength(50);
            builder.Property(x => x.Nombre).HasMaxLength(50);
            builder.Property(x => x.IdProveedor).HasMaxLength(50);
            builder.HasOne(x => x.Proveedor).WithMany().HasForeignKey(x => x.IdProveedor);
        }
    }
}
