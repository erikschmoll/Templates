﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class _BaseDeDatosConfiguration : IEntityTypeConfiguration<_BaseDeDatos>
    {
        public void Configure(EntityTypeBuilder<_BaseDeDatos> builder)
        {
            builder.ToTable("_BaseDeDatos");
            builder.HasKey(x => x.Id).HasName("PK_BASE_DE_DATOS_ID");
            builder.Property(x => x.Id).HasMaxLength(50).IsRequired();
            builder.Property(x => x.Nombre).HasMaxLength(50).IsRequired();
        }
    }
}