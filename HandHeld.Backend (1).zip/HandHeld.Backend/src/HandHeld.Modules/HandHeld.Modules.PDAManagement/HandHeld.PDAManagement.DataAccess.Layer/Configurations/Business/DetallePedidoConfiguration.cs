﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class DetallePedidoConfiguration : IEntityTypeConfiguration<DetallePedido>
    {
        public void Configure(EntityTypeBuilder<DetallePedido> builder)
        {
            builder.ToTable("DetallePedido");
            builder.HasKey(x => new
            {
                x.IdViaje,
                x.IdPedido,
                x.IdArticulo
            });
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.IdPedido).HasMaxLength(50);
            builder.Property(x => x.IdArticulo).HasMaxLength(50);
            builder.Property(x => x.IdUnidadCantidad).HasMaxLength(50);
            builder.Property(x => x.IdUnidadPrecioUnitario).HasMaxLength(50);
            builder.Property(x => x.Cantidad).HasPrecision(13,4);
            builder.Property(x => x.PrecioUnitario).HasPrecision(13,4);
            builder.HasOne(x => x.UnidadPrecioUnitario).WithMany().HasForeignKey(x => x.IdUnidadPrecioUnitario);
            builder.HasOne(x => x.UnidadCantidad).WithMany().HasForeignKey(x => x.IdUnidadCantidad);
            builder.HasOne(x => x.Articulo).WithMany().HasForeignKey(x => x.IdArticulo);
            builder.HasOne(x => x.Pedido).WithMany().HasForeignKey(x => new
            {
                x.IdPedido,
                x.IdViaje
            });
        }
    }
}
