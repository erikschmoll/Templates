﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class ReciboConfiguration : IEntityTypeConfiguration<Recibo>
    {
        public void Configure(EntityTypeBuilder<Recibo> builder)
        {
            builder.ToTable("Recibo");
            builder.HasKey(x => new
            {
                x.Id,
                x.IdViaje
            });
            builder.Property(x => x.Serie).HasMaxLength(50);
            builder.Property(x => x.IdUnidadImporte).HasMaxLength(50);
            builder.Property(x => x.IdBoca).HasMaxLength(50);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.Numero).HasPrecision(13,0);
            builder.Property(x => x.Importe).HasPrecision(13,4);
            builder.HasOne(x => x.UnidadImporte).WithMany().HasForeignKey(x => x.IdUnidadImporte);
            builder.HasOne(x => x.Boca).WithMany().HasForeignKey(x => x.IdBoca);
            builder.HasOne(x => x.GeoPosicion).WithMany().HasForeignKey(x => x.IdGeoPosicion);
            builder.HasOne(x => x.Documento).WithMany().HasForeignKey(x => new
            {
                x.Id,
                x.IdViaje
            });
        }
    }
}
