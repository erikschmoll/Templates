﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business
{
    internal class DetalleMovimientoStockConfiguration : IEntityTypeConfiguration<DetalleMovimientoStock>
    {
        public void Configure(EntityTypeBuilder<DetalleMovimientoStock> builder)
        {
            builder.ToTable("DetalleMovimientoStock");
            builder.HasKey(x => new
            {
                x.IdMovimiento,
                x.IdArticulo,
                x.IdViaje
            });
            builder.Property(x => x.IdArticulo).HasMaxLength(50);
            builder.Property(x => x.IdUnidad).HasMaxLength(50);
            builder.Property(x => x.IdViaje).HasMaxLength(50);
            builder.Property(x => x.Cantidad).HasPrecision(13,4);
            builder.Property(x => x.Densidad).HasPrecision(13,4);
            builder.HasOne(x => x.Unidad).WithMany().HasForeignKey(x => x.IdUnidad);
            builder.HasOne(x => x.Articulo).WithMany().HasForeignKey(x => x.IdArticulo);
            builder.HasOne(x => x.MovimientoStock).WithMany().HasForeignKey(x => new
            {
                x.IdMovimiento,
                x.IdViaje
            });
        }
    }
}
