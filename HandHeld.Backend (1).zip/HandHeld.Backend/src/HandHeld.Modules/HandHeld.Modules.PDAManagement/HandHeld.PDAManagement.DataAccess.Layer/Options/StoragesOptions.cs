﻿
namespace HandHeld.PDAManagement.DataAccess.Layer.Options
{
    public class StoragesOptions
    {
        public static string Key = "Storages";
        public string? Name { get; set; }
        public string? Apikey { get; set; }
        public string? Container { get; set; }
        public string? User { get; set; }
        public string? PasswordEncoding { get; set; }
        public string? TemporaryDirectory { get; set; }
    }
}
