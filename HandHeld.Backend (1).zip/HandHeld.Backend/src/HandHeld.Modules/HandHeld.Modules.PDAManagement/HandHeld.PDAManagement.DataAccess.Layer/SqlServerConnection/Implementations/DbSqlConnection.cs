﻿using HandHeld.PDAManagement.DataAccess.Layer.SqlServerConnection.Interfaces;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDAManagement.DataAccess.Layer.SqlServerConnection.Implementations
{
    public class DbSqlConnection : IDbSqlConnection
    {
        public IConfiguration _config;

        private readonly SqlConnection _connection;
        public DbSqlConnection(IConfiguration config)
        {
            _config = config;
            _connection = new SqlConnection(_config.GetConnectionString("YPFGas_HH"));
        }

        public SqlConnection Connect() => _connection;
    }
}
