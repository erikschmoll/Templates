﻿using AutoMapper;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Base;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.YPFGas;
using HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Interfaces;
using System.Data;

namespace HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Implementations
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly HandHeldDbContext _context;

        private readonly IHttpClientFactory _httpClientFactory;

        private readonly IMapper _mapper;

        private readonly IUnitOfWorkDapper _getDataService;

        public UnitOfWork(HandHeldDbContext context, IMapper mapper, IHttpClientFactory httpClientFactory, IUnitOfWorkDapper getDataService)
        {
            _context = context;
            _mapper = mapper;
            _httpClientFactory = httpClientFactory;
            _getDataService = getDataService;

        }

        public IActualizacionRepository actualizacion => new ActualizacionRepository(_mapper,_context,_httpClientFactory,_getDataService);

        public void Dispose()
        {
            _context.Dispose();
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }

        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}
