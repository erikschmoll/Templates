﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.YPFGas;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.YPFGas;
using HandHeld.PDAManagement.DataAccess.Layer.SqlServerConnection.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Interfaces;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Implementations
{
    public class UnitOfWorkDapper : IUnitOfWorkDapper
    {
        private readonly SqlConnection _connection;
        private IDbTransaction _transaction;


        public UnitOfWorkDapper(IDbSqlConnection connection)
        {
            _connection = connection.Connect();
            if (_connection.State != ConnectionState.Open)
            {
                _connection.Open();
            }
            _transaction = _connection.BeginTransaction();
        }

        public void Commit()
        {
            _transaction.Commit();
            _transaction.Dispose();
            _transaction = _connection.BeginTransaction();
        }

        public void Dispose()
        {
            if (_transaction != null)
            {
                _transaction.Dispose();
            }
        }

        public void Rollback()
        {
            _transaction.Rollback();
            _transaction.Dispose();
            _transaction = _connection.BeginTransaction();
        }

        public IDbConnection Connection { get{ return _connection; } }

        public IDbTransaction Transaccion { get { return _transaction; } }

        public IGetDataServices getDataServices => new GetDataServices(_connection, _transaction);

        public IYPFGas_Repository<Planta> _planta => new YPFGas_Repository<Planta>(_connection,_transaction);

        public IYPFGas_Repository<Patente> _patente => new YPFGas_Repository<Patente>(_connection, _transaction);

        public IYPFGas_Repository<Pais> _pais => new YPFGas_Repository<Pais>(_connection,_transaction);

        public IYPFGas_Repository<Impuesto> _impuesto => new YPFGas_Repository<Impuesto>(_connection,_transaction);

        public IYPFGas_Repository<ProntoPago> _prontoPago => new YPFGas_Repository<ProntoPago>(_connection,_transaction);

        public IYPFGas_Repository<TipoOperacion> _tipoOperacion => new YPFGas_Repository<TipoOperacion>(_connection,_transaction);

        public IYPFGas_Repository<Usuario> _usuario => new YPFGas_Repository<Usuario>(_connection,_transaction);

        public IYPFGas_Repository<CategoriaSegunFisco> _categoriaSegunFisco => new YPFGas_Repository<CategoriaSegunFisco>(_connection,_transaction);

        public IYPFGas_Repository<Negocio> _negocio => new YPFGas_Repository<Negocio>(_connection,_transaction);

        public IYPFGas_Repository<RegionComercial> _regionComercial => new YPFGas_Repository<RegionComercial>(_connection,_transaction);

        public IYPFGas_Repository<Unidad> _unidad => new YPFGas_Repository<Unidad>(_connection,_transaction);

        public IYPFGas_Repository<Articulo> _articulo => new YPFGas_Repository<Articulo>(_connection,_transaction);

        public IYPFGas_Repository<Sucursal> _sucursal => new YPFGas_Repository<Sucursal>(_connection,_transaction);

        public IYPFGas_Repository<Banco> _banco => new YPFGas_Repository<Banco>(_connection,_transaction);

        public IYPFGas_Repository<Zona> _zona => new YPFGas_Repository<Zona>(_connection,_transaction);

        public IYPFGas_Repository<ViaDePago> _viaDePago => new YPFGas_Repository<ViaDePago>(_connection,_transaction);

        public IYPFGas_Repository<Boca> _boca => new YPFGas_Repository<Boca>(_connection,_transaction);

        public IYPFGas_Repository<ImpuestoBoca> _impuestoBoca => new YPFGas_Repository<ImpuestoBoca>(_connection,_transaction);

        public IYPFGas_Repository<Titular> _titular => new YPFGas_Repository<Titular>(_connection,_transaction);

        public IYPFGas_Repository<Tanque> _tanque => new YPFGas_Repository<Tanque>(_connection,_transaction);

        public IYPFGas_Repository<Precio> _precio => new YPFGas_Repository<Precio>(_connection,_transaction);

        public IYPFGas_Repository<TipoRazonDeNoAbastecido> _tipoRazonDeNoAbastecido => new YPFGas_Repository<TipoRazonDeNoAbastecido>(_connection,_transaction);

        public IYPFGas_Repository<TipoPedido> _tipoPedido => new YPFGas_Repository<TipoPedido>(_connection,_transaction);

        public IYPFGas_Repository<TipoIncidencia> _tipoIncidencia => new YPFGas_Repository<TipoIncidencia>(_connection,_transaction);

        public IYPFGas_Repository<EstadoArticulo> _estadoArticulo => new YPFGas_Repository<EstadoArticulo>(_connection,_transaction);

        public IYPFGas_Repository<MotivoEntrega> _motivoEntrega => new YPFGas_Repository<MotivoEntrega>(_connection,_transaction);

        public IYPFGas_Repository<TipoDeViaje> _tipoDeViaje => new YPFGas_Repository<TipoDeViaje>(_connection,_transaction);

        public IYPFGas_Repository<TipoDocumento> _tipoDocumento => new YPFGas_Repository<TipoDocumento>(_connection,_transaction);

        public IYPFGas_Repository<Proveedor> _proveedor => new YPFGas_Repository<Proveedor>(_connection,_transaction);

        public IYPFGas_Repository<Almacen> _almacen => new YPFGas_Repository<Almacen>(_connection,_transaction);

        public IYPFGas_Repository<BocaDespacho> _bocaDespacho => new YPFGas_Repository<BocaDespacho>(_connection,_transaction);

        public IYPFGas_Repository<Pantalla> _pantalla => new YPFGas_Repository<Pantalla>(_connection,_transaction);

        public IYPFGas_Repository<Proceso> _proceso => new YPFGas_Repository<Proceso>(_connection,_transaction);

        public IYPFGas_Repository<Parametro> _parametro => new YPFGas_Repository<Parametro>(_connection,_transaction);

        public IYPFGas_Repository<PDA> _pda => new YPFGas_Repository<PDA>(_connection,_transaction);

        public IYPFGas_Repository<dynamic> _dynamic => new YPFGas_Repository<dynamic>(_connection, _transaction);
    }
}
