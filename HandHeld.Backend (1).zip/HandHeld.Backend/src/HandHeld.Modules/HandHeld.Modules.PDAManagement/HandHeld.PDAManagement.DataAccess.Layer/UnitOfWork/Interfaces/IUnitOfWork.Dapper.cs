﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.YPFGas;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Interfaces
{
    public interface IUnitOfWorkDapper : IDisposable
    {
        public IYPFGas_Repository<dynamic> _dynamic { get; }
        public IYPFGas_Repository<Planta> _planta { get; }
        public IYPFGas_Repository<Patente> _patente {get;}
        public IYPFGas_Repository<Pais> _pais {get;}
        public IYPFGas_Repository<Impuesto> _impuesto {get;}
        public IYPFGas_Repository<ProntoPago> _prontoPago {get;}
        public IYPFGas_Repository<TipoOperacion> _tipoOperacion {get;}
        public IYPFGas_Repository<Usuario> _usuario {get;}
        public IYPFGas_Repository<CategoriaSegunFisco> _categoriaSegunFisco {get;}
        public IYPFGas_Repository<Negocio> _negocio { get; }
        public IYPFGas_Repository<RegionComercial> _regionComercial {get;}
        public IYPFGas_Repository<Unidad> _unidad {get;}
        public IYPFGas_Repository<Articulo> _articulo {get;}
        public IYPFGas_Repository<Sucursal> _sucursal {get;}
        public IYPFGas_Repository<Banco> _banco {get;}
        public IYPFGas_Repository<Zona> _zona {get;}
        public IYPFGas_Repository<ViaDePago> _viaDePago {get;}
        public IYPFGas_Repository<Boca> _boca {get;}
        public IYPFGas_Repository<ImpuestoBoca> _impuestoBoca {get;}
        public IYPFGas_Repository<Titular> _titular {get;}
        public IYPFGas_Repository<Tanque> _tanque {get;}
        public IYPFGas_Repository<Precio> _precio {get;}
        public IYPFGas_Repository<TipoRazonDeNoAbastecido> _tipoRazonDeNoAbastecido {get;}
        public IYPFGas_Repository<TipoPedido> _tipoPedido {get;}
        public IYPFGas_Repository<TipoIncidencia> _tipoIncidencia {get;}
        public IYPFGas_Repository<EstadoArticulo> _estadoArticulo {get;}
        public IYPFGas_Repository<MotivoEntrega> _motivoEntrega {get;}
        public IYPFGas_Repository<TipoDeViaje> _tipoDeViaje {get;}
        public IYPFGas_Repository<TipoDocumento> _tipoDocumento {get;}
        public IYPFGas_Repository<Proveedor> _proveedor {get;}
        public IYPFGas_Repository<Almacen> _almacen {get;}
        public IYPFGas_Repository<BocaDespacho> _bocaDespacho {get;}
        public IYPFGas_Repository<Pantalla> _pantalla {get;}
        public IYPFGas_Repository<Proceso> _proceso {get;}
        public IYPFGas_Repository<Parametro> _parametro {get;}
        public IYPFGas_Repository<PDA> _pda {get;}
        public IGetDataServices getDataServices { get; }

        IDbConnection Connection { get; } 
        IDbTransaction Transaccion { get; }

        void Commit();
        void Rollback();
    }
}
