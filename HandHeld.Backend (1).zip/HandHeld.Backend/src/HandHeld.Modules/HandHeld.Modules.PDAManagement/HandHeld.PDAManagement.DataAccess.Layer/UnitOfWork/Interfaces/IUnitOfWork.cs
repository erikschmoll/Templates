﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core;

namespace HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        public IActualizacionRepository actualizacion { get; }

        void SaveChanges();

        Task SaveChangesAsync();
    }
}
