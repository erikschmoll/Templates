﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Base;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Core
{
    public class ConfiguracionRepository : ReadRepository<Configuracion>, IConfiguracionRepository
    {
        private List<Configuracion> _parametros;
        public ConfiguracionRepository(HandHeldDbContext context) : base(context)
        {
            _parametros = new List<Configuracion>();
            cargar();
        }
        public int ValorEntero32(string id)
        {
            return Convert.ToInt32(registro(id).Valor);
        }
        public long ValorEntero64(string id)
        {
            return Convert.ToInt64(registro(id).Valor);
        }
        public DateTimeOffset ValorFechaUTC(string id)
        {
            return Convert.ToDateTime(registro(id).Valor);
        }
        public string Valor(string id)
        {
            return registro(id).Valor;
        }
        private void cargar()
        {
            _parametros = GetAll().Where(c => !c.Del).ToList();
        }
        private Configuracion registro(string id)
        {
            Configuracion? configuracion = _parametros.Where(p => p.Id.Equals(id)).FirstOrDefault();
            if (configuracion is null)
            {
                throw new Exception($"La clave de configuracion no existe. {id}");
            }
            return configuracion;
        }
    }
}
