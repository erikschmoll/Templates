﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockMenuRepository : _MockRepository<Menu>
    {
        public MockMenuRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
