﻿using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core;
using HandHeld.Shared.Infrastructure.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Core
{
    public class ColaPendientesRepository : IColaPendientesRepository
    {
        private bool _ocupado;
        private readonly IConfiguration _config;
        private readonly IIdentityService _identityService;
        private readonly ILogger<ColaPendientesRepository> _logger;
        public ColaPendientesRepository(IConfiguration configuration,
            IIdentityService identityService,
            ILogger<ColaPendientesRepository> logger)
        {
            _ocupado = false;
            _config = configuration;
            _identityService = identityService;
            _logger = logger;
        }
        public IEnumerable<Actualizacion> GetPendientesConTope()
        {
            IEnumerable<Actualizacion> actualizacionesPendientes = new List<Actualizacion>();
            try
            {
                if (!_ocupado)
                {
                    _ocupado = true;
                    using (var dbContext = crearDbContext())
                    {
                        int maxDePedidosAProcesar = obtenerMaxDePedidosAProcesar(dbContext);
                        actualizacionesPendientes = dbContext.Set<Actualizacion>().Where(a =>
                        a.IdEstado.Equals(EstadoActualizacion.PENDIENTE)
                        && !a.Del).Take(maxDePedidosAProcesar).ToList();
                        if (actualizacionesPendientes.Any())
                        {
                            foreach (var actualizacionPendiente in actualizacionesPendientes)
                            {
                                actualizacionPendiente.IdEstado = EstadoActualizacion.PROCESANDO;
                            }
                            dbContext.Set<Actualizacion>().UpdateRange(actualizacionesPendientes);
                            dbContext.SaveChanges();
                        }
                    }
                }
                else
                {
                    _logger.LogTrace("Cola ocupada.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            finally
            {
                _ocupado = false;
            }
            return actualizacionesPendientes;
        }
        private int obtenerMaxDePedidosAProcesar(HandHeldDbContext dbContext)
        {
            Configuracion? config = dbContext.Set<Configuracion>()
                .Where(c => c.Id.Equals("cape"))
                .FirstOrDefault();
            if(config is null)
            {
                return Configuracion.MAX_PEDIDOS_PROCESAR;
            }
            return Convert.ToInt32(config.Valor);
        }
        private HandHeldDbContext crearDbContext()
        {
            string connectionString = _config.GetConnectionString("Default");
            var optionsBuilder = new DbContextOptionsBuilder<HandHeldDbContext>();
            optionsBuilder.UseSqlServer(connectionString);
            HandHeldDbContext dbContext = new HandHeldDbContext(optionsBuilder.Options, _identityService);
            dbContext.Database.EnsureCreated();
            return dbContext;
        }
    }
}
