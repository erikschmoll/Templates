﻿using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockArticuloRepository : _MockRepository<Articulo>
    {
        public MockArticuloRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
