﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockFactorDeConversionRepository : _MockRepository<FactorDeConversion>
    {
        public MockFactorDeConversionRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
