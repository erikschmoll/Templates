﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockImpuestoBocaRepository : _MockRepository<ImpuestoBoca>
    {
        public MockImpuestoBocaRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
