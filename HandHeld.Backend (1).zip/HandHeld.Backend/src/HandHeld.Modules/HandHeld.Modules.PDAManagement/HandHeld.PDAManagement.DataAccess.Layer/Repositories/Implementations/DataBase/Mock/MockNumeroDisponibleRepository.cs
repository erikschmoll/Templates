﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockNumeroDisponibleRepository : _MockRepository<NumeroDisponible>
    {
        public MockNumeroDisponibleRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
