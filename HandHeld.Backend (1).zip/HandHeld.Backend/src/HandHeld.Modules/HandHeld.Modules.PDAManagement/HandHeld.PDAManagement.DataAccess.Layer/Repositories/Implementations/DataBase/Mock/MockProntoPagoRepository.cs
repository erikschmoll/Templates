﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockProntoPagoRepository : _MockRepository<ProntoPago>
    {
        public MockProntoPagoRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
