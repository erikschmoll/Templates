﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockPatenteRepository : _MockRepository<Patente>
    {
        public MockPatenteRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
