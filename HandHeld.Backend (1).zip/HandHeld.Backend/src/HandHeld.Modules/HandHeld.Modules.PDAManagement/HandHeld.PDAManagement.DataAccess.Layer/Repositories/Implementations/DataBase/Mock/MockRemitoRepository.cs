﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockRemitoRepository : _MockRepository<Remito>
    {
        public MockRemitoRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
