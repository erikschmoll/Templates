﻿using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockAlmacenRepository : _MockRepository<Almacen>
    {
        public MockAlmacenRepository(HandHeldSdfDbContext context) : base(context)
        {
        }
    }
}
