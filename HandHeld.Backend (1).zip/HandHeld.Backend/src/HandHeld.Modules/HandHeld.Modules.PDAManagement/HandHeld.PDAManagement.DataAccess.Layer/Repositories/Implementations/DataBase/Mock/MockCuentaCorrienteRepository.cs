﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockCuentaCorrienteRepository : _MockRepository<CuentaCorriente>
    {
        public MockCuentaCorrienteRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
