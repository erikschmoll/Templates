﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockDetalleCobranzaRepository : _MockRepository<DetalleCobranza>
    {
        public MockDetalleCobranzaRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
