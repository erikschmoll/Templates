﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockMotivoEntregaRepository : _MockRepository<MotivoEntrega>
    {
        public MockMotivoEntregaRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
