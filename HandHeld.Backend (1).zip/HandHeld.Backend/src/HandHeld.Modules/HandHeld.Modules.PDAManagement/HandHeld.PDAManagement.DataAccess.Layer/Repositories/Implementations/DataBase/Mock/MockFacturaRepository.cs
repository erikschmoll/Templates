﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockFacturaRepository : _MockRepository<Factura>
    {
        public MockFacturaRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
