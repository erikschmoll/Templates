﻿using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Base;
using Microsoft.EntityFrameworkCore;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;
using HandHeld.PDAManagement.DataAccess.Layer.Models;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Base
{
    public abstract class ReadRepository<T> : IReadRepository<T> where T : Auditoria
    {
        protected readonly HandHeldDbContext _context;
        private readonly DbSet<T> _dbSet;
        public ReadRepository(HandHeldDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }
        public virtual T Get(object id)
        {
            return _dbSet.Where(t => t.Id.Equals(id)).Single();
        }

        public virtual IEnumerable<T> GetAll()
        {
            return _dbSet.ToList();
        }

        public virtual async Task<IEnumerable<T>> GetAllAsync()
        {
            return await _dbSet.ToListAsync();
        }

        public virtual async Task<T> GetAsync(int id)
        {
            return await _dbSet.FirstAsync(t => t.Id.Equals(id.ToString()));
        }
    }
}
