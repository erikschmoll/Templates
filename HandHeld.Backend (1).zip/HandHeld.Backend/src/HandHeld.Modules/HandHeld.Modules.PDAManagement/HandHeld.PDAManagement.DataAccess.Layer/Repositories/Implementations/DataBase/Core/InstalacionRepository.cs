﻿using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Base;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Core
{
    internal class InstalacionRepository : WriteRepository<Instalacion>, IInstalacionRepository
    {
        private readonly IConfiguracionRepository _configuracionRepository;
        public InstalacionRepository(HandHeldDbContext context, IConfiguracionRepository configuracionRepository) : base(context)
        {
            _configuracionRepository = configuracionRepository;
        }

        public int CantDeInstalaciones(string IdActualizacion, int nroActualizacion)
        {
            return _context.Instalaciones.Count(x => x.IdActualizacion.Equals(IdActualizacion)
            && x.NroActualizacionUsado.Equals(nroActualizacion));
        }
    }
}