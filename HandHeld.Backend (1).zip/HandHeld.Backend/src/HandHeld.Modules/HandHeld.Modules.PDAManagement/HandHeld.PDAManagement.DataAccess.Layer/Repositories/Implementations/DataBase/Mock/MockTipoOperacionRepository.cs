﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockTipoOperacionRepository : _MockRepository<TipoOperacion>
    {
        public MockTipoOperacionRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
