﻿using Firebase.Auth;
using Firebase.Storage;
using HandHeld.PDAManagement.DataAccess.Layer.Options;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.WebServices;
using HandHeld.PDAManagement.DataAccess.Layer.Utilities;
using Microsoft.Extensions.Options;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.WebServices
{
    public class StorageService //: IStorageService
    {
        private readonly StoragesOptions _storagesOptions;
        public StorageService(IOptions<StoragesOptions> sharedOptions)
        {
            _storagesOptions = sharedOptions.Value;
        }

        public async Task<string> PushToStorage(string path, string fileName)
        {
            //TODO: encodear la psw
            var stream = File.Open($"{path}\\{fileName}", FileMode.Open);
            string url = string.Empty;
            try
            {
                FirebaseAuthProvider firebaseAuthProvider = new FirebaseAuthProvider(new FirebaseConfig(_storagesOptions.Apikey));
                FirebaseAuthLink firebaseAuthLink = await firebaseAuthProvider.SignInWithEmailAndPasswordAsync(_storagesOptions.User, _storagesOptions.PasswordEncoding);

                CancellationTokenSource cancellationToken = new CancellationTokenSource();
                FirebaseStorageTask storageManager = new FirebaseStorage(_storagesOptions.Container,
                    new FirebaseStorageOptions
                    {
                        AuthTokenAsyncFactory = () => Task.FromResult(firebaseAuthLink.FirebaseToken),
                        ThrowOnCancel = true,
                        HttpClientTimeout = TimeSpan.FromMinutes(10)
                    })
                    .Child(fileName)
                    .PutAsync(stream, cancellationToken.Token);
                url = await storageManager;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                stream.Close();
            }
            return url;
        }
    }
}
