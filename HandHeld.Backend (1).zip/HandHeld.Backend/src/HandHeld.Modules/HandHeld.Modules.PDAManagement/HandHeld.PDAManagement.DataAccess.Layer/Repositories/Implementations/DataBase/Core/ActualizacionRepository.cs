﻿using AutoMapper;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;
using HandHeld.PDAManagement.DataAccess.Layer.Models;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Config;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Reponse;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Request;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Base;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.YPFGas;
using HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Utilities;
using HandHeld.PDAManagement.DataAccess.Layer.Utilities.OrderBy;
using HandHeld.PDAManagement.DataAccess.Layer.Utilities.OrderBy.Implementations;
using HandHeld.PDAManagement.DataAccess.Layer.Utilities.OrderBy.Interface;
using HandHeld.PDAManagement.Presentation.Layer.Models;
using HandHeld.Shared.Abstractions.Models;
using HandHeld.Shared.Infrastructure.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Linq;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Core
{
    public class ActualizacionRepository : WriteRepository<Actualizacion>, IActualizacionRepository
    {
        private readonly IHttpClientFactory _httpClientFactory;

        private readonly IMapper _mapper;

        private readonly IUnitOfWorkDapper _UnitOfWorkDapper;

        private static readonly Dictionary<string, IOrderBy> OrderActualizaciones = new()
        {
            { "chofer", new OrderByActualizaciones<string>(x => x.IdChofer) },
            { "planta",  new OrderByActualizaciones<string>(x => x.IdPlanta) },
            { "patente",   new OrderByActualizaciones<string>(x => x.IdPatente) },
            { "estado.nombre",   new OrderByActualizaciones<string>(x => x.Estado.Nombre) },
            { "version",   new OrderByActualizaciones<long?>(x => x.Version) },
            { "nroactualizacion",   new OrderByActualizaciones<long?>(x => x.NroActualizacion) },
            { "creadopor",   new OrderByActualizaciones<string>(x => x.CreadoPor) },
            { "modificadopor",   new OrderByActualizaciones<string>(x => x.ModificadoPor) },
            { "fechacreacion",   new OrderByActualizaciones<DateTimeOffset>(x => x.FechaCreacion) },
            { "fechamodificacion",   new OrderByActualizaciones<DateTimeOffset>(x => x.FechaModificacion) }
        };

        public ActualizacionRepository(IMapper mapper, HandHeldDbContext context, IHttpClientFactory httpClientFactory, IUnitOfWorkDapper UnitOfWorkDapper) : base(context)
        {
            _UnitOfWorkDapper = UnitOfWorkDapper;
            _httpClientFactory = httpClientFactory;
            _mapper = mapper;
        }

        public async Task<long> NuevaVersion(int vr, string chofer)
        {
            long version = long.Parse($"{vr}0");
            var ultimaActualizacion = await _context.Actualizaciones
                .Where(a => a.IdEstado.Equals(EstadoActualizacion.LISTO_PARA_SINCRONIZAR))
                .OrderByDescending(a => a.FechaModificacion)
                .FirstOrDefaultAsync(a => a.IdChofer.Equals(chofer))
                ;
            if (ultimaActualizacion is not null
            && ultimaActualizacion.Version is not null)
            {
                version = long.Parse($"{vr}{ultimaActualizacion.Version++}");
            }
            return version;
        }

        public async Task<Actualizacion?> GetAsync(string? chofer, int nroActualizacion)
        {
            return await _context.Actualizaciones.FirstOrDefaultAsync(a => a.IdChofer.Equals(chofer)
            && a.NroActualizacion.Equals(nroActualizacion));
        }

        public async Task<Actualizacion?> GetByIdAsync(string id, bool del)
        {
            var actualizacion = await _context.Actualizaciones.Where(x => x.Id == id && x.Del == del).Include(x => x.Estado).FirstOrDefaultAsync();
            if (actualizacion is not null)
            {
                actualizacion.Planta = _UnitOfWorkDapper.getDataServices.GetPlanta(actualizacion.IdPlanta).Result;
                _UnitOfWorkDapper.Dispose();
                actualizacion.Patente = _UnitOfWorkDapper.getDataServices.GetPatente(actualizacion.IdPatente).Result;
                _UnitOfWorkDapper.Dispose();
                var usuarios = await BuscarUsuarios("");
                var usuario = usuarios.Where(x => x.Id == actualizacion.IdChofer).FirstOrDefault();

                if (usuario != null)
                    actualizacion.Chofer = usuario;

                actualizacion.Chofer = usuario;

                return actualizacion;
            }
            throw new ShowException("La asociación no existe");
        }

        public async Task<Actualizacion> BuscarActualizacionesByIdAsync(string id)
        {
            var actualizaciones = await _context.Actualizaciones.Where(x => x.Id == id && x.Del == false).Include(x => x.Estado).FirstOrDefaultAsync();

            if (actualizaciones == null)
                throw new ShowException("No existe un registro con id " + id, 400);

            actualizaciones.Planta = _UnitOfWorkDapper.getDataServices.GetPlanta(actualizaciones.IdPlanta).Result;
            _UnitOfWorkDapper.Dispose();
            actualizaciones.Patente = _UnitOfWorkDapper.getDataServices.GetPatente(actualizaciones.IdPatente).Result;
            _UnitOfWorkDapper.Dispose();
            var usuarios = await BuscarUsuarios("");
            var usuario = usuarios.Where(x => x.Id == actualizaciones.IdChofer).FirstOrDefault();

            if (usuario != null)
                actualizaciones.Chofer = usuario;

            return actualizaciones;
        }

        public async Task<Actualizaciones?> BuscarActualizacionesPorFiltrosAsync(FiltrosBuscarActualizaciones? filtros, int limite, int pagina, string? order, string? tipoOrder)
        {
            var skip = (pagina - 1) * limite;
            IQueryable<Actualizacion> queryable = _context.Actualizaciones.AsQueryable();

            if (filtros == null)
            {
                queryable = (order != null)
                ? (tipoOrder == "desc")
                ? queryable.Include(i => i.Estado).OrderByDescending(OrderActualizaciones[order.ToLower()])
                : queryable.Include(i => i.Estado).OrderBy(OrderActualizaciones[order.ToLower()])
                : queryable.Include(i => i.Estado);
            }
            else
            {
                if (filtros.IdEstado != null)
                    queryable = queryable.Where(x => x.IdEstado == filtros.IdEstado);

                if (filtros.IdPatente != null)
                    queryable = queryable.Where(x => x.IdPatente == filtros.IdPatente);

                if (filtros.IdPlanta != null)
                    queryable = queryable.Where(x => x.IdPlanta == filtros.IdPlanta);

                if (filtros.IdChofer != null)
                    queryable = queryable.Where(x => x.IdChofer == filtros.IdChofer);

                if (filtros.Activos == true)
                    queryable = queryable.Where(x => x.Del != true);

                queryable = (order != null)
                ? (tipoOrder == "desc")
                ? queryable.Include(i => i.Estado).OrderByDescending(OrderActualizaciones[order.ToLower()])
                : queryable.Include(i => i.Estado).OrderBy(OrderActualizaciones[order.ToLower()])
                : queryable.Include(i => i.Estado);
            }

            List<Actualizacion> actualizacion = await queryable.Skip(skip).Take(limite).ToListAsync();

            foreach (var item in actualizacion)
            {
                item.Planta = _UnitOfWorkDapper.getDataServices.GetPlanta(item.IdPlanta).Result;
                _UnitOfWorkDapper.Dispose();
                item.Patente = _UnitOfWorkDapper.getDataServices.GetPatente(item.IdPatente).Result;
                _UnitOfWorkDapper.Dispose();
                var usuarios = await BuscarUsuarios("");
                var usuario = usuarios.Where(x => x.Id == item.IdChofer).FirstOrDefault();

                if (usuario != null)
                    item.Chofer = usuario;
            }

            Actualizaciones actualizaciones = new()
            {
                Total = queryable.Count(),
                Registros = actualizacion
            };

            return actualizaciones;
        }

        public string AltaActualizacionesAsync(AltaActualizaciones model)
        {
            string id = GuidUtility.NewGuid();

            Actualizacion actualizacion = new()
            {
                Id = id,
                IdPlanta = model.IdPlanta,
                IdPatente = model.IdPatente,
                IdChofer = model.IdChofer,
                Url = string.Empty,
                IdEstado = "1",
                Version = null,
                NroActualizacion = null,
                Del = false
            };

            _context.Actualizaciones.Add(actualizacion);
            return id;
        }

        public async Task BajaActualizacionesByIdAsync(string id)
        {
            Actualizacion? actualizacion = await _context.Actualizaciones.Where(x => x.Id == id && x.Del == false).FirstOrDefaultAsync();

            if (actualizacion == null)
                throw new ShowException("No existe un registro con id " + id, 400);

            if (actualizacion.IdEstado == "1")
            {
                actualizacion.Del = true;
            }
            else
            {
                actualizacion.IdEstado = "5";
            }
        }

        public async Task ModificarActualizacionAsync(string id, ModificarActualizaciones model)
        {
            Actualizacion? actializacion = await _context.Actualizaciones.Where(x => x.Id == id && x.Del == false).Include(x => x.Estado).FirstOrDefaultAsync();

            if (actializacion == null)
                throw new ShowException("No existe un registro con id " + id, 400);

            if (actializacion.IdEstado != "1")
                throw new ShowException("El rigistro con id " + id + " no puede ser editado porque esta en estado '" + actializacion.Estado.Nombre+"'", 400);

            if (actializacion.IdChofer != null && model.IdChofer != string.Empty )
                actializacion.IdChofer = model.IdChofer;

            if (model.IdPlanta != null && model.IdPlanta != string.Empty)
                actializacion.IdPlanta = model.IdPlanta;

            if (model.IdPatente != null && model.IdPatente != string.Empty)
                actializacion.IdPatente = model.IdPatente;
        }

        public HandHeldDbContext Get_context()
        {
            return _context;
        }

        public async Task BlanqueoNroActualizacion(string id)
        {
            Actualizacion? actializacion = await _context.Actualizaciones.Where(x => x.Id.Equals(id) && x.Del == false).Include(x => x.Estado).FirstOrDefaultAsync();

            if (actializacion == null)
                throw new ShowException("No existe un registro con id '" + id + "'", 400);

            if (actializacion.IdEstado != "1")
                throw new ShowException("No puedes editar un registro en estado '" + actializacion.Estado.Nombre+"'", 400);

            if (actializacion.NroActualizacion == null || actializacion.NroActualizacion.Equals(string.Empty))
                throw new ShowException("Este registro no tiene asignado un Nro de actualización aún.", 400);

            var pin = Generator.PIN();

            actializacion.NroActualizacion = pin;

        }

        public Task<IEnumerable<Usuarios>> BuscarUsuarios(string? patron)
        {
            //var client = _httpClientFactory.CreateClient("usuarios");
            //string? uri = (patron == null || patron == string.Empty) ? client.BaseAddress?.ToString() : client.BaseAddress?.ToString() + "?patron=" + patron;
            //client.BaseAddress = new Uri(uri);
            //var response = await client.GetAsync("");
            //var usuarios = JsonConvert.DeserializeObject<IEnumerable<Usuarios>>(await response.Content.ReadAsStringAsync());
            //if (usuarios is not null)
            //{
            //    //TODO: Johan filtro los resultados random
            //    usuarios = usuarios.Where(item => item.nombres.IndexOf(patron, StringComparison.OrdinalIgnoreCase) >= 0);
            //}

            //mock
            IEnumerable<Usuarios> usuarios = new List<Usuarios>()
            {
                new(){
                    Id = "1766",
                    Apellidos = "MONTERO",
                    Nombres = "GUSTAVO",
                    Del = false,
                    Dni = "85693650",
                    Pin = 123456,
                    CreadoPor ="Admin",
                    ModificadoPor ="Admin",
                    FechaCreacion = DateTimeOffset.Now,
                    fechaDeExpiracion = DateTimeOffset.Now,
                    FechaModificacion = DateTimeOffset.Now

                },
                new()
                {
                    Id="1767",
                    Apellidos = "ABREGU",
                    Nombres = "PABLO",
                    Del = false,
                    Dni = "85693651",
                    Pin = 123456,
                    CreadoPor ="Admin",
                    ModificadoPor ="Admin",
                    FechaCreacion = DateTimeOffset.Now,
                    fechaDeExpiracion = DateTimeOffset.Now,
                    FechaModificacion = DateTimeOffset.Now
                },
                new(){
                    Id="1768",
                    Apellidos = "RIEDEL",
                    Nombres = "GUILLERMO",
                    Del = false,
                    Dni = "85693652",
                    Pin = 123456,
                    CreadoPor ="Admin",
                    ModificadoPor ="Admin",
                    FechaCreacion = DateTimeOffset.Now,
                    fechaDeExpiracion = DateTimeOffset.Now,
                    FechaModificacion = DateTimeOffset.Now
                },
                new()
                {
                    Id="1769",
                    Apellidos = "CARDOSO",
                    Nombres = "LUIS",
                    Del = false,
                    Dni = "85693653",
                    Pin = 123456,
                    CreadoPor ="Admin",
                    ModificadoPor ="Admin",
                    FechaCreacion = DateTimeOffset.Now,
                    fechaDeExpiracion = DateTimeOffset.Now,
                    FechaModificacion = DateTimeOffset.Now
                },
                new()
                {
                    Id="1807",
                    Apellidos = "SERGIO",
                    Nombres = "SERGIO",
                    Del = false,
                    Dni = "85693654",
                    Pin = 123456,
                    CreadoPor ="Admin",
                    ModificadoPor ="Admin",
                    FechaCreacion = DateTimeOffset.Now,
                    fechaDeExpiracion = DateTimeOffset.Now,
                    FechaModificacion = DateTimeOffset.Now
                }
            };

            return Task.Run(async () => (patron != null) ? usuarios.Where(x => x.Nombres.Contains(patron)) : usuarios);
        }

        public async Task<IEnumerable<dynamic>?> BuscarPlantas()
        {
            string fieldsAndFrom = "SELECT IDSitio, Sitio FROM Sitio";
            return await _UnitOfWorkDapper._dynamic.GetDataDynamicByPattern(fieldsAndFrom,
                 null,
                 orderBy: "Sitio");
        }

        public async Task<IEnumerable<dynamic>?> BuscarPatentes(string? patron)
        {
            string fieldsAndFrom = "SELECT TOP 10 IDVehiculo, Patente FROM Vehiculo";
            List<Filtro> filtros = new()
            {
                new Igual("Activo", 1),
                new Igual("IDTipoVehiculo", "Q")
            };
            if (patron != null)
            {
                filtros.Add(new Coincidencia("Patente", patron));
            }
            return await _UnitOfWorkDapper._dynamic.GetDataDynamicByPattern(fieldsAndFrom,
                filtros,
                orderBy: "Patente");
        }

        public async Task<IEnumerable<EstadoActualizacionDto>> BuscarEstados()
        {
            var estados = await _context.EstadosActualizacion.ToListAsync();

            if (estados == null)
                throw new ShowException("No existen registros en la tabla estados ", 400);

            var estadosDto = _mapper.Map<IEnumerable<EstadoActualizacion>, IEnumerable<EstadoActualizacionDto>>(estados);

            return estadosDto;
        }
    }
}
