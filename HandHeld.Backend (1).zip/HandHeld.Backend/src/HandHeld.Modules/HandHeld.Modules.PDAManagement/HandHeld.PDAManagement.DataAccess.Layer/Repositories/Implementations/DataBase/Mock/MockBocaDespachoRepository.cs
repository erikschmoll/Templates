﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockBocaDespachoRepository : _MockRepository<BocaDespacho>
    {
        public MockBocaDespachoRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
