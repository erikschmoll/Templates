﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockViajeRepository : _MockRepository<Viaje>
    {
        public MockViajeRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
