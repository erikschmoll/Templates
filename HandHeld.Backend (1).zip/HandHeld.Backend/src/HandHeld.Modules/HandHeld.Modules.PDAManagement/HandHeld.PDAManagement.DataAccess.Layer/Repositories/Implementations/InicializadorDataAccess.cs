﻿using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.YPFGas;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.YPFGas;
using HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Interfaces;
using System.Reflection.Metadata;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations
{
    public class InicializadorDataAccess : IInicializadorDataAccess
    {
        private HandHeldSQLiteDbContext? _handHeldSQLiteDbContext = null;
        private readonly HandHeldSQLiteDbContextFactory _handHeldSQLiteDbContextFactory;

        #region Declarations/MockRepository
        private readonly MockAlmacenRepository _mockAlmacenRepository;
        private readonly MockArticuloRepository _mockArticuloRepository;
        private readonly MockBancoRepository _mockBancoRepository;
        private readonly MockBocaDespachoRepository _mockBocaDespachoRepository;
        private readonly MockBocaRepository _mockBocaRepository;
        private readonly MockCategoriaSegunFiscoRepository _mockCategoriaSegunFiscoRepository;
        private readonly MockCobranzaRepository _mockCobranzaRepository;
        private readonly MockCuentaCorrienteRepository _mockCuentaCorrienteRepository;
        private readonly MockDespachoRepository _mockDespachoRepository;
        private readonly MockDetalleAplicacionReciboRepository _mockDetalleAplicacionReciboRepository;
        private readonly MockDetalleCobranzaRepository _mockDetalleCobranzaRepository;
        private readonly MockDetalleEntregaDocumentoRepository _mockDetalleEntregaDocumentoRepository;
        private readonly MockDetalleEntregaRepository _mockDetalleEntregaRepository;
        private readonly MockDetalleEntregaTanqueRepository _mockDetalleEntregaTanqueRepository;
        private readonly MockDetalleFacturaRepository _mockDetalleFacturaRepository;
        private readonly MockDetalleMovimientoStockRepository _mockDetalleMovimientoStockRepository;
        private readonly MockDetallePedidoRepository _mockDetallePedidoRepository;
        private readonly MockDetalleRemitoRepository _mockDetalleRemitoRepository;
        private readonly MockDocumentoAnuladoRepository _mockDocumentoAnuladoRepository;
        private readonly MockDocumentoRepository _mockDocumentoRepository;
        private readonly MockEntregaRepository _mockEntregaRepository;
        private readonly MockEstadoArticuloRepository _mockEstadoArticuloRepository;
        private readonly MockFactorDeConversionRepository _mockFactorDeConversionRepository;
        private readonly MockFacturaRepository _mockFacturaRepository;
        private readonly MockFechaFeriadoRepository _mockFechaFeriadoRepository;
        private readonly MockGeoPosicionRepository _mockGeoPosicionRepository;
        private readonly MockImpuestoBocaRepository _mockImpuestoBocaRepository;
        private readonly MockImpuestoFacturaRepository _mockImpuestoFacturaRepository;
        private readonly MockImpuestoRepository _mockImpuestoRepository;
        private readonly MockIncidenciaRepository _mockIncidenciaRepository;
        private readonly MockMenuRepository _mockMenuRepository;
        private readonly MockMotivoEntregaRepository _mockMotivoEntregaRepository;
        private readonly MockMovimientoStockAnuladoRepository _mockMovimientoStockAnuladoRepository;
        private readonly MockMovimientoStockRepository _mockMovimientoStockRepository;
        private readonly MockNegocioRepository _mockNegocioRepository;
        private readonly MockNumeradorRepository _mockNumeradorRepository;
        private readonly MockNumeroDisponibleRepository _mockNumeroDisponibleRepository;
        private readonly MockPaisRepository _mockPaisRepository;
        private readonly MockPantallaRepository _mockPantallaRepository;
        private readonly MockParametroRepository _mockParametroRepository;
        private readonly MockPatenteRepository _mockPatenteRepository;
        private readonly MockPDARepository _mockPDARepository;
        private readonly MockPedidoRepository _mockPedidoRepository;
        private readonly MockPlantaRepository _mockPlantaRepository;
        private readonly MockPrecioRepository _mockPrecioRepository;
        private readonly MockProcesoRepository _mockProcesoRepository;
        private readonly MockProntoPagoRepository _mockProntoPagoRepository;
        private readonly MockProveedorRepository _mockProveedorRepository;
        private readonly MockRazonDeNoAbastecidoRepository _mockRazonDeNoAbastecidoRepository;
        private readonly MockReciboRepository _mockReciboRepository;
        private readonly MockRegionComercialRepository _mockRegionComercialRepository;
        private readonly MockRemitoRepository _mockRemitoRepository;
        private readonly MockStockRepository _mockStockRepository;
        private readonly MockSucursalRepository _mockSucursalRepository;
        private readonly MockTanqueRepository _mockTanqueRepository;
        private readonly MockTipoDeViajeRepository _mockTipoDeViajeRepository;
        private readonly MockTipoDocumentoRepository _mockTipoDocumentoRepository;
        private readonly MockTipoIncidenciaRepository _mockTipoIncidenciaRepository;
        private readonly MockTipoOperacionRepository _mockTipoOperacionRepository;
        private readonly MockTipoPedidoRepository _mockTipoPedidoRepository;
        private readonly MockTipoRazonDeNoAbastecidoRepository _mockTipoRazonDeNoAbastecidoRepository;
        private readonly MockTitularRepository _mockTitularRepository;
        private readonly MockTraduccionRepository _mockTraduccionRepository;
        private readonly MockUnidadRepository _mockUnidadRepository;
        private readonly MockUsuarioRepository _mockUsuarioRepository;
        private readonly MockValorRepository _mockValorRepository;
        private readonly MockViaDePagoRepository _mockViaDePagoRepository;
        private readonly MockViajeRepository _mockViajeRepository;
        private readonly MockZonaRepository _mockZonaRepository;
        private readonly MockZonaXViajeRepository _mockZonaXViajeRepository;
        #endregion

        #region Declarations/Repository
        private readonly IUnitOfWorkDapper _entities;
        #endregion

        public InicializadorDataAccess(
            HandHeldSQLiteDbContextFactory handHeldSQLiteDbContextFactory,

        #region Dependencies/Repository
            IUnitOfWorkDapper entities,
        #endregion

        #region Dependencies/MocksRepository
        MockBancoRepository mockBancoRepository,
            MockCategoriaSegunFiscoRepository mockCategoriaSegunFiscoRepository,
            MockDespachoRepository mockDespachoRepository,
            MockEstadoArticuloRepository mockEstadoArticuloRepository,
            MockGeoPosicionRepository mockGeoPosicionRepository,
            MockImpuestoRepository mockImpuestoRepository,
            MockMotivoEntregaRepository mockMotivoEntregaRepository,
            MockNegocioRepository mockNegocioRepository,
            MockPaisRepository mockPaisRepository,
            MockPantallaRepository mockPantallaRepository,
            MockPatenteRepository mockPatenteRepository,
            MockProcesoRepository mockProcesoRepository,
            MockProntoPagoRepository mockProntoPagoRepository,
            MockProveedorRepository mockProveedorRepository,
            MockTipoDeViajeRepository mockTipoDeViajeRepository,
            MockTipoDocumentoRepository mockTipoDocumentoRepository,
            MockTipoIncidenciaRepository mockTipoIncidenciaRepository,
            MockTipoPedidoRepository mockTipoPedidoRepository,
            MockTipoRazonDeNoAbastecidoRepository mockTipoRazonDeNoAbastecidoRepository,
            MockUnidadRepository mockUnidadRepository,
            MockUsuarioRepository mockUsuarioRepository,
            MockZonaRepository mockZonaRepository,
            MockArticuloRepository mockArticuloRepository,
            MockBocaDespachoRepository mockBocaDespachoRepository,
            MockFactorDeConversionRepository mockFactorDeConversionRepository,
            MockMenuRepository mockMenuRepository,
            MockParametroRepository mockParametroRepository,
            MockPlantaRepository mockPlantaRepository,
            MockPDARepository mockPDARepository,
            MockRegionComercialRepository mockRegionComercialRepository,
            MockSucursalRepository mockSucursalRepository,
            MockTipoOperacionRepository mockTipoOperacionRepository,
            MockTitularRepository mockTitularRepository,
            MockTraduccionRepository mockTraduccionRepository,
            MockViaDePagoRepository mockViaDePagoRepository,
            MockViajeRepository mockViajeRepository,
            MockZonaXViajeRepository mockZonaXViajeRepository,
            MockAlmacenRepository mockAlmacenRepository,
            MockDocumentoRepository mockDocumentoRepository,
            MockDocumentoAnuladoRepository mockDocumentoAnuladoRepository,
            MockFechaFeriadoRepository mockFechaFeriadoRepository,
            MockNumeradorRepository mockNumeradorRepository,
            MockBocaRepository mockBocaRepository,
            MockCobranzaRepository mockCobranzaRepository,
            MockCuentaCorrienteRepository mockCuentaCorrienteRepository,
            MockDetalleCobranzaRepository mockDetalleCobranzaRepository,
            MockImpuestoBocaRepository mockImpuestoBocaRepository,
            MockIncidenciaRepository mockIncidenciaRepository,
            MockNumeroDisponibleRepository mockNumeroDisponibleRepository,
            MockPrecioRepository mockPrecioRepository,
            MockTanqueRepository mockTanqueRepository,
            MockMovimientoStockRepository mockMovimientoStockRepository,
            MockMovimientoStockAnuladoRepository mockMovimientoStockAnuladoRepository,
            MockStockRepository mockStockRepository,
            MockReciboRepository mockReciboRepository,
            MockRemitoRepository mockRemitoRepository,
            MockValorRepository mockValorRepository,
            MockPedidoRepository mockPedidoRepository,
            MockEntregaRepository mockEntregaRepository,
            MockFacturaRepository mockFacturaRepository,
            MockRazonDeNoAbastecidoRepository mockRazonDeNoAbastecidoRepository,
            MockImpuestoFacturaRepository mockImpuestoFacturaRepository,
            MockDetalleMovimientoStockRepository mockDetalleMovimientoStockRepository,
            MockDetalleAplicacionReciboRepository mockDetalleAplicacionReciboRepository,
            MockDetalleEntregaRepository mockDetalleEntregaRepository,
            MockDetalleEntregaDocumentoRepository mockDetalleEntregaDocumentoRepository,
            MockDetalleFacturaRepository mockDetalleFacturaRepository,
            MockDetallePedidoRepository mockDetallePedidoRepository,
            MockDetalleRemitoRepository mockDetalleRemitoRepository,
            MockDetalleEntregaTanqueRepository mockDetalleEntregaTanqueRepository
        #endregion
            )
        {
            _handHeldSQLiteDbContextFactory = handHeldSQLiteDbContextFactory;
            #region Binding/Repository
            _entities = entities;
            #endregion

            #region Binding/MocksRepository
            _mockBancoRepository = mockBancoRepository;
            _mockCategoriaSegunFiscoRepository = mockCategoriaSegunFiscoRepository;
            _mockDespachoRepository = mockDespachoRepository;
            _mockEstadoArticuloRepository = mockEstadoArticuloRepository;
            _mockGeoPosicionRepository = mockGeoPosicionRepository;
            _mockImpuestoRepository = mockImpuestoRepository;
            _mockMotivoEntregaRepository = mockMotivoEntregaRepository;
            _mockNegocioRepository = mockNegocioRepository;
            _mockPaisRepository = mockPaisRepository;
            _mockPantallaRepository = mockPantallaRepository;
            _mockPatenteRepository = mockPatenteRepository;
            _mockProcesoRepository = mockProcesoRepository;
            _mockProntoPagoRepository = mockProntoPagoRepository;
            _mockProveedorRepository = mockProveedorRepository;
            _mockTipoDeViajeRepository = mockTipoDeViajeRepository;
            _mockTipoDocumentoRepository = mockTipoDocumentoRepository;
            _mockTipoIncidenciaRepository = mockTipoIncidenciaRepository;
            _mockTipoPedidoRepository = mockTipoPedidoRepository;
            _mockTipoRazonDeNoAbastecidoRepository = mockTipoRazonDeNoAbastecidoRepository;
            _mockUnidadRepository = mockUnidadRepository;
            _mockUsuarioRepository = mockUsuarioRepository;
            _mockZonaRepository = mockZonaRepository;
            _mockArticuloRepository = mockArticuloRepository;
            _mockBocaDespachoRepository = mockBocaDespachoRepository;
            _mockFactorDeConversionRepository = mockFactorDeConversionRepository;
            _mockMenuRepository = mockMenuRepository;
            _mockParametroRepository = mockParametroRepository;
            _mockPlantaRepository = mockPlantaRepository;
            _mockPDARepository = mockPDARepository;
            _mockRegionComercialRepository = mockRegionComercialRepository;
            _mockSucursalRepository = mockSucursalRepository;
            _mockTipoOperacionRepository = mockTipoOperacionRepository;
            _mockTitularRepository = mockTitularRepository;
            _mockTraduccionRepository = mockTraduccionRepository;
            _mockViaDePagoRepository = mockViaDePagoRepository;
            _mockViajeRepository = mockViajeRepository;
            _mockZonaXViajeRepository = mockZonaXViajeRepository;
            _mockAlmacenRepository = mockAlmacenRepository;
            _mockDocumentoRepository = mockDocumentoRepository;
            _mockDocumentoAnuladoRepository = mockDocumentoAnuladoRepository;
            _mockFechaFeriadoRepository = mockFechaFeriadoRepository;
            _mockNumeradorRepository = mockNumeradorRepository;
            _mockBocaRepository = mockBocaRepository;
            _mockCobranzaRepository = mockCobranzaRepository;
            _mockCuentaCorrienteRepository = mockCuentaCorrienteRepository;
            _mockDetalleCobranzaRepository = mockDetalleCobranzaRepository;
            _mockImpuestoBocaRepository = mockImpuestoBocaRepository;
            _mockIncidenciaRepository = mockIncidenciaRepository;
            _mockNumeroDisponibleRepository = mockNumeroDisponibleRepository;
            _mockPrecioRepository = mockPrecioRepository;
            _mockTanqueRepository = mockTanqueRepository;
            _mockMovimientoStockRepository = mockMovimientoStockRepository;
            _mockMovimientoStockAnuladoRepository = mockMovimientoStockAnuladoRepository;
            _mockStockRepository = mockStockRepository;
            _mockReciboRepository = mockReciboRepository;
            _mockRemitoRepository = mockRemitoRepository;
            _mockValorRepository = mockValorRepository;
            _mockPedidoRepository = mockPedidoRepository;
            _mockEntregaRepository = mockEntregaRepository;
            _mockFacturaRepository = mockFacturaRepository;
            _mockRazonDeNoAbastecidoRepository = mockRazonDeNoAbastecidoRepository;
            _mockImpuestoFacturaRepository = mockImpuestoFacturaRepository;
            _mockDetalleMovimientoStockRepository = mockDetalleMovimientoStockRepository;
            _mockDetalleAplicacionReciboRepository = mockDetalleAplicacionReciboRepository;
            _mockDetalleEntregaRepository = mockDetalleEntregaRepository;
            _mockDetalleEntregaDocumentoRepository = mockDetalleEntregaDocumentoRepository;
            _mockDetalleFacturaRepository = mockDetalleFacturaRepository;
            _mockDetallePedidoRepository = mockDetallePedidoRepository;
            _mockDetalleRemitoRepository = mockDetalleRemitoRepository;
            _mockDetalleEntregaTanqueRepository = mockDetalleEntregaTanqueRepository;
            #endregion
        }
        public void CrearBaseSqlite(string path, string name)
        {
            _handHeldSQLiteDbContext = _handHeldSQLiteDbContextFactory.NewHandHeldSQLiteDbContextBuilder(path, name);
        }
        public async Task GenerarBaseSqlite(Actualizacion actualizacion, long version)
        {
            if (_handHeldSQLiteDbContext is null)
            {
                throw new Exception("_handHeldSQLiteDbContext is null");
            }

            _BaseDeDatos db = new _BaseDeDatos() { Id = "1", Nombre = _BaseDeDatos.DB, Version = version };

            #region GetData

            IEnumerable<Boca> bocas = await _entities._boca.GetDataByIdPlanta(int.Parse(actualizacion.IdPlanta));
            IEnumerable<Banco> bancos = await _entities._banco.GetData();
            IEnumerable<CategoriaSegunFisco> categoriasSegunFisco = await _entities._categoriaSegunFisco.GetData();
            IEnumerable<EstadoArticulo> estadosArticulos = await _entities._estadoArticulo.GetData();
            IEnumerable<Impuesto> impuestos = await _entities._impuesto.GetData();
            IEnumerable<MotivoEntrega> motivosEntregas = await _entities._motivoEntrega.GetData();
            IEnumerable<Negocio> negocios = await _entities._negocio.GetData();
            IEnumerable<Pais> paises = await _entities._pais.GetData();
            IEnumerable<Pantalla> pantallas = await _entities._pantalla.GetData();
            IEnumerable<Patente> patentes = await _entities._patente.GetData();
            IEnumerable<Proceso> procesos = await _entities._proceso.GetData();
            IEnumerable<ProntoPago> prontoPagos = await _entities._prontoPago.GetData();
            IEnumerable<Proveedor> proveedores = await _entities._proveedor.GetData();
            IEnumerable<TipoDeViaje> tiposDeViajes = await _entities._tipoDeViaje.GetData();
            IEnumerable<TipoDocumento> tiposDocumentos = await _entities._tipoDocumento.GetData();
            IEnumerable<TipoIncidencia> tiposIncidencias = _mockTipoIncidenciaRepository.GetAll();
            IEnumerable<TipoPedido> tiposPedidos = await _entities._tipoPedido.GetData();
            IEnumerable<TipoRazonDeNoAbastecido> tiposRazonesDeNoAbastecidos =await _entities._tipoRazonDeNoAbastecido.GetData();
            IEnumerable<Unidad> unidades = await _entities._unidad.GetData();
            IEnumerable<Usuario> usuarios = await _entities._usuario.GetData();
            IEnumerable<Zona> zonas = await _entities._zona.GetData();
            IEnumerable<Articulo> articulos = await _entities._articulo.GetData();
            IEnumerable<BocaDespacho> bocaDespachos = await _entities._bocaDespacho.GetData();
            IEnumerable<Parametro> parametros = await _entities._parametro.GetData();
            IEnumerable<Planta> plantas = await _entities._planta.GetData();
            IEnumerable<PDA> pdas = await _entities._pda.GetDataByIdVehiculo(int.Parse(actualizacion.IdPatente));
            IEnumerable<RegionComercial> regionesComerciales = await _entities._regionComercial.GetData();
            IEnumerable<Sucursal> sucursales = await _entities._sucursal.GetData();
            IEnumerable<TipoOperacion> tiposOperaciones = await _entities._tipoOperacion.GetData();
            IEnumerable<Titular> titulares = await _entities._titular.GetDataByIdPlanta(int.Parse(actualizacion.IdPlanta));
            IEnumerable<ViaDePago> viasDePagos = await _entities._viaDePago.GetData();
            IEnumerable<Almacen> almacenes = await _entities._almacen.GetData();
            IEnumerable<ImpuestoBoca> impuestosBocas = await _entities._impuestoBoca.GetDataByIdPlanta(int.Parse(actualizacion.IdPlanta));
            IEnumerable<Incidencia> incidencias = _mockIncidenciaRepository.GetAll();
            IEnumerable<Precio> precios = await _entities._precio.GetDataByIdPlanta(int.Parse(actualizacion.IdPlanta));
            IEnumerable<Tanque> tanques = await _entities._tanque.GetDataByIdPlanta(int.Parse(actualizacion.IdPlanta));
            #endregion

            #region SetData
            _handHeldSQLiteDbContext.BasesDeDatos.Add(db);
            _handHeldSQLiteDbContext.Bancos.AddRange(bancos);
            _handHeldSQLiteDbContext.CategoriasSegunFisco.AddRange(categoriasSegunFisco);
            _handHeldSQLiteDbContext.EstadosArticulos.AddRange(estadosArticulos);
            _handHeldSQLiteDbContext.Impuestos.AddRange(impuestos);
            _handHeldSQLiteDbContext.MotivosEntregas.AddRange(motivosEntregas);
            _handHeldSQLiteDbContext.Negocios.AddRange(negocios);
            _handHeldSQLiteDbContext.Paises.AddRange(paises);
            _handHeldSQLiteDbContext.Pantallas.AddRange(pantallas);
            _handHeldSQLiteDbContext.Patentes.AddRange(patentes);
            _handHeldSQLiteDbContext.Procesos.AddRange(procesos);
            _handHeldSQLiteDbContext.ProntoPagos.AddRange(prontoPagos);
            _handHeldSQLiteDbContext.Proveedores.AddRange(proveedores);
            _handHeldSQLiteDbContext.TiposDeViajes.AddRange(tiposDeViajes);
            _handHeldSQLiteDbContext.TiposDocumentos.AddRange(tiposDocumentos);
            _handHeldSQLiteDbContext.TiposIncidencias.AddRange(tiposIncidencias);
            _handHeldSQLiteDbContext.TiposPedidos.AddRange(tiposPedidos);
            _handHeldSQLiteDbContext.TiposRazonesDeNoAbastecidos.AddRange(tiposRazonesDeNoAbastecidos);
            _handHeldSQLiteDbContext.Unidades.AddRange(unidades);
            _handHeldSQLiteDbContext.Usuarios.AddRange(usuarios);
            _handHeldSQLiteDbContext.Zonas.AddRange(zonas);
            _handHeldSQLiteDbContext.Articulos.AddRange(articulos);
            _handHeldSQLiteDbContext.BocaDespachos.AddRange(bocaDespachos);
            _handHeldSQLiteDbContext.Parametros.AddRange(parametros);
            _handHeldSQLiteDbContext.Plantas.AddRange(plantas);
            _handHeldSQLiteDbContext.PDAs.AddRange(pdas);
            _handHeldSQLiteDbContext.RegionesComerciales.AddRange(regionesComerciales);
            _handHeldSQLiteDbContext.Sucursales.AddRange(sucursales);
            _handHeldSQLiteDbContext.TiposOperaciones.AddRange(tiposOperaciones);
            _handHeldSQLiteDbContext.ViasDePagos.AddRange(viasDePagos);
            _handHeldSQLiteDbContext.Almacenes.AddRange(almacenes);
            _handHeldSQLiteDbContext.Bocas.AddRange(bocas);
            _handHeldSQLiteDbContext.ImpuestosBocas.AddRange(impuestosBocas);
            _handHeldSQLiteDbContext.Incidencias.AddRange(incidencias);
            _handHeldSQLiteDbContext.Titulares.AddRange(titulares);
            _handHeldSQLiteDbContext.Precios.AddRange(precios);
            _handHeldSQLiteDbContext.Tanques.AddRange(tanques);
            #endregion
            
            _handHeldSQLiteDbContext.SaveChanges();
        }

    }
}
