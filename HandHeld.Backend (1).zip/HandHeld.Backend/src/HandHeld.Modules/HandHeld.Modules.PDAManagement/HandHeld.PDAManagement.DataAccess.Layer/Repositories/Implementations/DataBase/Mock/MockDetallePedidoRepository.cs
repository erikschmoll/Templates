﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockDetallePedidoRepository : _MockRepository<DetallePedido>
    {
        public MockDetallePedidoRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
