﻿using Dapper;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core;
using HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Interfaces;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations
{
    public class GetDataServices : IGetDataServices
    {

        private readonly SqlConnection _connection;
        private readonly IDbTransaction _transaction;

        public GetDataServices(SqlConnection connection, IDbTransaction transaction)
        {
            _connection = connection;
            _transaction = transaction;
        }

        public async Task<dynamic?> GetPatente(string id)
        {
            string query = "SELECT TOP 1 IDVehiculo as id, Patente as nombre FROM Vehiculo WHERE IDVehiculo= " + id;
            var patente = await _connection.QueryFirstAsync<dynamic>(query, commandType:  CommandType.Text,transaction: _transaction);
            return patente;
        }

        public async Task<dynamic?> GetPlanta(string id)
        {
            string query = "SELECT TOP 1 IDSitio as id, Sitio as nombre FROM Sitio WHERE IDSitio= " + id;
            var plata = await _connection.QueryFirstAsync<dynamic>(query, commandType: CommandType.Text, transaction: _transaction);
            return plata;
        }
    }
}
