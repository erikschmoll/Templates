﻿using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.YPFGas;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using Dapper;
using System.Reflection;
using System.ComponentModel;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Config;
using HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Interfaces;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.YPFGas
{
    public class YPFGas_Repository<T> : IYPFGas_Repository<T> where T : class
    {
        private readonly string? query;
        private readonly bool isSP;
        private readonly SqlConnection _connection;
        private readonly IDbTransaction _transaction;

        public YPFGas_Repository(SqlConnection connection, IDbTransaction transaction)
        {
            _connection = connection;
            _transaction = transaction;
            query = typeof(T).GetProperty("Query", BindingFlags.Public | BindingFlags.Static)?.GetValue(null, null)?.ToString();
            var sp = typeof(T).GetProperty("IsSP", BindingFlags.Public | BindingFlags.Static)?.GetValue(null, null);
            isSP = (sp != null) && (bool)sp;
        }

        public async Task<IEnumerable<dynamic>> GetDataDynamicByPattern(string fieldsAndFrom,
            IList<Filtro>? filters,
            string? orderBy = null,
            string? orderType = "asc")
        {
            IEnumerable<dynamic> result;
            string where = string.Empty;
            Dictionary<string, object> parameters = new();

            if (filters is not null && filters.Any())
            {
                where = "WHERE ";
                
                for (int i = 0; i < filters.Count; i++)
                {
                    var filter = filters[i];
                    if (i != 0 && i != filters.Count)
                    {
                        where += " and ";
                    }
                    where += filter.Condicion;
                    parameters.Add(filter.Field, filter.Valor);
                }
            }

            string order = $"{((orderBy is null) ? string.Empty : $"order by {orderBy} {orderType}")}";
            string query = $"{fieldsAndFrom} {where} {order}";

            result = await _connection.QueryAsync<dynamic>(query, parameters,transaction: _transaction);
            return result;
        }

        public async Task<IEnumerable<T>> GetData()
        {
            Map();
            var parameters = new DynamicParameters();
            parameters.Add("@iErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            IEnumerable<T> data = await _connection.QueryAsync<T>(query, parameters, commandType: isSP ? CommandType.StoredProcedure : CommandType.Text,transaction: _transaction);
            return data;
        }

        public async Task<IEnumerable<T>> GetDataByIdPlanta(int IdPlanta)
        {
            Map();
            var parameters = new DynamicParameters();
            parameters.Add("iIDSitio", IdPlanta);
            parameters.Add("@iErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            IEnumerable<T> data = await _connection.QueryAsync<T>(query, parameters, commandType: isSP ? CommandType.StoredProcedure : CommandType.Text, transaction: _transaction);
            return data;
        }

        public async Task<IEnumerable<T>> GetDataByIdVehiculo(int IdVehiculo)
        {
            Map();
            var parameters = new DynamicParameters();
            parameters.Add("iIDVehiculo", IdVehiculo);
            parameters.Add("@iErrorCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            IEnumerable<T> data = await _connection.QueryAsync<T>(query, parameters, commandType: isSP ? CommandType.StoredProcedure : CommandType.Text, transaction: _transaction);
            return data;
        }

        #region Private

        private static string? GetDescriptionFromAttribute(MemberInfo member)
        {
            if (member == null) return null;

            var attrib = (DescriptionAttribute?)Attribute.GetCustomAttribute(member, typeof(DescriptionAttribute), false);
            return attrib == null ? member.Name : attrib.Description;
        }

        private static void Map()
        {
            var map = new CustomPropertyTypeMap(typeof(T),
                 (type, columnName) => type.GetProperties().FirstOrDefault(prop => GetDescriptionFromAttribute(prop) == columnName));
            SqlMapper.SetTypeMap(typeof(T), map);
        }

        #endregion
    }
}
