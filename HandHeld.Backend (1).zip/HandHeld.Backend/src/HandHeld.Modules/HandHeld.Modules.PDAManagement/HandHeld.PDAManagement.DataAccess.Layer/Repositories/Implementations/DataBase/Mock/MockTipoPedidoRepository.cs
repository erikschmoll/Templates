﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockTipoPedidoRepository : _MockRepository<TipoPedido>
    {
        public MockTipoPedidoRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
