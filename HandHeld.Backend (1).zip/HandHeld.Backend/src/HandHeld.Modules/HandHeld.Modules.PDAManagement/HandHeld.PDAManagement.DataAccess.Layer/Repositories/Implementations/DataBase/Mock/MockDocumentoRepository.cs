﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockDocumentoRepository : _MockRepository<Documento>
    {
        public MockDocumentoRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
