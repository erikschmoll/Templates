﻿
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public abstract class _MockRepository<T> where T : class
    {
        protected readonly HandHeldSdfDbContext _context;
        public _MockRepository(HandHeldSdfDbContext context)
        {
            _context = context;
        }
        public virtual IEnumerable<T> GetAll()
        {
            return _context.Set<T>().ToList();
        }
    }
}
