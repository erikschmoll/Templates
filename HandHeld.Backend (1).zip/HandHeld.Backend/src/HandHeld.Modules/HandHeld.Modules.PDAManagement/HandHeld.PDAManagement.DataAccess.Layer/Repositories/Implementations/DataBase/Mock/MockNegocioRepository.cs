﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockNegocioRepository : _MockRepository<Negocio>
    {
        public MockNegocioRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
