﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock
{
    public class MockSucursalRepository : _MockRepository<Sucursal>
    {
        public MockSucursalRepository(HandHeldSdfDbContext context): base(context)
        {
        }
    }
}
