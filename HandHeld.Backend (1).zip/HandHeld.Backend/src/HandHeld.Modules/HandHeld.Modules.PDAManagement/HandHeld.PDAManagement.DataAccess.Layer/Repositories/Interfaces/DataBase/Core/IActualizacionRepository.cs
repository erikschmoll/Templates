﻿
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Reponse;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Request;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Base;
using HandHeld.PDAManagement.Presentation.Layer.Models;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core
{
    public interface IActualizacionRepository : IWriteRepository<Actualizacion>, IReadRepository<Actualizacion>
    {
        Task<Actualizaciones?> BuscarActualizacionesPorFiltrosAsync(FiltrosBuscarActualizaciones? filtros, int limite, int pagina, string? order, string? tipoOrder);

        Task<Actualizacion> BuscarActualizacionesByIdAsync(string id);

        Task BajaActualizacionesByIdAsync(string id);

        string AltaActualizacionesAsync(AltaActualizaciones model);

        Task<Actualizacion?> GetAsync(string? chofer, int nroActualizacion);

        Task ModificarActualizacionAsync(string id, ModificarActualizaciones model);

        Task BlanqueoNroActualizacion(string id);

        Task<Actualizacion?> GetByIdAsync(string id, bool del);

        Task<IEnumerable<dynamic>?> BuscarPlantas();

        Task<IEnumerable<dynamic>?> BuscarPatentes(string? patron);

        Task<IEnumerable<Usuarios>> BuscarUsuarios(string patron);

        Task<IEnumerable<EstadoActualizacionDto>> BuscarEstados();

        Task<long> NuevaVersion(int vr, string chofer);
    }
}
