﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Base;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core
{
    public interface IConfiguracionRepository : IReadRepository<Configuracion>
    {
        int ValorEntero32(string id);
        long ValorEntero64(string id);
        string Valor(string id);

    }
}
