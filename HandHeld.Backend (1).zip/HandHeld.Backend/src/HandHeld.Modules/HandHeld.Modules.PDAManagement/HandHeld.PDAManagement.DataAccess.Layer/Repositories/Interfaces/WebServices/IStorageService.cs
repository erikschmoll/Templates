﻿
namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.WebServices
{
    public interface IStorageService
    {
        Task<byte[]> GetStorageAsync(string url);
        Task<string> PushToStorageAsync(string path, string fileName);
    }
}
