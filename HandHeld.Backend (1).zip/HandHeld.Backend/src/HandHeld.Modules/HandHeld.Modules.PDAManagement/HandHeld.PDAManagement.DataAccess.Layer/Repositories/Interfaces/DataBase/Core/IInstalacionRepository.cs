﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Base;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core
{
    public interface IInstalacionRepository : IWriteRepository<Instalacion>, IReadRepository<Instalacion>
    {
        int CantDeInstalaciones(string IdActualizacion, int nroActualizacion);
    }
}
