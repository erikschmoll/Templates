﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core
{
    public interface IColaPendientesRepository
    {
        IEnumerable<Actualizacion> GetPendientesConTope();
    }
}
