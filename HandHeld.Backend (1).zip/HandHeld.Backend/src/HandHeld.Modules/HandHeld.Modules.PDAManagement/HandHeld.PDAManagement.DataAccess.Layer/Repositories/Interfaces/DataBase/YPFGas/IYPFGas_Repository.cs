﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Config;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.YPFGas
{
    public interface IYPFGas_Repository<T> where T : class
    {
        Task<IEnumerable<T>> GetData();
        Task<IEnumerable<dynamic>> GetDataDynamicByPattern(string fieldsAndFrom,
            IList<Filtro>? filters,
            string? orderBy = null,
            string? orderType = "asc");
        Task<IEnumerable<T>> GetDataByIdPlanta(int IdPlanta);
        Task<IEnumerable<T>> GetDataByIdVehiculo(int IdVehiculo);
    }
}
