﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces
{
    public interface IInicializadorDataAccess
    {
        void CrearBaseSqlite(string path, string name);
        Task GenerarBaseSqlite(Actualizacion actualizacion, long version);
    }
}
