﻿using AutoMapper;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDAManagement.DataAccess.Layer.Repositories
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<EstadoActualizacion, EstadoActualizacionDto>();
        }
    }
}
