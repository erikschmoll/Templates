using HandHeld.PDAManagement.DataAccess.Layer.Configurations.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.Shared.Infrastructure.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace HandHeld.PDAManagement.DataAccess.Layer.DbContexts
{
    public class HandHeldDbContext : DbContext
    {
        public DbSet<EstadoActualizacion> EstadosActualizacion => Set<EstadoActualizacion>();
        public DbSet<Actualizacion> Actualizaciones => Set<Actualizacion>();
        public DbSet<Configuracion> Configuraciones => Set<Configuracion>();
        public DbSet<Instalacion> Instalaciones => Set<Instalacion>();

        private readonly IIdentityService _identityService;

        public HandHeldDbContext(DbContextOptions<HandHeldDbContext> options,
            IIdentityService identityService) : base(options) 
        {
            _identityService = identityService;
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.ApplyConfiguration(new EstadoActualizacionConfiguration());
            builder.ApplyConfiguration(new ActualizacionConfiguration());
            builder.ApplyConfiguration(new ConfiguracionConfiguration());
            builder.ApplyConfiguration(new InstalacionConfiguration());
        }
        public override int SaveChanges()
        {
            Audit();
            return (base.SaveChanges());

        }

        private void Audit()
        {
            var user = _identityService.UserName();
            foreach (var entry in ChangeTracker.Entries())
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                        entry.CurrentValues["FechaCreacion"] = DateTimeOffset.Now;
                        entry.CurrentValues["FechaModificacion"] = DateTimeOffset.Now;
                        if (user is not null)
                        {
                            entry.CurrentValues["CreadoPor"] = user;
                            entry.CurrentValues["ModificadoPor"] = user;
                        }
                        break;
                    case EntityState.Modified:
                        entry.CurrentValues["FechaModificacion"] = DateTimeOffset.Now;
                        if (user is not null)
                        {
                            entry.CurrentValues["ModificadoPor"] = user;
                        }
                        break;
                    case EntityState.Deleted:
                        entry.CurrentValues["FechaModificacion"] = DateTimeOffset.Now;
                        entry.State = EntityState.Modified;
                        if (user is not null)
                        {
                            entry.CurrentValues["ModificadoPor"] = user;
                        }
                        entry.CurrentValues["Del"] = true;
                        //TODO: se deberian setear en true los hijos.
                        // no deberian guardarse objetos compuestos.
                        break;
                }
            }
        }
    }
}
