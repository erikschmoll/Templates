﻿using HandHeld.PDAManagement.DataAccess.Layer.Configurations.Business;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace HandHeld.PDAManagement.DataAccess.Layer.DbContexts
{
    public class HandHeldSQLiteDbContext : DbContext, IDisposable
    {
        #region DbSet/Models/Business
        public DbSet<_BaseDeDatos> BasesDeDatos => Set<_BaseDeDatos>();
        public DbSet<Banco> Bancos => Set<Banco>();
        public DbSet<CategoriaSegunFisco> CategoriasSegunFisco => Set<CategoriaSegunFisco>();
        public DbSet<Despacho> Despachos => Set<Despacho>();
        public DbSet<EstadoArticulo> EstadosArticulos => Set<EstadoArticulo>();
        public DbSet<GeoPosicion> GeoPosiciones => Set<GeoPosicion>();
        public DbSet<Impuesto> Impuestos => Set<Impuesto>();
        public DbSet<MotivoEntrega> MotivosEntregas => Set<MotivoEntrega>();
        public DbSet<Negocio> Negocios => Set<Negocio>();
        public DbSet<Pais> Paises => Set<Pais>();
        public DbSet<Pantalla> Pantallas => Set<Pantalla>();
        public DbSet<Patente> Patentes => Set<Patente>();
        public DbSet<Proceso> Procesos => Set<Proceso>();
        public DbSet<ProntoPago> ProntoPagos => Set<ProntoPago>();
        public DbSet<Proveedor> Proveedores => Set<Proveedor>();
        public DbSet<TipoDeViaje> TiposDeViajes => Set<TipoDeViaje>();
        public DbSet<TipoDocumento> TiposDocumentos => Set<TipoDocumento>();
        public DbSet<TipoIncidencia> TiposIncidencias => Set<TipoIncidencia>();
        public DbSet<TipoPedido> TiposPedidos => Set<TipoPedido>();
        public DbSet<TipoRazonDeNoAbastecido> TiposRazonesDeNoAbastecidos => Set<TipoRazonDeNoAbastecido>();
        public DbSet<Unidad> Unidades => Set<Unidad>();
        public DbSet<Usuario> Usuarios => Set<Usuario>();
        public DbSet<Zona> Zonas => Set<Zona>();
        public DbSet<Articulo> Articulos => Set<Articulo>();
        public DbSet<BocaDespacho> BocaDespachos => Set<BocaDespacho>();
        public DbSet<FactorDeConversion> FactoresDeConversiones => Set<FactorDeConversion>();
        public DbSet<Menu> Menues => Set<Menu>();
        public DbSet<Parametro> Parametros => Set<Parametro>();
        public DbSet<Planta> Plantas => Set<Planta>();
        public DbSet<PDA> PDAs => Set<PDA>();
        public DbSet<RegionComercial> RegionesComerciales => Set<RegionComercial>();
        public DbSet<Sucursal> Sucursales => Set<Sucursal>();
        public DbSet<TipoOperacion> TiposOperaciones => Set<TipoOperacion>();
        public DbSet<Titular> Titulares => Set<Titular>();
        public DbSet<Traduccion> Traducciones => Set<Traduccion>();
        public DbSet<ViaDePago> ViasDePagos => Set<ViaDePago>();
        public DbSet<Viaje> Viajes => Set<Viaje>();
        public DbSet<ZonaXViaje> ZonasXViajes => Set<ZonaXViaje>();
        public DbSet<Almacen> Almacenes => Set<Almacen>();
        public DbSet<Documento> Documentos => Set<Documento>();
        public DbSet<DocumentoAnulado> DocumentosAnulados => Set<DocumentoAnulado>();
        public DbSet<FechaFeriado> FechasFeriados => Set<FechaFeriado>();
        public DbSet<Numerador> Numeradores => Set<Numerador>();
        public DbSet<Boca> Bocas => Set<Boca>();
        public DbSet<Cobranza> Cobranzas => Set<Cobranza>();
        public DbSet<CuentaCorriente> CuentasCorrientes => Set<CuentaCorriente>();
        public DbSet<DetalleCobranza> DetallesCobranzas => Set<DetalleCobranza>();
        public DbSet<ImpuestoBoca> ImpuestosBocas => Set<ImpuestoBoca>();
        public DbSet<Incidencia> Incidencias => Set<Incidencia>();
        public DbSet<NumeroDisponible> NumerosDisponibles => Set<NumeroDisponible>();
        public DbSet<Precio> Precios => Set<Precio>();
        public DbSet<Tanque> Tanques => Set<Tanque>();
        public DbSet<MovimientoStock> MovimientosStocks => Set<MovimientoStock>();
        public DbSet<MovimientoStockAnulado> MovimientosStocksAnulados => Set<MovimientoStockAnulado>();
        public DbSet<Stock> Stocks => Set<Stock>();
        public DbSet<Recibo> Recibos => Set<Recibo>();
        public DbSet<Remito> Remitos => Set<Remito>();
        public DbSet<Valor> Valores => Set<Valor>();
        public DbSet<Factura> Facturas => Set<Factura>();
        public DbSet<Pedido> Pedidos => Set<Pedido>();
        public DbSet<Entrega> Entregas => Set<Entrega>();
        public DbSet<RazonDeNoAbastecido> RazonesDeNoAbastecidos => Set<RazonDeNoAbastecido>();
        public DbSet<ImpuestoFactura> ImpuestosFacturas => Set<ImpuestoFactura>();
        public DbSet<DetalleMovimientoStock> DetallesMovimientosStocks => Set<DetalleMovimientoStock>();
        public DbSet<DetalleAplicacionRecibo> DetallesAplicacionesRecibos => Set<DetalleAplicacionRecibo>();
        public DbSet<DetalleEntrega> DetallesEntregas => Set<DetalleEntrega>();
        public DbSet<DetalleEntregaDocumento> DetallesEntregasDocumentos => Set<DetalleEntregaDocumento>();
        public DbSet<DetalleFactura> DetallesFacturas => Set<DetalleFactura>();
        public DbSet<DetallePedido> DetallesPedidos => Set<DetallePedido>();
        public DbSet<DetalleRemito> DetallesRemitos => Set<DetalleRemito>();
        public DbSet<DetalleEntregaTanque> DetallesEntregasTanques => Set<DetalleEntregaTanque>();
        #endregion

        public HandHeldSQLiteDbContext(DbContextOptions<HandHeldSQLiteDbContext> options) : base(options)
        {
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.EnableSensitiveDataLogging();
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            #region Configuration/Models/Business
            builder.ApplyConfiguration(new _BaseDeDatosConfiguration());
            builder.ApplyConfiguration(new BancoConfiguration());
            builder.ApplyConfiguration(new CategoriaSegunFiscoConfiguration());
            builder.ApplyConfiguration(new DespachoConfiguration());
            builder.ApplyConfiguration(new EstadoArticuloConfiguration());
            builder.ApplyConfiguration(new GeoPosicionConfiguration());
            builder.ApplyConfiguration(new ImpuestoConfiguration());
            builder.ApplyConfiguration(new MotivoEntregaConfiguration());
            builder.ApplyConfiguration(new NegocioConfiguration());
            builder.ApplyConfiguration(new PaisConfiguration());
            builder.ApplyConfiguration(new PantallaConfiguration());
            builder.ApplyConfiguration(new PatenteConfiguration());
            builder.ApplyConfiguration(new ProcesoConfiguration());
            builder.ApplyConfiguration(new ProntoPagoConfiguration());
            builder.ApplyConfiguration(new ProveedorConfiguration());
            builder.ApplyConfiguration(new TipoDeViajeConfiguration());
            builder.ApplyConfiguration(new TipoDocumentoConfiguration());
            builder.ApplyConfiguration(new TipoIncidenciaConfiguration());
            builder.ApplyConfiguration(new TipoPedidoConfiguration());
            builder.ApplyConfiguration(new TipoRazonDeNoAbastecidoConfiguration());
            builder.ApplyConfiguration(new UnidadConfiguration());
            builder.ApplyConfiguration(new UsuarioConfiguration());
            builder.ApplyConfiguration(new ZonaConfiguration());
            builder.ApplyConfiguration(new ArticuloConfiguration());
            builder.ApplyConfiguration(new BocaDespachoConfiguration());
            builder.ApplyConfiguration(new FactorDeConversionConfiguration());
            builder.ApplyConfiguration(new MenuConfiguration());
            builder.ApplyConfiguration(new ParametroConfiguration());
            builder.ApplyConfiguration(new PlantaConfiguration());
            builder.ApplyConfiguration(new PDAConfiguration());
            builder.ApplyConfiguration(new RegionComercialConfiguration());
            builder.ApplyConfiguration(new SucursalConfiguration());
            builder.ApplyConfiguration(new TipoOperacionConfiguration());
            builder.ApplyConfiguration(new TitularConfiguration());
            builder.ApplyConfiguration(new TraduccionConfiguration());
            builder.ApplyConfiguration(new ViaDePagoConfiguration());
            builder.ApplyConfiguration(new ViajeConfiguration());
            builder.ApplyConfiguration(new ZonaXViajeConfiguration());
            builder.ApplyConfiguration(new AlmacenConfiguration());
            builder.ApplyConfiguration(new DocumentoConfiguration());
            builder.ApplyConfiguration(new DocumentoAnuladoConfiguration());
            builder.ApplyConfiguration(new FechaFeriadoConfiguration());
            builder.ApplyConfiguration(new NumeradorConfiguration());
            builder.ApplyConfiguration(new BocaConfiguration());
            builder.ApplyConfiguration(new CobranzaConfiguration());
            builder.ApplyConfiguration(new CuentaCorrienteConfiguration());
            builder.ApplyConfiguration(new DetalleCobranzaConfiguration());
            builder.ApplyConfiguration(new ImpuestoBocaConfiguration());
            builder.ApplyConfiguration(new IncidenciaConfiguration());
            builder.ApplyConfiguration(new NumeroDisponibleConfiguration());
            builder.ApplyConfiguration(new PrecioConfiguration());
            builder.ApplyConfiguration(new TanqueConfiguration());
            builder.ApplyConfiguration(new MovimientoStockConfiguration());
            builder.ApplyConfiguration(new MovimientoStockAnuladoConfiguration());
            builder.ApplyConfiguration(new StockConfiguration());
            builder.ApplyConfiguration(new ReciboConfiguration());
            builder.ApplyConfiguration(new RemitoConfiguration());
            builder.ApplyConfiguration(new ValorConfiguration());
            builder.ApplyConfiguration(new PedidoConfiguration());
            builder.ApplyConfiguration(new EntregaConfiguration());
            builder.ApplyConfiguration(new FacturaConfiguration());
            builder.ApplyConfiguration(new RazonDeNoAbastecidoConfiguration());
            builder.ApplyConfiguration(new ImpuestoFacturaConfiguration());
            builder.ApplyConfiguration(new DetalleMovimientoStockConfiguration());
            builder.ApplyConfiguration(new DetalleAplicacionReciboConfiguration());
            builder.ApplyConfiguration(new DetalleEntregaConfiguration());
            builder.ApplyConfiguration(new DetalleEntregaDocumentoConfiguration());
            builder.ApplyConfiguration(new DetalleFacturaConfiguration());
            builder.ApplyConfiguration(new DetallePedidoConfiguration());
            builder.ApplyConfiguration(new DetalleRemitoConfiguration());
            builder.ApplyConfiguration(new DetalleEntregaTanqueConfiguration());
            #endregion
            base.OnModelCreating(builder);
        }
        public void CloseConn()
        {
            Database.CloseConnection();
        }
        public void BackUp(string path, string name)
        {
            SqliteConnection source = (SqliteConnection)Database.GetDbConnection();
        }
    }
}
