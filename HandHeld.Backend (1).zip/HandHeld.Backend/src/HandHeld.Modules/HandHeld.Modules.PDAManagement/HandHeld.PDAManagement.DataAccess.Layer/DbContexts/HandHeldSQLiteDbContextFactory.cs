﻿using Microsoft.EntityFrameworkCore;

namespace HandHeld.PDAManagement.DataAccess.Layer.DbContexts
{
    public class HandHeldSQLiteDbContextFactory
    {
        public HandHeldSQLiteDbContextFactory()
        {
        }
        public HandHeldSQLiteDbContext NewHandHeldSQLiteDbContextBuilder(string path, string name)
        {
            var connectionstring = $"Data Source={path}\\{name};Pooling=False;";
            //var connectionstring = $"DataSource={name};mode=memory;cache=shared";

            /*var cnn = new SqliteConnection("Filename=:memory:");
            cnn.Open();*/
            var optionsBuilder = new DbContextOptionsBuilder<HandHeldSQLiteDbContext>();
            optionsBuilder.UseSqlite(connectionstring);
            HandHeldSQLiteDbContext dbContext = new HandHeldSQLiteDbContext(optionsBuilder.Options);
            dbContext.Database.EnsureCreated();
            return dbContext;
        }
    }
}
