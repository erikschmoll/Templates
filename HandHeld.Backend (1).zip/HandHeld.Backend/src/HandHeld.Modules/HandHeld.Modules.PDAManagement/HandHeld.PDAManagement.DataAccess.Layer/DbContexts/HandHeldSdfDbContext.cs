﻿using HandHeld.PDAManagement.DataAccess.Layer.Configurations.BusinessMock;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using Microsoft.EntityFrameworkCore;

namespace HandHeld.PDAManagement.DataAccess.Layer.DbContexts
{
    public class HandHeldSdfDbContext : DbContext
    {
        #region DbSet/Models/MocksBusiness
        public DbSet<Banco> Bancos => Set<Banco>();
        public DbSet<CategoriaSegunFisco> CategoriasSegunFisco => Set<CategoriaSegunFisco>();
        public DbSet<Despacho> Despachos => Set<Despacho>();
        public DbSet<EstadoArticulo> EstadosArticulos => Set<EstadoArticulo>();
        public DbSet<GeoPosicion> GeoPosiciones => Set<GeoPosicion>();
        public DbSet<Impuesto> Impuestos => Set<Impuesto>();
        public DbSet<MotivoEntrega> MotivosEntregas => Set<MotivoEntrega>();
        public DbSet<Negocio> Negocios => Set<Negocio>();
        public DbSet<Pais> Paises => Set<Pais>();
        public DbSet<Pantalla> Pantallas => Set<Pantalla>();
        public DbSet<Patente> Patentes => Set<Patente>();
        public DbSet<Proceso> Procesos => Set<Proceso>();
        public DbSet<ProntoPago> ProntoPagos => Set<ProntoPago>();
        public DbSet<Proveedor> Proveedores => Set<Proveedor>();
        public DbSet<TipoDeViaje> TiposDeViajes => Set<TipoDeViaje>();
        public DbSet<TipoDocumento> TiposDocumentos => Set<TipoDocumento>();
        public DbSet<TipoIncidencia> TiposIncidencias => Set<TipoIncidencia>();
        public DbSet<TipoPedido> TiposPedidos => Set<TipoPedido>();
        public DbSet<TipoRazonDeNoAbastecido> TiposRazonesDeNoAbastecidos => Set<TipoRazonDeNoAbastecido>();
        public DbSet<Unidad> Unidades => Set<Unidad>();
        public DbSet<Usuario> Usuarios => Set<Usuario>();
        public DbSet<Zona> Zonas => Set<Zona>();
        public DbSet<Articulo> Articulos => Set<Articulo>();
        public DbSet<BocaDespacho> BocaDespachos => Set<BocaDespacho>();
        public DbSet<FactorDeConversion> FactoresDeConversiones => Set<FactorDeConversion>();
        public DbSet<Menu> Menues => Set<Menu>();
        public DbSet<Parametro> Parametros => Set<Parametro>();
        public DbSet<Planta> Plantas => Set<Planta>();
        public DbSet<PDA> PDAs => Set<PDA>();
        public DbSet<RegionComercial> RegionesComerciales => Set<RegionComercial>();
        public DbSet<Sucursal> Sucursales => Set<Sucursal>();
        public DbSet<TipoOperacion> TiposOperaciones => Set<TipoOperacion>();
        public DbSet<Titular> Titulares => Set<Titular>();
        public DbSet<Traduccion> Traducciones => Set<Traduccion>();
        public DbSet<ViaDePago> ViasDePagos => Set<ViaDePago>(); 
        public DbSet<Viaje> Viajes => Set<Viaje>();
        public DbSet<ZonaXViaje> ZonasXViajes => Set<ZonaXViaje>();
        public DbSet<Almacen> Almacenes => Set<Almacen>();
        public DbSet<Documento> Documentos => Set<Documento>();
        public DbSet<DocumentoAnulado> DocumentosAnulados => Set<DocumentoAnulado>();
        public DbSet<FechaFeriado> FechasFeriados => Set<FechaFeriado>();
        public DbSet<Numerador> Numeradores => Set<Numerador>();
        public DbSet<Boca> Bocas => Set<Boca>();
        public DbSet<Cobranza> Cobranzas => Set<Cobranza>();
        public DbSet<CuentaCorriente> CuentasCorrientes => Set<CuentaCorriente>();
        public DbSet<DetalleCobranza> DetallesCobranzas => Set<DetalleCobranza>();
        public DbSet<ImpuestoBoca> ImpuestosBocas => Set<ImpuestoBoca>();
        public DbSet<Incidencia> Incidencias => Set<Incidencia>();
        public DbSet<NumeroDisponible> NumerosDisponibles => Set<NumeroDisponible>();
        public DbSet<Precio> Precios => Set<Precio>();
        public DbSet<Tanque> Tanques => Set<Tanque>();
        public DbSet<MovimientoStock> MovimientosStocks => Set<MovimientoStock>();
        public DbSet<MovimientoStockAnulado> MovimientosStocksAnulados => Set<MovimientoStockAnulado>();
        public DbSet<Stock> Stocks => Set<Stock>();
        public DbSet<Recibo> Recibos => Set<Recibo>();
        public DbSet<Remito> Remitos => Set<Remito>();
        public DbSet<Valor> Valores => Set<Valor>();
        public DbSet<Factura> Facturas => Set<Factura>();
        public DbSet<Pedido> Pedidos => Set<Pedido>();
        public DbSet<Entrega> Entregas => Set<Entrega>();
        public DbSet<RazonDeNoAbastecido> RazonesDeNoAbastecidos => Set<RazonDeNoAbastecido>();
        public DbSet<ImpuestoFactura> ImpuestosFacturas => Set<ImpuestoFactura>();
        public DbSet<DetalleMovimientoStock> DetallesMovimientosStocks => Set<DetalleMovimientoStock>();
        public DbSet<DetalleAplicacionRecibo> DetallesAplicacionesRecibos => Set<DetalleAplicacionRecibo>();
        public DbSet<DetalleEntrega> DetallesEntregas => Set<DetalleEntrega>();
        public DbSet<DetalleEntregaDocumento> DetallesEntregasDocumentos => Set<DetalleEntregaDocumento>();
        public DbSet<DetalleFactura> DetallesFacturas => Set<DetalleFactura>();
        public DbSet<DetallePedido> DetallesPedidos => Set<DetallePedido>();
        public DbSet<DetalleRemito> DetallesRemitos => Set<DetalleRemito>();
        public DbSet<DetalleEntregaTanque> DetallesEntregasTanques => Set<DetalleEntregaTanque>();
        #endregion
        public HandHeldSdfDbContext(DbContextOptions<HandHeldSdfDbContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            #region Configuration/Models/MocksBusiness
            builder.ApplyConfiguration(new MockBancoConfiguration());
            builder.ApplyConfiguration(new MockCategoriaSegunFiscoConfiguration());
            builder.ApplyConfiguration(new MockDespachoConfiguration());
            builder.ApplyConfiguration(new MockEstadoArticuloConfiguration());
            builder.ApplyConfiguration(new MockGeoPosicionConfiguration());
            builder.ApplyConfiguration(new MockImpuestoConfiguration());
            builder.ApplyConfiguration(new MockMotivoEntregaConfiguration());
            builder.ApplyConfiguration(new MockNegocioConfiguration());
            builder.ApplyConfiguration(new MockPaisConfiguration());
            builder.ApplyConfiguration(new MockPantallaConfiguration());
            builder.ApplyConfiguration(new MockPatenteConfiguration());
            builder.ApplyConfiguration(new MockProcesoConfiguration());
            builder.ApplyConfiguration(new MockProntoPagoConfiguration());
            builder.ApplyConfiguration(new MockProveedorConfiguration());
            builder.ApplyConfiguration(new MockTipoDeViajeConfiguration());
            builder.ApplyConfiguration(new MockTipoDocumentoConfiguration());
            builder.ApplyConfiguration(new MockTipoIncidenciaConfiguration());
            builder.ApplyConfiguration(new MockTipoPedidoConfiguration());
            builder.ApplyConfiguration(new MockTipoRazonDeNoAbastecidoConfiguration());
            builder.ApplyConfiguration(new MockUnidadConfiguration());
            builder.ApplyConfiguration(new MockUsuarioConfiguration());
            builder.ApplyConfiguration(new MockZonaConfiguration());
            builder.ApplyConfiguration(new MockArticuloConfiguration());
            builder.ApplyConfiguration(new MockBocaDespachoConfiguration());
            builder.ApplyConfiguration(new MockFactorDeConversionConfiguration());
            builder.ApplyConfiguration(new MockMenuConfiguration());
            builder.ApplyConfiguration(new MockParametroConfiguration());
            builder.ApplyConfiguration(new MockPlantaConfiguration());
            builder.ApplyConfiguration(new MockPDAConfiguration());
            builder.ApplyConfiguration(new MockRegionComercialConfiguration());
            builder.ApplyConfiguration(new MockSucursalConfiguration());
            builder.ApplyConfiguration(new MockTipoOperacionConfiguration());
            builder.ApplyConfiguration(new MockTitularConfiguration());
            builder.ApplyConfiguration(new MockTraduccionConfiguration());
            builder.ApplyConfiguration(new MockViaDePagoConfiguration());
            builder.ApplyConfiguration(new MockViajeConfiguration());
            builder.ApplyConfiguration(new MockZonaXViajeConfiguration());
            builder.ApplyConfiguration(new MockAlmacenConfiguration());
            builder.ApplyConfiguration(new MockDocumentoConfiguration());
            builder.ApplyConfiguration(new MockDocumentoAnuladoConfiguration());
            builder.ApplyConfiguration(new MockFechaFeriadoConfiguration());
            builder.ApplyConfiguration(new MockNumeradorConfiguration());
            builder.ApplyConfiguration(new MockBocaConfiguration());
            builder.ApplyConfiguration(new MockCobranzaConfiguration());
            builder.ApplyConfiguration(new MockCuentaCorrienteConfiguration());
            builder.ApplyConfiguration(new MockDetalleCobranzaConfiguration());
            builder.ApplyConfiguration(new MockImpuestoBocaConfiguration());
            builder.ApplyConfiguration(new MockIncidenciaConfiguration());
            builder.ApplyConfiguration(new MockNumeroDisponibleConfiguration());
            builder.ApplyConfiguration(new MockPrecioConfiguration());
            builder.ApplyConfiguration(new MockTanqueConfiguration());
            builder.ApplyConfiguration(new MockMovimientoStockConfiguration());
            builder.ApplyConfiguration(new MockMovimientoStockAnuladoConfiguration());
            builder.ApplyConfiguration(new MockStockConfiguration());
            builder.ApplyConfiguration(new MockReciboConfiguration());
            builder.ApplyConfiguration(new MockRemitoConfiguration());
            builder.ApplyConfiguration(new MockValorConfiguration());
            builder.ApplyConfiguration(new MockPedidoConfiguration());
            builder.ApplyConfiguration(new MockEntregaConfiguration());
            builder.ApplyConfiguration(new MockFacturaConfiguration());
            builder.ApplyConfiguration(new MockRazonDeNoAbastecidoConfiguration());
            builder.ApplyConfiguration(new MockImpuestoFacturaConfiguration());
            builder.ApplyConfiguration(new MockDetalleMovimientoStockConfiguration());
            builder.ApplyConfiguration(new MockDetalleAplicacionReciboConfiguration());
            builder.ApplyConfiguration(new MockDetalleEntregaConfiguration());
            builder.ApplyConfiguration(new MockDetalleEntregaDocumentoConfiguration());
            builder.ApplyConfiguration(new MockDetalleFacturaConfiguration());
            builder.ApplyConfiguration(new MockDetallePedidoConfiguration());
            builder.ApplyConfiguration(new MockDetalleRemitoConfiguration());
            builder.ApplyConfiguration(new MockDetalleEntregaTanqueConfiguration());
            #endregion
            base.OnModelCreating(builder);
        }
    }
}
