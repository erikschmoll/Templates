﻿using HandHeld.PDAManagement.DataAccess.Layer.DbContexts;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Options;
using HandHeld.PDAManagement.DataAccess.Layer.Providers;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.Mock;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Implementations.DataBase.YPFGas;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.YPFGas;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.WebServices;
using HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Implementations;
using HandHeld.Shared.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Runtime.CompilerServices;
using HandHeld.PDAManagement.DataAccess.Layer.SqlServerConnection.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.SqlServerConnection.Implementations;

[assembly: InternalsVisibleTo("HandHeld.PDAManagement.Business.Layer")]
namespace HandHeld.PDAManagement.DataAccess.Layer
{
    internal static class DataAccessModule
    {
        public static IServiceCollection AddDataAccessModule(this IServiceCollection services, IConfiguration configuration)
        {
            string connectionString = configuration.GetConnectionString("Default");
            string connectionStringSdf = configuration.GetConnectionString("Sdf"); 
            string connectionStringYPFGas = configuration.GetConnectionString("YPFGas_HH");

            services.AddAutoMapper(typeof(ActualizacionRepository));
            services.AddDbContext<HandHeldDbContext>(options => options.UseSqlServer(connectionString));
            services.AddDbContext<HandHeldSdfDbContext>(options => options.UseSqlServer(connectionStringSdf));
            services.AddScoped<HandHeldSQLiteDbContextFactory>();
            services.AddHttpClient("usuarios", options =>
            {
                options.BaseAddress = new Uri("https://jsonplaceholder.typicode.com/users");
            }); 

            //hasta no tener los servicios definidos, los mocks quedan fuera del if
            #region Mock
            services.AddScoped<MockAlmacenRepository>();
            services.AddScoped<MockArticuloRepository>();
            services.AddScoped<MockBancoRepository>();
            services.AddScoped<MockBocaDespachoRepository>();
            services.AddScoped<MockBocaRepository>();
            services.AddScoped<MockCategoriaSegunFiscoRepository>();
            services.AddScoped<MockCobranzaRepository>();
            services.AddScoped<MockCuentaCorrienteRepository>();
            services.AddScoped<MockDespachoRepository>();
            services.AddScoped<MockDetalleAplicacionReciboRepository>();
            services.AddScoped<MockDetalleCobranzaRepository>();
            services.AddScoped<MockDetalleEntregaDocumentoRepository>();
            services.AddScoped<MockDetalleEntregaRepository>();
            services.AddScoped<MockDetalleEntregaTanqueRepository>();
            services.AddScoped<MockDetalleFacturaRepository>();
            services.AddScoped<MockDetalleMovimientoStockRepository>();
            services.AddScoped<MockDetallePedidoRepository>();
            services.AddScoped<MockDetalleRemitoRepository>();
            services.AddScoped<MockDocumentoAnuladoRepository>();
            services.AddScoped<MockDocumentoRepository>();
            services.AddScoped<MockEntregaRepository>();
            services.AddScoped<MockEstadoArticuloRepository>();
            services.AddScoped<MockFactorDeConversionRepository>();
            services.AddScoped<MockFacturaRepository>();
            services.AddScoped<MockFechaFeriadoRepository>();
            services.AddScoped<MockGeoPosicionRepository>();
            services.AddScoped<MockImpuestoBocaRepository>();
            services.AddScoped<MockImpuestoFacturaRepository>();
            services.AddScoped<MockImpuestoRepository>();
            services.AddScoped<MockIncidenciaRepository>();
            services.AddScoped<MockMenuRepository>();
            services.AddScoped<MockMotivoEntregaRepository>();
            services.AddScoped<MockMovimientoStockAnuladoRepository>();
            services.AddScoped<MockMovimientoStockRepository>();
            services.AddScoped<MockNegocioRepository>();
            services.AddScoped<MockNumeradorRepository>();
            services.AddScoped<MockNumeroDisponibleRepository>();
            services.AddScoped<MockPaisRepository>();
            services.AddScoped<MockPantallaRepository>();
            services.AddScoped<MockParametroRepository>();
            services.AddScoped<MockPatenteRepository>();
            services.AddScoped<MockPDARepository>();
            services.AddScoped<MockPedidoRepository>();
            services.AddScoped<MockPlantaRepository>();
            services.AddScoped<MockPrecioRepository>();
            services.AddScoped<MockProcesoRepository>();
            services.AddScoped<MockProntoPagoRepository>();
            services.AddScoped<MockProveedorRepository>();
            services.AddScoped<MockRazonDeNoAbastecidoRepository>();
            services.AddScoped<MockReciboRepository>();
            services.AddScoped<MockRegionComercialRepository>();
            services.AddScoped<MockRemitoRepository>();
            services.AddScoped<MockStockRepository>();
            services.AddScoped<MockSucursalRepository>();
            services.AddScoped<MockTanqueRepository>();
            services.AddScoped<MockTipoDeViajeRepository>();
            services.AddScoped<MockTipoDocumentoRepository>();
            services.AddScoped<MockTipoIncidenciaRepository>();
            services.AddScoped<MockTipoOperacionRepository>();
            services.AddScoped<MockTipoPedidoRepository>();
            services.AddScoped<MockTipoRazonDeNoAbastecidoRepository>();
            services.AddScoped<MockTitularRepository>();
            services.AddScoped<MockTraduccionRepository>();
            services.AddScoped<MockUnidadRepository>();
            services.AddScoped<MockUsuarioRepository>();
            services.AddScoped<MockValorRepository>();
            services.AddScoped<MockViaDePagoRepository>();
            services.AddScoped<MockViajeRepository>();
            services.AddScoped<MockZonaRepository>();
            services.AddScoped<MockZonaXViajeRepository>();
            #endregion

            if (InfrastructureModule.GetEnvironment().Equals("Development"))
            {
                services.AddScoped<IStorageService, FirebaseStorageProvider>();
            }
            else
            {
                services.AddScoped<IStorageService, AzureStorageProvider>();

            }

            services.AddScoped<IUnitOfWorkDapper, UnitOfWorkDapper>();
            services.AddScoped<IUnitOfWork, UnitOfWork.Implementations.UnitOfWork>();
            services.AddScoped<IDbSqlConnection,DbSqlConnection>();
            services.AddSingleton<IColaPendientesRepository, ColaPendientesRepository>();
            services.AddScoped<IInicializadorDataAccess, InicializadorDataAccess>();

            #region Repositories

            services.AddScoped<IConfiguracionRepository, ConfiguracionRepository>();
            services.AddScoped<IInstalacionRepository, InstalacionRepository>();

            #endregion
            #region Options
            services.Configure<StoragesOptions>(configuration.GetSection(StoragesOptions.Key));
            #endregion
            return services;
        }
    }
}
