﻿
namespace HandHeld.PDAManagement.DataAccess.Layer.Utilities
{
    internal static class Generator
    {
        private static int SIZE_N = 5;// no debe ser mayor que 5
        private static int DIGITS_0_T0_9 = 9;
        private static Dictionary<string, int> M = new (){
                { "A", 1 },{ "B", 2 },{ "C", 3 },{ "D", 4 },{ "E", 5 },{ "F", 6 },{ "G", 7 },
                { "H", 8 },{ "I", 9 },{ "J", 10 },{ "K", 11 },{ "L", 12 },{ "M", 13 },{ "N", 14 },
                { "O", 15 },{ "P", 16 },{ "Q", 17 },{ "R", 18 },{ "S", 19 },{ "T", 20 },{ "U", 21 },
                { "V", 22 },{ "W", 23 },{ "X", 24 },{ "Y", 25 },{ "Z", 26 },
                { "1", 1 },{ "2", 2 },{ "3", 3 },{ "4", 4 },{ "5", 5 },{ "6", 6 },{ "7", 7 },
                { "8", 8 },{ "9", 9 },{ "0", 0 }
            };

        public static int PIN()
        {
            //https://stackoverflow.com/questions/968175/what-is-the-string-length-of-a-guid
            var guid = Guid.NewGuid().ToString("N").ToUpper();//32 characters

            var seed0 = guid.Substring(SIZE_N * 0, SIZE_N);
            var seed1 = guid.Substring(SIZE_N * 1, SIZE_N);
            var seed2 = guid.Substring(SIZE_N * 2, SIZE_N);
            var seed3 = guid.Substring(SIZE_N * 3, SIZE_N);
            var seed4 = guid.Substring(SIZE_N * 4, SIZE_N);
            var seed5 = guid.Substring(SIZE_N * 5, SIZE_N); //max substr 5*5+5=30

            //digits
            var x0 = fn(seed0);
            var x1 = fn(seed1);
            var x2 = fn(seed2);
            var x3 = fn(seed3);
            var x4 = fn(seed4);
            var x5 = fn(seed5);
            return int.Parse($"{x0}{x1}{x2}{x3}{x4}{x5}");
        }
        private static int fn(string seed)
        {
            List<int> Acum = new List<int>();
            foreach (char charSeed in seed)
            {
                var charSeedToString = charSeed.ToString();
                if (M.ContainsKey(charSeedToString))
                {
                    Acum.Add(M[charSeedToString]);
                }
                else
                {
                    throw new Exception("Caracter inválido al generar PIN");
                }
            }
            return Acum.Sum() % DIGITS_0_T0_9;
        }
    }
}
