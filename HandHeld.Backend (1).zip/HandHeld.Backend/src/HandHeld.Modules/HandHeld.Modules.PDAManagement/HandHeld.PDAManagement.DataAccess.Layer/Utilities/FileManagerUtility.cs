﻿
using HandHeld.Shared.Infrastructure;

namespace HandHeld.PDAManagement.DataAccess.Layer.Utilities
{
    public static class FileManagerUtility
    {
        public static void CreatePath(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }
        public static string GetDefaultDirectory()
        {
            string path = Directory.GetCurrentDirectory();
            if (InfrastructureModule.StaticConfig is not null)
            {
                path = InfrastructureModule.StaticConfig
                    .GetSection("Storages:TemporaryDirectory").Value ?? path;
            }
            return path;
        }
        public static void DeleteFile(string path, string name)
        {
            string file = $"{path}\\{name}";
            if (File.Exists(file))
            {
                File.Delete(file);
            }
        }

        public static string CreateNewPath(string dir)
        {
            string path = $"{GetDefaultDirectory()}\\{dir}";
            CreatePath(path);
            return path;
        }
    }
}
