﻿
namespace HandHeld.PDAManagement.DataAccess.Layer.Utilities
{
    public static class GuidUtility
    {
        public static string NewGuid()
        {
            return Guid.NewGuid().ToString().ToUpper();
        }
    }
}
