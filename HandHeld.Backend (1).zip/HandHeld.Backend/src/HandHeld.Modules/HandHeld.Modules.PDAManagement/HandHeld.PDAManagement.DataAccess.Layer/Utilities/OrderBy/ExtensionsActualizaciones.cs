﻿using HandHeld.PDAManagement.DataAccess.Layer.Utilities.OrderBy.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDAManagement.DataAccess.Layer.Utilities.OrderBy
{
    public static class ExtensionsActualizaciones
    {
        public static IOrderedQueryable<T> OrderBy<T>(this IQueryable<T> source, IOrderBy orderBy)
        {
            return Queryable.OrderBy(source, orderBy.Actualizaciones);
        }

        public static IOrderedQueryable<T> OrderByDescending<T>(this IQueryable<T> source, IOrderBy orderBy)
        {
            return Queryable.OrderByDescending(source, orderBy.Actualizaciones);
        }

        public static IOrderedQueryable<T> ThenBy<T>(this IOrderedQueryable<T> source, IOrderBy orderBy)
        {
            return Queryable.ThenBy(source, orderBy.Actualizaciones);
        }

        public static IOrderedQueryable<T> ThenByDescending<T>(this IOrderedQueryable<T> source, IOrderBy orderBy)
        {
            return Queryable.ThenByDescending(source, orderBy.Actualizaciones);
        }
    }
}
