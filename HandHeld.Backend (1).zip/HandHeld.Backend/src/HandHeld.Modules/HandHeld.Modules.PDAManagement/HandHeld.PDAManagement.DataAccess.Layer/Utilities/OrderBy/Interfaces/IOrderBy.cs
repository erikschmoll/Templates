﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDAManagement.DataAccess.Layer.Utilities.OrderBy.Interface
{
    public interface IOrderBy
    {
        dynamic Actualizaciones { get; }
    }
}
