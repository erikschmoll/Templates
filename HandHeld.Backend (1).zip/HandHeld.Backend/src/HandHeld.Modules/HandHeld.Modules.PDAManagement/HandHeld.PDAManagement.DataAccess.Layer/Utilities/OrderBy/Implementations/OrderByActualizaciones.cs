﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HandHeld.PDAManagement.DataAccess.Layer.Utilities.OrderBy.Interface;
using System;
using System.Linq.Expressions;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;

namespace HandHeld.PDAManagement.DataAccess.Layer.Utilities.OrderBy.Implementations
{
    public class OrderByActualizaciones<T> : IOrderBy
    {
        private readonly Expression<Func<Actualizacion, T>> _actualizaciones;

        public OrderByActualizaciones(Expression<Func<Actualizacion, T>> Actualizaciones)
        {
            _actualizaciones = Actualizaciones;
        }

        public dynamic Actualizaciones => _actualizaciones;
    }
}
