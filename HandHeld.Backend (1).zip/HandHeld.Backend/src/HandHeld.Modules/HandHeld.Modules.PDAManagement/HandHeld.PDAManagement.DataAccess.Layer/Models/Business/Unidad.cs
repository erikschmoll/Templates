﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Unidad
    {
        [Description("IDUnidadMedidaBackOffice")]
        public string Id { get; set; }

        [Description("UnidadMedida")]
        public string Nombre { get; set; }

        public string Simbolo { get; set; }

        public string TipoUnidad { get; set; }

        public Unidad()
        {
            Id =
            Nombre =
            Simbolo =
            TipoUnidad = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "UnidadMedida_Custom_Query_All_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
