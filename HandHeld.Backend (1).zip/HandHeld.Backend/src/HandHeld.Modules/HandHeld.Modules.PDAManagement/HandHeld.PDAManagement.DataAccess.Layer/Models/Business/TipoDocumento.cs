﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class TipoDocumento
    {
        [Description("IDTipoDocumento")]
        public string Id { get; set; }

        [Description("TipoDocumento")]
        public string Nombre { get; set; }

        public string TipoDocumentoPDA { get; set; }
        public int CantidadCopias { get; set; }
        public int ImpresionObligatoria { get; set; }
        public bool ReimprimirSoloDelUltimoCliente { get; set; }
        public bool PuedeSerReimpreso { get; set; }
        public bool PuedeSerAnulado { get; set; }

        [Description("AnuladoSoloDelUltimoCliente")]
        public bool AnularSoloDelUltimoCliente { get; set; }

        public TipoDocumento()
        {
            Id =
            Nombre =
            TipoDocumentoPDA = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "TipoDocumento_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
