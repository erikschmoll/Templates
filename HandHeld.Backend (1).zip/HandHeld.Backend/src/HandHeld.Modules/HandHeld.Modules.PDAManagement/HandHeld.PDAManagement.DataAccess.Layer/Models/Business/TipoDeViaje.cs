﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class TipoDeViaje
    {
        [Description("IDTipoViaje")]
        public string Id { get; set; }


        [Description("TipoViaje")]
        public string Nombre { get; set; }


        [Description("IDTipoViajeBackOffice")]
        public string IdClaseSAP { get; set; }

        public TipoDeViaje()
        {
            Id =
            Nombre =
            IdClaseSAP = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "TipoViaje_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
