﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class FactorDeConversion
    {
        public string IdUnidadDesde { get; set; }
        public string IdUnidadHacia { get; set; }
        public int Numerador { get; set; }
        public int Denominador { get; set; }

        public FactorDeConversion()
        {
            IdUnidadDesde =
            IdUnidadHacia = string.Empty;
        }
        public virtual Unidad? UnidadDesde { get; set; }
        public virtual Unidad? UnidadHacia { get; set; }
    }
}
