﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Planta
    {
        [Description("IDSitioBackOffice")]
        public string Id { get; set; }
        
        [Description("Sitio")]
        public string Nombre { get; set; }
        
        [Description("Direccion")]
        public string Direccion { get; set; }
        
        [Description("CodigoPostal")]
        public string CodigoPostal { get; set; }
        
        [Description("Poblacion")]
        public string Poblacion { get; set; }
        
        [Description("Telefono")]
        public string Telefono { get; set; }
        
        [Description("RazonSocialEmpresa")]
        public string RazonSocialEmpresa { get; set; }
        
        [Description("RazonSocialSucursal")]
        public string RazonSocialSucursal { get; set; }
        
        [Description("Cuit")]
        public string IdentificadorFiscal { get; set; }
        
        [Description("IngresosBrutos")]
        public string NumeroIngresosBrutos { get; set; }
        
        [Description("AgentePercepcion")]
        public string NumeroDeAgentePercepcion { get; set; }
        
        [Description("SedeTimbrado")]
        public string SedeTimbrado { get; set; }
        
        public int DiasSegundoVencimiento { get; set; }
        
        public Decimal TasaSegundoVencimiento { get; set; }
        
        public Decimal IvaFinanciero { get; set; }
        
        [Description("IDRegionBackOffice")]
        public string CodigoRegionGeografica { get; set; }
        
        public string TipoRegionGeografica { get; set; }
        
        [Description("IDPaisBackOffice")]
        public string IdPais { get; set; }

        public Planta()
        {
            Id =
            Nombre =
            Direccion =
            CodigoPostal =
            Poblacion =
            Telefono =
            RazonSocialEmpresa =
            RazonSocialSucursal =
            IdentificadorFiscal =
            NumeroIngresosBrutos =
            NumeroDeAgentePercepcion =
            SedeTimbrado =
            CodigoRegionGeografica =
            TipoRegionGeografica =
            IdPais = string.Empty;
        }
        public virtual List<Pais?> Pais { get; set; }
        public virtual List<RegionComercial?> Region { get; set; }

        [NotMapped]
        public static string Query { get { return "USE YPFGas_HH SELECT S.IDSitioBackOffice, " +
                        "S.Direccion, " +
                        "S.Sitio, " +
                        "S.CodigoPostal, " +
                        "S.Poblacion, " +
                        "S.Telefono, " +
                        "S.RazonSocialEmpresa, " +
                        "S.RazonSocialSucursal, " +
                        "S.Cuit, " +
                        "S.IngresosBrutos, " +
                        "S.AgentePercepcion, " +
                        "S.SedeTimbrado, " +
                        "ISNULL(S.DiasSegundoVto, 0) AS DiasSegundoVto, " +
                        "ISNULL(S.TasaSegundoVto, 0) AS TasaSegundoVto, " +
                        "ISNULL(S.IvaFinanciero, 0) AS IvaFinanciero, " +
                        "R.IDRegionBackOffice, " +
                        "' ', " +
                        "P.IDPaisBackOffice " +
                        "FROM[dbo].[Sitio] S " +
                        "INNER JOIN[dbo].[Pais] P ON(P.IDPais = S.IDPais) " +
                        "INNER JOIN[dbo].[Region] R ON(R.IDRegion = S.IDRegion) " +
                        "WHERE S.Activo = 1"; } }

        [NotMapped]
        public static bool IsSP { get { return false; } }
    }
}
