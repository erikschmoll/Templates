﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class CuentaCorriente
    {
        public string IdBoca { get; set; }
        public string NroDocumentoSAP { get; set; }
        public int Ejercicio { get; set; }
        public int Posicion { get; set; }
        public string ClaseDocumentoSAP { get; set; }
        public string Serie { get; set; }
        public Decimal Numero { get; set; }
        public string IdTipoDocumento { get; set; }
        public bool TieneAplicacionParcial { get; set; }
        public DateTime FechaModificacion { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public Decimal Importe { get; set; }
        public DateTime FechaSegundoVencimiento { get; set; }
        public Decimal ImporteSegundoVencimiento { get; set; }
        public DateTime FechaProntoPago { get; set; }
        public Decimal ImporteProntoPago { get; set; }
        public string IdMonedaImportes { get; set; }

        public CuentaCorriente()
        {
            IdBoca =
            NroDocumentoSAP =
            ClaseDocumentoSAP =
            Serie =
            IdTipoDocumento =
            IdMonedaImportes = string.Empty;
        }
        public virtual Boca? Boca { get; set; }
        public virtual TipoDocumento? TipoDocumento { get; set; }
        public virtual Unidad? MonedaImportes { get; set; }
    }
}
