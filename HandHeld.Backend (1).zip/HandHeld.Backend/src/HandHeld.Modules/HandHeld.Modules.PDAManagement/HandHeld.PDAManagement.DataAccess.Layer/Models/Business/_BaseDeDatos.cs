﻿
namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class _BaseDeDatos
    {
        public static string DB = "glp.db";
        public string Id { get; set; }
        public string Nombre { get; set; }
        public long Version { get; set; }

        public _BaseDeDatos()
        {
            Id = Nombre = string.Empty;
        }

    }
}
