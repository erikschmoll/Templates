﻿
namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class DetalleMovimientoStock
    {
        public int IdMovimiento { get; set; }
        public string IdArticulo { get; set; }
        public Decimal Cantidad { get; set; }
        public string IdUnidad { get; set; }
        public Decimal Densidad { get; set; }
        public string IdViaje { get; set; }

        public DetalleMovimientoStock()
        {
            IdArticulo =
            IdUnidad =
            IdViaje = string.Empty;
        }
        public virtual Unidad? Unidad { get; set; }
        public virtual Articulo? Articulo { get; set; }
        public virtual MovimientoStock? MovimientoStock { get; set; }
    }
}
