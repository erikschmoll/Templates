﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class ZonaXViaje
    {
        public string IdZona { get; set; }
        public string IdViaje { get; set; }

        public ZonaXViaje()
        {
            IdZona =
            IdViaje = string.Empty;
        }
        public virtual Zona? Zona { get; set; }
        public virtual Viaje? Viaje { get; set; }
    }
}
