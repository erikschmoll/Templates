﻿
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class TipoOperacion
    {
        [Description("IDTipoOperacionBackOffice")]
        public string Id { get; set; }

        [Description("TipoOperacion")]
        public string Nombre { get; set; }

        [Description("Signo")]
        public int Signo { get; set; }

        [Description("PuedeCambiarUnidad")]
        public bool PuedeCambiarUnidad { get; set; }

        [Description("IDUnidadMedidaBackOffice")]
        public string IdUnidadPreferida { get; set; }

        public TipoOperacion()
        {
            Id =
            IdUnidadPreferida =
            Nombre =
            IdUnidadPreferida = string.Empty;
        }
        public virtual Unidad? Unidad { get; set; }

        [NotMapped]
        public static string Query { get { return "TipoOperacion_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
