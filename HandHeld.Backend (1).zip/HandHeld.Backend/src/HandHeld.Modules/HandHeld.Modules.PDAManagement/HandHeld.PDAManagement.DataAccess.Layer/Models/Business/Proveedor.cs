﻿
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Proveedor
    {
        [Description("IDProveedorBackOffice")]
        public string Id { get; set; }


        [Description("Proveedor")]
        public string Nombre { get; set; }

        public Proveedor()
        {
            Id =
            Nombre = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "Proveedor_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
