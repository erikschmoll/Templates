﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Incidencia
    {
        public int IdIncidencia { get; set; }
        public DateTime Fecha { get; set; }
        public string Observaciones { get; set; }
        public string IdTipoIncidencia { get; set; }
        public string IdBoca { get; set; }
        public string IdViaje { get; set; }
        public int IdGeoPosicion { get; set; }

        public Incidencia()
        {
            Observaciones =
            IdTipoIncidencia =
            IdBoca =
            IdViaje = string.Empty;
        }
        public virtual Viaje? Viaje { get; set; }
        public virtual TipoIncidencia? TipoIncidencia { get; set; }
        public virtual Boca? Boca { get; set; }
        public virtual GeoPosicion? GeoPosicion { get; set; }
    }
}
