﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Entrega
    {
        public int Id { get; set; }
        public Decimal Kilometros { get; set; }
        public Decimal KilosFinal { get; set; }
        public Decimal KilosInicial { get; set; }
        public Decimal LitrajeFinal { get; set; }
        public Decimal LitrajeInicial { get; set; }
        public DateTime Fecha { get; set; }
        public string IdViaje { get; set; }
        public string IdPedido { get; set; }
        public int IdGeoPosicionInicial { get; set; }
        public string IdBoca { get; set; }
        public int IdGeoPosicionFinal { get; set; }

        public Entrega()
        {
            IdViaje =
            IdPedido =
            IdBoca = string.Empty;
        }
        public virtual Viaje? Viaje { get; set; }
        public virtual GeoPosicion? GeoPosicionInicial { get; set; }
        public virtual Boca? Boca { get; set; }
        public virtual GeoPosicion? GeoPosicionFinal { get; set; }
        public virtual Pedido? Pedido { get; set; }

    }
}
