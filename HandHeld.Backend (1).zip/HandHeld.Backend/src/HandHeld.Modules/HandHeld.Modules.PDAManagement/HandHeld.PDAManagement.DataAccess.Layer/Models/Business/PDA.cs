﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class PDA
    {
        [Description("IDPaisBackOffice")]
        public string IdPais { get; set; }

        [Description("IDNegocioBackOffice")]
        public string IdNegocio { get; set; }

        [Description("Patente")]
        public string IdPatenteTractor { get; set; }

        [Description("IDSitioBackOffice")]
        public string IdPlanta { get; set; }

        [Description("IdPatenteTanque")]
        public string IdPatenteTanque { get; set; }

        public PDA()
        {
            IdPais =
            IdNegocio =
            IdPatenteTractor =
            IdPlanta =
            IdPatenteTanque = string.Empty;
        }
        public virtual Pais? Pais { get; set; }
        public virtual Negocio? Negocio { get; set; }
        public virtual Patente? PatenteTractor { get; set; }
        public virtual Planta? Planta { get; set; }
        public virtual Patente? PatenteTanque { get; set; }

        [NotMapped]
        public static string Query { get { return "USE YPFGas_HH SELECT " +
                        "P.IDPaisBackOffice, " +
                        "N.IDNegocioBackOffice, " +
                        "S.IDSitioBackOffice, " +
                        "V.Patente AS IdPatenteTanque " +
                        "FROM PDA PD " +
                        "INNER JOIN Pais P ON(P.IDPais = PD.IDPais) " +
                        "INNER JOIN Negocio N ON(N.IDNegocio = PD.IDNegocio) " +
                        "INNER JOIN Vehiculo V ON(V.IDVehiculo = PD.IDVehiculo) " +
                        "INNER JOIN Sitio S ON(S.IDSitio = PD.IDPlanta) " +
                        "WHERE PD.IDVehiculo = @iIDVehiculo AND Estado = 1"; } }

        [NotMapped]
        public static bool IsSP { get { return false; } }
    }
}
