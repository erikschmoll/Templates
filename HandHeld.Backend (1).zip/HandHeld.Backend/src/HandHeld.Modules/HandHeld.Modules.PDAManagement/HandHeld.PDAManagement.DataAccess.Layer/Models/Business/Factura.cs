﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Factura
    {
        public int Id { get; set; }
        public Decimal Numero { get; set; }
        public string Serie { get; set; }
        public Decimal BonificacionProntoPago { get; set; }
        public int DiasProntoPago { get; set; }
        public int DiasSegundoVencimiento { get; set; }
        public DateTime Fecha { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public Decimal InteresSegundoVencimiento { get; set; }
        public Decimal MontoNeto { get; set; }
        public Decimal MontoTotal { get; set; }
        public string IdViaje { get; set; }
        public int IdEntrega { get; set; }
        public int IdGeoPosicion { get; set; }
        public string IdBoca { get; set; }

        public Factura()
        {
            Serie =
            IdViaje =
            IdBoca = string.Empty;
        }
        public virtual Documento? Documento { get; set; }
        public virtual Entrega? Entrega { get; set; }
        public virtual GeoPosicion? GeoPosicion { get; set; }
        public virtual Boca? Boca { get; set; }
    }
}
