﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class RazonDeNoAbastecido
    {
        public int Secuencia { get; set; }
        public DateTime Fecha { get; set; }
        public string Observaciones { get; set; }
        public string IdViaje { get; set; }
        public string IdPedido { get; set; }
        public int IdGeoPosicion { get; set; }
        public string IdTipoRazonDeNoAbastecido { get; set; }

        public RazonDeNoAbastecido()
        {
            Observaciones =
            IdViaje =
            IdPedido =
            IdTipoRazonDeNoAbastecido = string.Empty;
        }
        public virtual GeoPosicion? GeoPosicion { get; set; }
        public virtual TipoRazonDeNoAbastecido? TipoRazonDeNoAbastecido { get; set; }
        public virtual Pedido? Pedido { get; set; }
    }
}
