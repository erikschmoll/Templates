﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Articulo
    {
        public string Id { get; set; }
        public string Nombre { get; set; }
        public string IdUnidadPreferidaCompra { get; set; }
        public string IdUnidadPreferidaVenta { get; set; }
        public Decimal DensidadOficial { get; set; }
        public string IdUnidadPreferidaStock { get; set; }
        public bool EsEnvasado { get; set; }
        public string TipoArticulo { get; set; }
        public Articulo()
        {
            Id =
            Nombre =
            IdUnidadPreferidaCompra =
            IdUnidadPreferidaVenta =
            IdUnidadPreferidaStock =
            TipoArticulo = string.Empty;
        }
        public virtual Unidad? UnidadPreferidaCompra { get; set; }
        public virtual Unidad? UnidadPreferidaVenta { get; set; }
        public virtual Unidad? UnidadPreferidaStock { get; set; }

        [NotMapped]
        public static string Query { get { return "USE YPFGas_HH SELECT " +

                        "IDMaterialBackOffice AS Id, " +
                        "Material AS Nombre, " +
                        "'KG' AS IdUnidadPreferidaCompra, " +
                        "IDUnidadMedidaBackOffice AS IdUnidadPreferidaVenta, " +
                        "0 AS DensidadOficial , " +
                        "'KG' AS IdUnidadPreferidaStock, " +
                        "CASE IDNegocio  WHEN 1 THEN 0 ELSE 1 END AS EsEnvasado, " +
                        "ISNULL(IDCategoriaMaterial, ' ') AS TipoArticulo " +

                        "FROM[dbo].[Material] M " +
                        "INNER JOIN[dbo].[UnidadMedida] U ON(U.IDUnidadMedida = M.IDUnidadMedida) " +
                        "WHERE IDNegocio = 1 " +
                        "AND M.Activo = 1 " +

                        "UNION " +

                        "SELECT " +

                        "IDMaterialBackOffice AS Id, " +
                        "Material AS Nombre, " +
                        "IDUnidadMedidaBackOffice AS IdUnidadPreferidaCompra, " +
                        "IDUnidadMedidaBackOffice AS IdUnidadPreferidaVenta, " +
                        "0 AS DensidadOficial , " +
                        "IDUnidadMedidaBackOffice AS IdUnidadPreferidaStock, " +
                        "CASE IDNegocio WHEN 1 THEN 0 ELSE 1 END AS EsEnvasado, " +
                        "ISNULL(IDCategoriaMaterial, ' ') AS TipoArticulo " +

                        "FROM[dbo].[Material] M " +
                        "INNER JOIN[dbo].[UnidadMedida] U ON(U.IDUnidadMedida = M.IDUnidadMedida) " +
                        "WHERE IDNegocio = 2 " +
                        "AND M.Activo = 1"; } }

        [NotMapped]
        public static bool IsSP { get { return false; } }

    }
}
