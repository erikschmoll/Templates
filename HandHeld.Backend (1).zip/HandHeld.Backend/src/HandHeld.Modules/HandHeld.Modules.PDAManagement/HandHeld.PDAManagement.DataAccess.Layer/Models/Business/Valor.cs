﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Valor
    {
        public int IdDocumentoRecibo { get; set; }
        public string IdViaje { get; set; }
        public int IdValor { get; set; }
        public DateTime FechaEmision { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public Decimal Importe { get; set; }
        public string Numero { get; set; }
        public string IdUnidadImporte { get; set; }
        public string IdViaDePago { get; set; }
        public string IdBanco { get; set; }
        public string IdSucursal { get; set; }

        public Valor()
        {
            IdViaje =
            Numero =
            IdUnidadImporte =
            IdViaDePago =
            IdBanco =
            IdSucursal = string.Empty;
        }
        public virtual Unidad? UnidadImporte { get; set; }
        public virtual ViaDePago? ViaDePago { get; set; }
        public virtual Sucursal? Sucursal { get; set; }
        public virtual Recibo? Recibo { get; set; }
    }
}
