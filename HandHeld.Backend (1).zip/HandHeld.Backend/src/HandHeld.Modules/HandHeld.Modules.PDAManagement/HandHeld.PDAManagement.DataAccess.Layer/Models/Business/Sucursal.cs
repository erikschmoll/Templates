﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Sucursal
    {
        [Description("IDSucursalBancoBackOffice")]
        public string Id { get; set; }

        [Description("SucursalBanco")]
        public string Nombre { get; set; }

        [Description("IDBancoBackOffice")]
        public string IdBanco { get; set; }


        public Sucursal()
        {
            Id = 
            Nombre =
            IdBanco = string.Empty;
        }
        public virtual Banco? Banco { get; set; }

        [NotMapped]
        public static string Query { get { return "SucursalBanco_Custom_Query_All_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
