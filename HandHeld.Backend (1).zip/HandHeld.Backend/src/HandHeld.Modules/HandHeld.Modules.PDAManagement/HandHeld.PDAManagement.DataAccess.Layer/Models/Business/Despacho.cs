﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Despacho
    {
        public int Id { get; set; }
        public DateTime FechaInicial { get; set; }
        public DateTime FechaFinal { get; set; }
        public Decimal Temperatura { get; set; }
        public Decimal Densidad { get; set; }
        public Decimal LitrosInicial { get; set; }
        public Decimal LitrosFinal { get; set; }
        public Decimal LitrosDespachados { get; set; }
        public Decimal KilosDespachados { get; set; }

    }
}
