﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Patente
    {
        [Description("Patente")]
        public string Id { get; set; }

        [Description("IDTipoVehiculo")]
        public string TipoVehiculo { get; set; }

        [Description("IDTipoVehiculo")]
        public bool TieneMasico { get; set; }

        [Description("IDEmpresaBackOffice")]
        public string EmpresaTransportista { get; set; }

        [Description("Capacidad")]
        public Decimal CapacidadDeCarga { get; set; }

        public Patente()
        {
            Id =
            TipoVehiculo =
            EmpresaTransportista = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "Vehiculo_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
