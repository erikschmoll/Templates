﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class TipoRazonDeNoAbastecido
    {
        [Description("IDTipoRazonNoAbastecidoBackOffice")]
        public string Id { get; set; }

        [Description("RazonNoAbastecido")]
        public string Nombre { get; set; }
        public int Orden { get; set; }

        public TipoRazonDeNoAbastecido()
        {
            Id =
            Nombre = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "TipoRazonNoAbastecido_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
