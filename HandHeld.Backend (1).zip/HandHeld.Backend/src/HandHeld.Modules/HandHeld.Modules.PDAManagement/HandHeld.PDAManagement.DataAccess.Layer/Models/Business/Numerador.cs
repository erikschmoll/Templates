﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Numerador
    {
        public string Serie { get; set; }
        public string IdTipoDocumento { get; set; }
        public Decimal UltimoNumeroUsado { get; set; }
        public string IdViaje { get; set; }
        public Decimal NumeroDesde { get; set; }
        public Decimal NumeroHasta { get; set; }
        public string TipoNumerador { get; set; }
        public string NumeroCAI { get; set; }
        public DateTime FechaVencimientoCAI { get; set; }
        public DateTime FechaInicioActividades { get; set; }

        public Numerador()
        {
            Serie =
            IdTipoDocumento =
            IdViaje =
            TipoNumerador =
            NumeroCAI = string.Empty;
        }
        public virtual Viaje? Viaje { get; set; }
        public virtual TipoDocumento? TipoDocumento { get; set; }
    }
}
