﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Tanque
    {
        [Description("IDTanqueBackOffice")]
        public string Id { get; set; }


        [Description("IDBocaBackOffice")]
        public string IdBoca { get; set; }

        public Decimal Capacidad { get; set; }


        [Description("IDUnidadMedidaBackOffice")]
        public string IdUnidadCapacidad { get; set; }


        [Description("IDMaterialBackOffice")]
        public string IdArticulo { get; set; }

        public string Matricula { get; set; }

        public Tanque()
        {
            Id =
            IdBoca =
            IdUnidadCapacidad =
            IdArticulo =
            Matricula = string.Empty;
        }
        public virtual Boca? Boca { get; set; }
        public virtual Unidad? UnidadCapacidad { get; set; }
        public virtual Articulo? Articulo { get; set; }

        [NotMapped]
        public static string Query { get { return "Tanque_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
