﻿
namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Menu
    {
        public string Id { get; set; }
        public string Nombre { get; set; }
        public string IdMenuPadre { get; set; }
        public string Mediador { get; set; }
        public string IdPais { get; set; }
        public string IdNegocio { get; set; }

        public Menu()
        {
            Id =
            Nombre =
            IdMenuPadre =
            Mediador =
            IdPais =
            IdNegocio = string.Empty;
        }
        public virtual Pais? Pais { get; set; }
        public virtual Negocio? Negocio { get; set; }
        //public virtual Menu? MenuPadre { get; set; }
    }
}
