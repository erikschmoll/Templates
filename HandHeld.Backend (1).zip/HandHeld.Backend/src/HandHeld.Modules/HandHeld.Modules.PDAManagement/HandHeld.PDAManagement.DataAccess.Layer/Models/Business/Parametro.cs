﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Parametro
    {
        [Description("IDPaisBackOffice")]
        public string IdPais { get; set; }

        [Description("IDNegocioBackOffice")]
        public string IdNegocio { get; set; }

        [Description("IDProceso")]
        public string IdProceso { get; set; }

        [Description("IDPantalla")]
        public string IdPantalla { get; set; }

        [Description("IDParametro")]
        public string IdParametro { get; set; }
        
        [Description("Valor")]
        public string Valor { get; set; }

        public Parametro()
        {
            IdPais =
            IdNegocio =
            IdProceso =
            IdPantalla =
            IdParametro =
            Valor = string.Empty;
        }
        public virtual Pais? Pais { get; set; }
        public virtual Negocio? Negocio { get; set; }
        public virtual Proceso? Proceso { get; set; }
        public virtual Pantalla? Pantalla { get; set; }

        [NotMapped]
        public static string Query { get { return "Parametro_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
