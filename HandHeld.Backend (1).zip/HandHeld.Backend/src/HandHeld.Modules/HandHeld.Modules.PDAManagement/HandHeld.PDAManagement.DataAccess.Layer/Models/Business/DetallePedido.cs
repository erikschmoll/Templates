﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class DetallePedido
    {
        public Decimal Cantidad { get; set; }
        public Decimal PrecioUnitario { get; set; }
        public string IdViaje { get; set; }
        public string IdPedido { get; set; }
        public string IdArticulo { get; set; }
        public string IdUnidadCantidad { get; set; }
        public string IdUnidadPrecioUnitario { get; set; }
        public bool EsCargaFija { get; set; }

        public DetallePedido()
        {
            IdViaje =
            IdPedido =
            IdArticulo =
            IdUnidadCantidad =
            IdUnidadPrecioUnitario = string.Empty;
        }
        public virtual Articulo? Articulo { get; set; }
        public virtual Unidad? UnidadCantidad { get; set; }
        public virtual Unidad? UnidadPrecioUnitario { get; set; }
        public virtual Pedido? Pedido { get; set; }
    }
}
