﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class DetalleEntregaTanque
    {
        public Decimal PorcentajeFinal { get; set; }
        public string PrecintoNuevo { get; set; }
        public string IdViaje { get; set; }
        public int IdEntrega { get; set; }
        public string IdArticulo { get; set; }
        public string IdMotivoEntrega { get; set; }
        public string IdBoca { get; set; }
        public string IdTanque { get; set; }

        public DetalleEntregaTanque()
        {
            PrecintoNuevo =
            IdViaje =
            IdArticulo =
            IdMotivoEntrega =
            IdBoca =
            IdTanque = string.Empty;
        }
        public virtual Tanque? Tanque { get; set; }
        public virtual DetalleEntrega? DetalleEntrega { get; set; }
    }
}
