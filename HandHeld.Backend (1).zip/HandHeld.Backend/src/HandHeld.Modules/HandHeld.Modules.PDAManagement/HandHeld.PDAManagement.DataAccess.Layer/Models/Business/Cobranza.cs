﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Cobranza
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public string IdViaje { get; set; }
        public string IdBoca { get; set; }

        public Cobranza()
        {
            IdViaje =
            IdBoca = string.Empty;
        }
        public virtual Viaje? Viaje { get; set; }
        public virtual Boca? Boca { get; set; }
    }
}
