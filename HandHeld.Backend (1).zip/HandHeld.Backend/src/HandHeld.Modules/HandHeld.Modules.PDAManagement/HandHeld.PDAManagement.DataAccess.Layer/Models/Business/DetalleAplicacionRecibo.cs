﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class DetalleAplicacionRecibo
    {
        public int IdDocumentoRecibo { get; set; }
        public int IdDocumento { get; set; }
        public int Orden { get; set; }
        public bool Cancela { get; set; }
        public string IdViaje { get; set; }
        public string NroDocumentoSAP { get; set; }
        public int Ejercicio { get; set; }
        public string Estado { get; set; }
        public int Posicion { get; set; }

        public DetalleAplicacionRecibo()
        {
            IdViaje =
            NroDocumentoSAP =
            Estado = string.Empty;
        }
        public virtual CuentaCorriente? CuentaCorriente { get; set; }
        public virtual Documento? Documento { get; set; }
        public virtual Recibo? Recibo { get; set; }
    }
}
