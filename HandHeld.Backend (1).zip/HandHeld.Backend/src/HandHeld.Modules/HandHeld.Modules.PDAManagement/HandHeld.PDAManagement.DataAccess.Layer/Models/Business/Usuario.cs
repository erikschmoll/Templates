﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Usuario
    {
        [Description("IDChoferBackOffice")]
        public string Id { get; set; }

        [Description("Clave")]
        public string Clave { get; set; }

        [Description("Chofer")]
        public string Nombre { get; set; }

        public Usuario()
        {
            Id =
            Clave =
            Nombre = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "USE YPFGas_HH SELECT IDChoferBackOffice, IDChoferBackOffice AS Clave, Chofer FROM CHOFER WHERE Activo = 1"; } }

        [NotMapped]
        public static bool IsSP { get { return false; } }
    }
}
