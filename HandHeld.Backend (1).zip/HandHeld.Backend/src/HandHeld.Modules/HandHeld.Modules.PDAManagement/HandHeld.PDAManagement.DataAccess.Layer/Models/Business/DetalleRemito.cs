﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class DetalleRemito
    {
        public string IdViaje { get; set; }
        public int IdDocumentoRemito { get; set; }
        public string IdArticulo { get; set; }
        public Decimal CantidadDespachada { get; set; }
        public string IdUnidadCantidadDespachada { get; set; }

        public DetalleRemito()
        {
            IdViaje =
            IdArticulo =
            IdUnidadCantidadDespachada = string.Empty;
        }
        public virtual Articulo? Articulo { get; set; }
        public virtual Unidad? UnidadCantidadDespachada { get; set; }
        public virtual Remito? Remito { get; set; }
    }
}
