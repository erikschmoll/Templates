﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Remito
    {
        public string IdViaje { get; set; }
        public int IdDocumentoRemito { get; set; }
        public string IdBoca { get; set; }
        public DateTime FechaEntrega { get; set; }
        public Decimal Numero { get; set; }
        public string Serie { get; set; }
        public int NroDespacho { get; set; }

        public Remito()
        {
            IdViaje =
            IdBoca =
            Serie = string.Empty;
        }
        public virtual Boca? Boca { get; set; }
        public virtual Documento? Documento { get; set; }
    }
}
