﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Impuesto
    {
        [Description("IDImpuestoBackOffice")]
        public string Id { get; set; }

        [Description("Impuesto")]
        public string Nombre { get; set; }

        [Description("Orden")]
        public int Orden { get; set; }

        public Impuesto()
        {
            Id =
            Nombre = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "Impuesto_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
