﻿
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Almacen
    {
        [Description("IDAlmacenBackOffice")]
        public string Id { get; set; }

        [Description("Almacen")]
        public string Nombre { get; set; }

        [Description("IDSitioBackOffice")]
        public string IdPlanta { get; set; }

        public Almacen()
        {
            Id =
            Nombre =
            IdPlanta = string.Empty;
        }
        public virtual Planta? Planta { get; set; }

        [NotMapped]
        public static string Query { get { return "Almacen_Custom_Sincronizar_sp"; } }
        
        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
