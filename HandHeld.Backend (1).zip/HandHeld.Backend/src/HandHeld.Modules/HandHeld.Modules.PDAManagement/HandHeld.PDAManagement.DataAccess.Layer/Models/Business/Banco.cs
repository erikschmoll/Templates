﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Banco
    {
        
        [Description("IDBancoBackOffice")]
        public string Id { get; set; }

        [Description("Banco")]
        public string Nombre { get; set; }
        [Description("")]
        public int Orden { get; set; }

	
        public Banco()
        {
            Id = string.Empty;
            Nombre = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "Banco_Custom_Query_All_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
