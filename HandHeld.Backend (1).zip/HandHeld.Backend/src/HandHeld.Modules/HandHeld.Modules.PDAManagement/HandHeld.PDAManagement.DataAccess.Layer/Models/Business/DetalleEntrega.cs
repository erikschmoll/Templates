﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class DetalleEntrega
    {
        public Decimal Cantidad { get; set; }
        public Decimal Cantidad2 { get; set; }
        public Decimal Densidad { get; set; }
        public Decimal Temperatura { get; set; }
        public string IdViaje { get; set; }
        public int IdEntrega { get; set; }
        public string IdMotivoEntrega { get; set; }
        public string IdArticulo { get; set; }
        public string IdUnidadCantidad { get; set; }
        public string IdUnidadCantidad2 { get; set; }

        public DetalleEntrega()
        {
            IdViaje =
            IdMotivoEntrega =
            IdArticulo =
            IdUnidadCantidad =
            IdUnidadCantidad2 = string.Empty;
        }
        public virtual MotivoEntrega? MotivoEntrega { get; set; }
        public virtual Articulo? Articulo { get; set; }
        public virtual Unidad? UnidadCantidad { get; set; }
        public virtual Unidad? UnidadCantidad2 { get; set; }
        public virtual Entrega? Entrega { get; set; }
    }
}
