﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class GeoPosicion
    {
        public int Id { get; set; }
        public Decimal Latitud { get; set; }
        public Decimal Longitud { get; set; }
        public DateTime TiempoLocal { get; set; }
        public DateTime TiempoGPS { get; set; }
    }
}
