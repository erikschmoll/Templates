﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class DocumentoAnulado
    {
        public string IdViaje { get; set; }
        public int IdDocumento { get; set; }
        public DateTime FechaAnulacion { get; set; }
        public int IdGeoPosicion { get; set; }

        public DocumentoAnulado()
        {
            IdViaje = string.Empty;
        }
        public virtual GeoPosicion? GeoPosicion { get; set; }
        public virtual Documento? Documento { get; set; }
    }
}
