﻿
namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Pedido
    {
        public string Id { get; set; }
        public string CodigoExpress { get; set; }
        public string EstadoPedido { get; set; }
        public DateTime FechaEntregaPreferente { get; set; }
        public int HoraDesde { get; set; }
        public int HoraHasta { get; set; }
        public Decimal ImporteCobroAnticipado { get; set; }
        public string Observaciones { get; set; }
        public bool EsCargaNormal { get; set; }
        public string IdViaje { get; set; }
        public string IdUnidadCobroAnticipado { get; set; }
        public string IdTipoPedido { get; set; }
        public string IdBoca { get; set; }
        public bool EsCuentaCorriente { get; set; }
        public bool EsPlanificado { get; set; }
        public bool EsFacturable { get; set; }
        public int IdGeoPosicion { get; set; }

        public Pedido()
        {
            Id =
            CodigoExpress =
            EstadoPedido =
            Observaciones =
            IdViaje =
            IdUnidadCobroAnticipado =
            IdTipoPedido =
            IdBoca = string.Empty;
        }
        public virtual Viaje? Viaje { get; set; }
        public virtual Unidad? UnidadCobroAnticipado { get; set; }
        public virtual TipoPedido? TipoPedido { get; set; }
        public virtual Boca? Boca { get; set; }
        public virtual GeoPosicion? GeoPosicion { get; set; }
    }
}
