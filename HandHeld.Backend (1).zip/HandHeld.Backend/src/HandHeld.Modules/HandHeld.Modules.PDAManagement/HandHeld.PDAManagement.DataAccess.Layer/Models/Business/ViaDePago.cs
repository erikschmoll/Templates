﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class ViaDePago
    {
        [Description("IDViaPagoBackOffice")]
        public string Id { get; set; }

        [Description("ViaPago")]
        public string Nombre { get; set; }

        public int Orden { get; set; }

        public bool PideBanco { get; set; }

        public bool PideNumeroDoc { get; set; }

        public bool PideVencimiento { get; set; }

        public bool pideEmision { get; set; }

        [Description("")]
        public string IdUnidad { get; set; }


        public ViaDePago()
        {
            Id =
            Nombre =
            IdUnidad = string.Empty;
        }
        public virtual Unidad? Unidad { get; set; }

        [NotMapped]
        public static string Query { get { return "ViaPago_Custom_Query_all_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
