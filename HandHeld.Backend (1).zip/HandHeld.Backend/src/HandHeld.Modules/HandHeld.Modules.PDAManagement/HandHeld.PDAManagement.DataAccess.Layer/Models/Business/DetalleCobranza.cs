﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class DetalleCobranza
    {
        public string IdViaje { get; set; }
        public int IdCobranza { get; set; }
        public int IdDocumentoGenerado { get; set; }

        public DetalleCobranza()
        {
            IdViaje = string.Empty;
        }
        public virtual Documento? Documento { get; set; }
        public virtual Cobranza? Cobranza { get; set; }
    }
}
