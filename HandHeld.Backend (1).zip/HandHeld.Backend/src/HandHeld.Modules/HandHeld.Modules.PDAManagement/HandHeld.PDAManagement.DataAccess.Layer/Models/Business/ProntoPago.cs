﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class ProntoPago
    {
        [Description("IDProntoPagoBackOffice")]
        public string Id { get; set; }

        [Description("DiasProntoPago")]
        public int DiasProntoPago { get; set; }

        [Description("DiasMinimos")]
        public int DiasMinimos { get; set; }

        [Description("FechaValidezDesde")]
        public DateTime FechaValidezDesde { get; set; }

        [Description("FechaValidezHasta")]
        public DateTime FechaValidezHasta { get; set; }

        [Description("Porcentaje")]
        public Decimal PorcentajeDescuento { get; set; }

        public ProntoPago()
        {
            Id = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "ProntoPago_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
