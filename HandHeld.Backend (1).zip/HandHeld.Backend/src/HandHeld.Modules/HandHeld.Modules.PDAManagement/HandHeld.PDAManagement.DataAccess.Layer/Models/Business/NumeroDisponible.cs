﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class NumeroDisponible
    {
        public Decimal NumeroDisp { get; set; }
        public string IdViaje { get; set; }
        public string IdTipoDocumento { get; set; }
        public string IdBoca { get; set; }
        public string Serie { get; set; }

        public NumeroDisponible()
        {
            IdViaje =
            IdTipoDocumento =
            IdBoca =
            Serie = string.Empty;
        }
        public virtual Boca? Boca { get; set; }
        public virtual Numerador? Numerador { get; set; }
    }
}
