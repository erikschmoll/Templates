﻿
namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Traduccion
    {
        public string IdElemento { get; set; }
        public string ValorTraduccion { get; set; }
        public string IdPantalla { get; set; }

        public Traduccion()
        {
            IdElemento =
            ValorTraduccion =
            IdPantalla = string.Empty;
        }
        public virtual Pantalla? Pantalla { get; set; }
    }
}
