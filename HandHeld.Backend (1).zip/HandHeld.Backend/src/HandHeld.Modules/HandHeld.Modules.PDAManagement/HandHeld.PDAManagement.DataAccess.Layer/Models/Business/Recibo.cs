﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Recibo
    {
        public int Id { get; set; }
        public Decimal Numero { get; set; }
        public string Serie { get; set; }
        public DateTime Fecha { get; set; }
        public Decimal Importe { get; set; }
        public string IdUnidadImporte { get; set; }
        public string IdBoca { get; set; }
        public string IdViaje { get; set; }
        public int IdGeoPosicion { get; set; }

        public Recibo()
        {
            Serie =
            IdUnidadImporte =
            IdBoca =
            IdViaje = string.Empty;
        }
        public virtual Unidad? UnidadImporte { get; set; }
        public virtual Boca? Boca { get; set; }
        public virtual GeoPosicion? GeoPosicion { get; set; }
        public virtual Documento? Documento { get; set; }
    }
}
