﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Stock
    {
        public string IdArticulo { get; set; }
        public string IdEstadoArticulo { get; set; }
        public Decimal Cantidad { get; set; }
        public string IdUnidadCantidad { get; set; }
        public string IdViaje { get; set; }

        public Stock()
        {
            IdArticulo =
            IdEstadoArticulo =
            IdUnidadCantidad =
            IdViaje = string.Empty;
        }
        public virtual Articulo? Articulo { get; set; }
        public virtual EstadoArticulo? EstadoArticulo { get; set; }
        public virtual Unidad? UnidadCantidad { get; set; }
        public virtual Viaje? Viaje { get; set; }
    }
}
