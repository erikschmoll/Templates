﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class DetalleFactura
    {
        public string IdViaje { get; set; }
        public int IdDocumentoFactura { get; set; }
        public string IdArticulo { get; set; }
        public Decimal Cantidad { get; set; }
        public string IdUnidadCantidad { get; set; }

        public DetalleFactura()
        {
            IdViaje =
            IdArticulo =
            IdUnidadCantidad = string.Empty;
        }
        public virtual Unidad? UnidadCantidad { get; set; }
        public virtual Articulo? Articulo { get; set; }
        public virtual Factura? Factura { get; set; }
    }
}
