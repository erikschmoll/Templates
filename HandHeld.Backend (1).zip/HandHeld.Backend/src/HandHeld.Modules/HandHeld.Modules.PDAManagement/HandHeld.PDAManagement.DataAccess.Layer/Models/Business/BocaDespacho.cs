﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class BocaDespacho
    {
        [Description("IDBocaDespachoBackOffice")]
        public string Id { get; set; }

        [Description("BocaDespacho")]
        public string Nombre { get; set; }

        [Description("IDProveedorBackOffice")]
        public string IdProveedor { get; set; }

        public BocaDespacho()
        {
            Id =
            Nombre =
            IdProveedor = string.Empty;
        }
        public virtual Proveedor? Proveedor { get; set; }

        [NotMapped]
        public static string Query { get { return "BocaDespacho_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
