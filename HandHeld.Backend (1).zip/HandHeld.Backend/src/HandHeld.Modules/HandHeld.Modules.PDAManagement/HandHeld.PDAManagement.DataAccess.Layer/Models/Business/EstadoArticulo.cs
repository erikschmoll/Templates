﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class EstadoArticulo
    {
        [Description("IDEstadoArticulo")]
        public string Id { get; set; }

        [Description("EstadoArticulo")]
        public string Nombre { get; set; }

        public EstadoArticulo()
        {
            Id =
            Nombre = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "EstadoArticulo_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
