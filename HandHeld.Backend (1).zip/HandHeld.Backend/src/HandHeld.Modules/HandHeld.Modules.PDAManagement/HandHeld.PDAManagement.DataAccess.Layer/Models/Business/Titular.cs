﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Titular
    {
        [Description("IDTitularBackOffice")]
        public string Id { get; set; }

        [Description("Titular")]
        public string Nombre { get; set; }

        [Description("Direccion")]
        public string Direccion { get; set; }

        [Description("IDNumeroFiscal")]
        public string IdFiscal { get; set; }

        public string CodigoPostal { get; set; }

        public string Poblacion { get; set; }

        [Description("IDTipoFiscal")]
        public string IdTipoIdFiscal { get; set; }

        [Description("IDCategoriaFiscalBackOffice")]
        public string IdCategoriaSegunFisco { get; set; }

        [Description("IDRegionBackOffice")]
        public string IdRegionComercial { get; set; }

        [Description("IDTipoRegionBackOffice")]
        public string IdTipoRegionComercial { get; set; }

        public Titular()
        {
            Id =
            Nombre =
            Direccion =
            IdFiscal =
            CodigoPostal =
            Poblacion =
            IdTipoIdFiscal =
            IdCategoriaSegunFisco =
            IdRegionComercial =
            IdTipoRegionComercial = string.Empty;
        }
        public virtual CategoriaSegunFisco? CategoriaSegunFisco { get; set; }
        public virtual RegionComercial? RegionComercial { get; set; }

        [NotMapped]
        public static string Query { get { return "Titular_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
