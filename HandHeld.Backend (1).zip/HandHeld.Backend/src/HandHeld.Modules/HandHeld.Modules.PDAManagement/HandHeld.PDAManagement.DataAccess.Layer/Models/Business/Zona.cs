﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Zona
    {
        [Description("IDZonaBackOffice")]
        public string Id { get; set; }

        [Description("Zona")]
        public string Nombre { get; set; }

        public Zona()
        {
            Id =
            Nombre = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "Zona_Custom_sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
