﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class ImpuestoFactura
    {
        public string IdViaje { get; set; }
        public int IdDocumentoFactura { get; set; }
        public string IdImpuesto { get; set; }
        public Decimal Importe { get; set; }
        public string IdUnidad { get; set; }
        public Decimal Porcentaje { get; set; }

        public ImpuestoFactura()
        {
            IdViaje =
            IdImpuesto =
            IdUnidad = string.Empty;
        }
        public virtual Factura? Factura { get; set; }
        public virtual Impuesto? Impuesto { get; set; }
        public virtual Unidad? Unidad { get; set; }
    }
}
