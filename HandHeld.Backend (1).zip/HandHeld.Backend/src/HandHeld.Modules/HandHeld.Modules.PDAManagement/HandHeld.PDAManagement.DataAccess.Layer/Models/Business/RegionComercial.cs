﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class RegionComercial
    {
        [Description("IDTipoRegionBackOffice")]
        public string Id { get; set; }

        public string Nombre { get; set; }

        [Description("IDRegionBackOffice")]
        public string IdTipoRegionComercial { get; set; }

        public string IdTipoRegionComercialRef { get; set; }

        [Description("Region")]
        public string IdRegionComercialRef { get; set; }

        public RegionComercial()
        {
            Id =
            Nombre =
            IdTipoRegionComercial =
            IdTipoRegionComercialRef =
            IdRegionComercialRef = string.Empty;
            //RegionComercialRef = new RegionComercial();
        }
        //public virtual RegionComercial RegionComercialRef { get; set; }

        [NotMapped]
        public static string Query { get { return "USE YPFGas_HH SELECT " +
                        "IDTipoRegionBackOffice, " +
                        "IDTipoRegionBackOffice AS Nombre, " +
                        "IDRegionBackOffice, " +
                        "IDRegionBackOffice AS IdTipoRegionComercialRef, " +
                        "Region " +
                        "FROM[dbo].[Region] WHERE Activo = 1"; } }

        [NotMapped]
        public static bool IsSP { get { return false; } }
    }
}
