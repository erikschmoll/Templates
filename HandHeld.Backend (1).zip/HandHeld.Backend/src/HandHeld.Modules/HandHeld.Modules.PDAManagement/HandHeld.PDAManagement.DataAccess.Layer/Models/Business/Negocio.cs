﻿
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Negocio
    {

        [Description("IDNegocioBackOffice")]
        public string Id { get; set; }

        [Description("Negocio")]
        public string Nombre { get; set; }

        public Negocio()
        {
            Id = string.Empty;
            Nombre = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "Negocio_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
