﻿
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class MotivoEntrega
    {
        [Description("IDMotivoEntrega")]
        public string Id { get; set; }

        [Description("MotivoEntrega")]
        public string Nombre { get; set; }

        public int SentidoGranel { get; set; }

        public int SentidoLleno { get; set; }

        public int SentidoVacio { get; set; }

        public int SentidoRoto { get; set; }

        public MotivoEntrega()
        {
            Id =
            Nombre = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "MotivoEntrega_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
