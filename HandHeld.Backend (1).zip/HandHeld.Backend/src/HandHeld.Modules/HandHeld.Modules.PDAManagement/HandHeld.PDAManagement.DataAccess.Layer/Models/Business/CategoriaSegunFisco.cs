﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class CategoriaSegunFisco
    {
        [Description("IDCategoriaFiscalBackOffice")]
        public string Id { get; set; }
        [Description("IDAfip")]
        public string Nombre { get; set; }
        [Description("TipoFactura")]
        public string IdAFIP { get; set; }
        [Description("CategoriaFiscal")]
        public string TipoFactura { get; set; }

        public CategoriaSegunFisco()
        {
            Id =
            Nombre =
            IdAFIP =
            TipoFactura = string.Empty;
        }


        [NotMapped]
        public static string Query { get { return "CategoriaFiscal_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
