﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Boca
    {
        [Description("IDBocaBackOffice")]
        public string Id { get; set; }

        [Description("Direccion")]
        public string Direccion { get; set; }

        [Description("Poblacion")]
        public string Poblacion { get; set; }

        [Description("Telefono")]
        public string Telefono { get; set; }

        [Description("IDTitularBackOffice")]
        public string IdTitular { get; set; }

        [Description("CodigoPostal")]
        public string CodigoPostal { get; set; }

        [Description("InstruccionAcceso")]
        public string InstruccionesDeAcceso { get; set; }

        [Description("IDZonaBackOffice")]
        public string IdZona { get; set; }

        [Description("MarcaSegundoVto")]
        public bool UsaSegundoVencimiento { get; set; }

        [Description("MarcaProntoPago")]
        public bool UsaProntoPago { get; set; }

        [Description("IDProntoPagoBackOffice")]
        public string IdProntoPago { get; set; }

        [Description("MarcaZonaFranca")]
        public bool EstaEnZonaFranca { get; set; }

        [Description("Boca")]
        public string RazonSocial { get; set; }

        [Description("DiasPlazoPago")]
        public int DiasPlazoPago { get; set; }

        [Description("MarcaDebitoAutomatico")]
        public bool UsaDebitoAutomatico { get; set; }

        [Description("MarcaFacturacion")]
        public bool EsFacturable { get; set; }

        [Description("IDRegionBackOffice")]
        public string IdRegionComercial { get; set; }

        [Description("IDTipoRegionBackOffice")]
        public string IdTipoRegionComercial { get; set; }

        [Description("IDSitioBackOffice")]
        public string IdPlanta { get; set; }

        [Description("Activo")]
        public bool EstaActiva { get; set; }

        [Description("ResolucionDGE")]
        public string ResolucionDGE { get; set; }

        public Boca()
        {
            Id =
            Direccion =
            Poblacion =
            Telefono =
            IdTitular =
            CodigoPostal =
            InstruccionesDeAcceso =
            IdZona =
            IdProntoPago =
            RazonSocial =
            IdRegionComercial =
            IdTipoRegionComercial =
            ResolucionDGE =
            IdPlanta = string.Empty;
        }
        public virtual Titular? Titular { get; set; }
        public virtual Zona? Zona { get; set; }
        public virtual ProntoPago? ProntoPago { get; set; }
        public virtual Planta? Planta { get; set; }
        public virtual RegionComercial? RegionComercial { get; set; }

        [NotMapped]
        public static string Query { get { return "USE YPFGas_HH " +
                        "SELECT B.IDBocaBackOffice " +
                        ",B.Direccion " +
                        ",B.Poblacion " +
                        ",B.Telefono " +
                        ",T.IDTitularBackOffice " +
                        ",B.CodigoPostal " +
                        ",CASE ISNULL(B.InstruccionAcceso,'') WHEN '' THEN '' ELSE B.InstruccionAcceso END AS InstruccionAcceso " +
                        ",Z.IDZonaBackOffice " +
                        ",CASE ISNULL(B.MarcaSegundoVto,0) WHEN 0 THEN 0 ELSE MarcaSegundoVto END AS MarcaSegundoVto " +
                        ",CASE ISNULL(B.MarcaProntoPago,0) WHEN 0 THEN 0 ELSE MarcaProntoPago END AS MarcaProntoPago " +
                        ",P.IDProntoPagoBackOffice " +
                        ",CASE ISNULL(B.MarcaZonaFranca,0) WHEN 0 THEN 0 ELSE MarcaZonaFranca END AS MarcaZonaFranca " +
                        ",B.Boca " +
                        ",B.DiasPlazoPago " +
                        ",B.MarcaDebitoAutomatico " +
                        ",B.MarcaFacturacion " +
                        ",R.IDRegionBackOffice " +
                        ",R.IDTipoRegionBackOffice " +
                        ",S.IDSitioBackOffice " +
                        ",B.Activo " +
                        ",B.ResolucionDGE " +
                        "FROM Boca B " +
                        "INNER JOIN Titular T ON T.IDTitular = B.IDTitular " +
                        "INNER JOIN Zona Z ON Z.IDZona = B.IDZona " +
                        "LEFT JOIN ProntoPago P ON P.IDProntoPago = B.IDProntoPago " +
                        "INNER JOIN Region R ON R.IDRegion = B.IDRegion " +
                        "INNER JOIN Sitio S ON S.IDSitio = B.IDSitio " +
                        "WHERE B.IDSitio = @iIDSitio " +
                        "AND B.Activo = 1"; } }

        [NotMapped]
        public static bool IsSP { get { return false; } }
    }
}
