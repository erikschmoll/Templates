﻿
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Pantalla
    {
        [Description("IDPantalla")]
        public string Id { get; set; }

        [Description("Pantalla")]
        public string Nombre { get; set; }

        public Pantalla()
        {
            Id =
            Nombre = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "Pantalla_Custom_Sincronizar_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
