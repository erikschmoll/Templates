﻿
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Pais
    {
        [Description("IDPaisBackOffice")]
        public string Id { get; set; }

        [Description("Pais")]
        public string Nombre { get; set; }

        public Pais()
        {
            Id =
            Nombre = string.Empty;
        }

        [NotMapped]
        public static string Query { get { return "Pais_Custom_Query_All_sp"; } }

        [NotMapped]
        public static bool IsSP { get { return true; } }
    }
}
