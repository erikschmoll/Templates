﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class MovimientoStockAnulado
    {
        public int IdMovimiento { get; set; }
        public string IdViaje { get; set; }
        public DateTime FechaAnulacion { get; set; }
        public int IdGeoPosicion { get; set; }

        public MovimientoStockAnulado()
        {
            IdViaje = string.Empty;
        }
        public virtual GeoPosicion? GeoPosicion { get; set; }
        public virtual MovimientoStock? MovimientoStock { get; set; }
    }
}
