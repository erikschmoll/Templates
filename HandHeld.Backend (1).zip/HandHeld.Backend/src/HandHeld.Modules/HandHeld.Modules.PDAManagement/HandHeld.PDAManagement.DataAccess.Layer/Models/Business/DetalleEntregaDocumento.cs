﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class DetalleEntregaDocumento
    {
        public string IdViaje { get; set; }
        public int IdEntrega { get; set; }
        public int IdDocumento { get; set; }

        public DetalleEntregaDocumento()
        {
            IdViaje = string.Empty;
        }
        public virtual Documento? Documento { get; set; }
        public virtual Entrega? Entrega { get; set; }
    }
}
