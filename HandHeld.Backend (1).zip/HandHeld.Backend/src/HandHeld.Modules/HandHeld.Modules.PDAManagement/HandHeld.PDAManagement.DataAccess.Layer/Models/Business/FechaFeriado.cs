﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class FechaFeriado
    {
        public DateTime Fecha { get; set; }
        public string IdPlanta { get; set; }

        public FechaFeriado()
        {
            IdPlanta = string.Empty;
        }
        public virtual Planta? Planta { get; set; }
    }
}
