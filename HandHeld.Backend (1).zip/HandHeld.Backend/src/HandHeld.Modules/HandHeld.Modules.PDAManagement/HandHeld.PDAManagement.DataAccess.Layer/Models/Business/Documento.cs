﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Documento
    {
        public int Id { get; set; }
        public string IdTipoDocumento { get; set; }
        public string IdViaje { get; set; }
        public int CantidadImpresiones { get; set; }

        public Documento()
        {
            IdTipoDocumento =
            IdViaje = string.Empty;
        }
        public virtual TipoDocumento? TipoDocumento { get; set; }
        public virtual Viaje? Viaje { get; set; }
    }
}
