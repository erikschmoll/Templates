﻿
namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class MovimientoStock
    {
        public int Id { get; set; }
        public string IdAlmacenOrigen { get; set; }
        public string IdAlmacenDestino { get; set; }
        public string IdPlantaOrigen { get; set; }
        public string IdPlantaDestino { get; set; }
        public string IdViaje { get; set; }
        public int IdDocumento { get; set; }
        public string IdPatenteTractor { get; set; }
        public string IdPatenteTanque { get; set; }
        public DateTime FechaOperacionInicial { get; set; }
        public DateTime FechaOperacionFinal { get; set; }
        public DateTime FechaMovimiento { get; set; }
        public string RemitoReferencia { get; set; }
        public Decimal Kilometros { get; set; }
        public Decimal KilosFinal { get; set; }
        public Decimal KilosInicial { get; set; }
        public Decimal LitrajeInicial { get; set; }
        public Decimal LitrajeFinal { get; set; }
        public int IdGeoPosicionFinal { get; set; }
        public int IdGeoPosicionInicial { get; set; }
        public Decimal Temperatura { get; set; }
        public string IdTipoOperacion { get; set; }
        public string IdBocaDespacho { get; set; }

        public MovimientoStock()
        {
            IdAlmacenOrigen =
            IdAlmacenDestino =
            IdPlantaOrigen =
            IdPlantaDestino =
            IdViaje =
            IdPatenteTractor =
            IdPatenteTanque =
            RemitoReferencia =
            IdTipoOperacion =
            IdBocaDespacho = string.Empty;
        }
        public virtual BocaDespacho? BocaDespacho { get; set; }
        public virtual TipoOperacion? TipoOperacion { get; set; }
        public virtual Viaje? Viaje { get; set; }
        public virtual GeoPosicion? GeoPosicionInicial { get; set; }
        public virtual GeoPosicion? GeoPosicionFinal { get; set; }
        public virtual Patente? PatenteTanque { get; set; }
        public virtual Patente? PatenteTractor { get; set; }
        public virtual Documento? Documento { get; set; }
        public virtual Almacen? AlmacenOrigen { get; set; }
        public virtual Almacen? AlmacenDestino { get; set; }
    }
}
