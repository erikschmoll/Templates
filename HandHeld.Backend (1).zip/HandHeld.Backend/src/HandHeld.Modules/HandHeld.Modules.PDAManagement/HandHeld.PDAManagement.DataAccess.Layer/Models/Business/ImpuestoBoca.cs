﻿
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class ImpuestoBoca
    {
        [Description("IDImpuestoBackOffice")]
        public string IdImpuesto { get; set; }

        [Description("IDBocaBackOffice")]
        public string IdBoca { get; set; }

        [Description("BaseCalculo")]
        public int BaseDeCalculo { get; set; }

        public Decimal PorcentajeImpuesto { get; set; }

        public Decimal ImporteMinimo { get; set; }

        public Decimal PorcentajeExento { get; set; }

        public DateTime FechaExentoHasta { get; set; }

        public DateTime FechaSujetoDesde { get; set; }

        public DateTime FechaSujetoHasta { get; set; }

        [Description("IDUnidadMedidaBackOffice")]
        public string IdUnidadImporteMinimo { get; set; }

        public ImpuestoBoca()
        {
            IdImpuesto =
            IdBoca =
            IdUnidadImporteMinimo = string.Empty;
        }
        public virtual Impuesto? Impuesto { get; set; }
        public virtual Boca? Boca { get; set; }
        public virtual Unidad? UnidadImporteMinimo { get; set; }

        [NotMapped]
        public static string Query { get { return "USE YPFGas_HH SELECT " +
                        "I.IDImpuestoBackOffice, " +
                        "B.IDBocaBackOffice, " +
                        "IB.BaseCalculo, " +
                        "IB.PorcentajeImpuesto, " +
                        "IB.ImporteMinimo, " +
                        "IB.PorcentajeExento, " +
                        "IB.FechaExentoHasta, " +
                        "IB.FechaSujetoDesde, " +
                        "IB.FechaSujetoHasta, " +
                        "U.IDUnidadMedidaBackOffice " +
                        "FROM[dbo].[ImpuestoBoca] IB " +
                        "INNER JOIN[dbo].[Boca] B ON(B.IDBoca = IB.IDBoca) " +
                        "INNER JOIN[dbo].[Impuesto] I ON(I.IDImpuesto = IB.IDImpuesto) " +
                        "INNER JOIN[dbo].[UnidadMedida] U ON(U.IDUnidadMedida = IB.IDUnidadImporteMinimo) " +
                        "WHERE B.[IDSitio] = @iIDSitio " +
                        "AND IB.Activo = 1 " +
                        "AND B.Activo = 1"; } }

        [NotMapped]
        public static bool IsSP { get { return false; } }
    }
}
