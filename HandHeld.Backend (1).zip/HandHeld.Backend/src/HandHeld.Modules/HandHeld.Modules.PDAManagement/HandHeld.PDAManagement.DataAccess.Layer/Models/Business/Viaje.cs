﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Viaje
    {
        public string Id { get; set; }
        public DateTime FechaInicial { get; set; }
        public DateTime FechaFinal { get; set; }
        public int KilometrajeInicial { get; set; }
        public int KilometrajeFinal { get; set; }
        public Decimal LitrajeInicial { get; set; }
        public Decimal LitrajeFinal { get; set; }
        public Decimal PesadaInicial { get; set; }
        public Decimal PesadaFinal { get; set; }
        public Decimal PresionInicial { get; set; }
        public Decimal PresionFinal { get; set; }
        public Decimal TemperaturaInicial { get; set; }
        public Decimal TemperaturaFinal { get; set; }
        public Decimal PorcentajeDeRotaryInicial { get; set; }
        public Decimal PorcentajeDeRotaryFinal { get; set; }
        public string IdUsuario { get; set; }
        public string IdTipoDeViaje { get; set; }
        public string EmpresaTransportista { get; set; }
        public int EstadoActual { get; set; }
        public Decimal DensidadInicial { get; set; }
        public Decimal DensidadFinal { get; set; }

        public Viaje()
        {
            Id =
            IdUsuario =
            IdTipoDeViaje =
            EmpresaTransportista = string.Empty;
        }
        public virtual Usuario? Usuario { get; set; }
        public virtual TipoDeViaje? TipoDeViaje { get; set; }
    }
}
