﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class TipoIncidencia
    {
        public string Id { get; set; }
        public string Nombre { get; set; }
        public int Orden { get; set; }

        public TipoIncidencia()
        {
            Id =
            Nombre = string.Empty;
        }
    }
}
