﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Business
{
    public class Precio
    {
        [Description("FechaVigenciaDesde")]
        public DateTime VigenciaDesde { get; set; }

        [Description("ImporteNeto")]
        public Decimal PrecioNeto { get; set; }

        [Description("IDMaterialBackOffice")]
        public string IdArticulo { get; set; }

        [Description("IDBocaBackOffice")]
        public string IdBoca { get; set; }

        [Description("IDMonedaBackOffice")]
        public string IdUnidadPrecioNeto { get; set; }

        public Precio()
        {
            IdArticulo =
            IdBoca =
            IdUnidadPrecioNeto = string.Empty;
        }
        public virtual Articulo? Articulo { get; set; }
        public virtual Boca? Boca { get; set; }
        public virtual Unidad? UnidadPrecioNeto { get; set; }

        [NotMapped]
        public static string Query { get { return "USE YPFGas_HH SELECT " +
                        "P.FechaVigenciaDesde, " +
                        "P.ImporteNeto, " +
                        "M.IDMaterialBackOffice, " +
                        "B.IDBocaBackOffice, " +
                        "Mo.IDMonedaBackOffice " +
                        "FROM[dbo].[PrecioEspecial] P " +
                        "INNER JOIN[dbo].[Boca] B ON(B.IDBoca = P.IDBoca) " +
                        "INNER JOIN[dbo].[Material] M ON(M.IDMaterial = P.IDMaterial) " +
                        "INNER JOIN[dbo].[Moneda] Mo ON(Mo.IDMoneda = P.IDMoneda) " +
                        "WHERE B.[IDSitio] = @iIDSitio " +
                        "AND P.Activo = 1 " +
                        "AND B.Activo = 1"; } }

        [NotMapped]
        public static bool IsSP { get { return false; } }
    }
}
