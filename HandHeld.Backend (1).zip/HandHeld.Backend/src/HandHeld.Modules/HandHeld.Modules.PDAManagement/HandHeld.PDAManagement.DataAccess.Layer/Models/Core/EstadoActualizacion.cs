﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Core
{
    public class EstadoActualizacion : Auditoria
    {
        public static string PENDIENTE = "1";
        public static string PROCESANDO = "2";
        public static string LISTO_PARA_SINCRONIZAR = "3";
        public static string ERROR = "4";
        public string Nombre { get; set; }
        public EstadoActualizacion()
        {
            Nombre = string.Empty;
        }
    }
}
