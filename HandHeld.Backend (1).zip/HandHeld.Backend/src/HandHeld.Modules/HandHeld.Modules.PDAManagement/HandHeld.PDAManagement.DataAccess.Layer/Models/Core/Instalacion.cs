﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Core
{
    public class Instalacion : Auditoria
    {
        public string IdActualizacion { get; set; }
        public int NroActualizacionUsado { get; set; }
        public string Chofer { get; set; }
        public string Dispositivo { get; set; }
        public Instalacion()
        {
            IdActualizacion = Chofer = Dispositivo = string.Empty;
        }
        public virtual Actualizacion? Actualizacion { get; set; }
    }
}
