﻿
namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Config
{
    public abstract class Filtro
    {
        protected object _value;
        protected string _field;
        public Filtro(string field, object value)
        {
            _value = value;
            _field = field;
        }
        virtual public string Condicion
        {
            get
            {
                return $"{_field} = @{_field}";
            }
        }
        virtual public string Field
        {
            get
            {
                return _field;
            }
        }
        virtual public object Valor
        {
            get
            {
                return _value;
            }
        }
    }
}
