﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Config
{
    public class Coincidencia : Filtro
    {
        public Coincidencia(string field, object value) : base(field, value)
        {
        }

        public override string Condicion
        {
            get
            {
                return $"{_field} like @{_field}";
            }
        }
        public override object Valor
        {
            get
            {
                return $"%{_value}%";
            }
        }
    }
}
