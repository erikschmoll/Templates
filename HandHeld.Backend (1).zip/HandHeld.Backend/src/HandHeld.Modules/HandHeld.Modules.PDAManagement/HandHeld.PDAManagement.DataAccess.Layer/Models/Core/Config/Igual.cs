﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Config
{
    public class Igual : Filtro
    {
        public Igual(string field, object value) : base(field, value)
        {
        }
    }
}
