﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Core
{
    public class Usuarios : Auditoria
    {
        public string Nombres {get;set;}
        public string Apellidos {get;set;}
        public string Dni {get;set;}
        public long Pin {get;set;}
        public DateTimeOffset fechaDeExpiracion {get;set;}

        public Usuarios()
        {
            Nombres =
            Apellidos =
            Dni = string.Empty;

        }

        public string Nombre
        {
            get
            {
                return $"{Nombres} {Apellidos}";
            }
        }

        //#region MOCK
        ////TODO: agrego prop que cumpla con la interfaz.
        //public string Nombre
        //{
        //    get
        //    {
        //        return name;
        //    }
        //}
        //public string name { get; set; }
        //public string username { get; set; }
        //public string email { get; set; }
        //public Adress address { get; set; }
        //public string phone { get; set; }
        //public string website { get; set; }
        //public Company company { get; set; }
        //#endregion


    }

    //#region MockClass
    //public class Adress
    //{
    //    public string street { get; set; }
    //    public string suite { get; set; }
    //    public string city { get; set; }
    //    public string zipcode { get; set; }
    //    public Geo geo { get; set; }
    //}

    //public class Geo
    //{
    //    public string lat { get; set; }
    //    public string lng { get; set; }
    //}

    //public class Company
    //{
    //    public string name { get; set; }
    //    public string catchPhrase { get; set; }
    //    public string bs { get; set; }
    //}
    //#endregion
}
