﻿using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Core
{
    public class Actualizacion : Auditoria
    {
        public string IdPlanta { get; set; }
        public string IdPatente { get; set; }
        public string IdChofer { get; set; }
        public string IdEstado { get; set; }
        public string Url { get; set; }
        public Nullable<long> Version { get; set; }
        public Nullable<int> NroActualizacion { get; set; }
        public virtual EstadoActualizacion? Estado { get; set; }

        public Actualizacion()
        {
            IdPlanta = 
            IdPatente =
            IdChofer =
            IdEstado =
            Planta =
            Patente =
            Url = string.Empty;
        }

        public dynamic? Planta { get; set; }
        public dynamic? Patente { get; set; }
        public virtual Usuarios? Chofer { get; set; }
    }
}
