﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Request
{
    public class ModificarActualizaciones
    {
        public string? IdPatente { get; set; }
        public string? IdPlanta { get; set; }
        public string? IdChofer { get; set; }
    }
}
