﻿namespace HandHeld.PDAManagement.DataAccess.Layer.Models.Core
{
    public class Configuracion : Auditoria
    {
        public static int MAX_PEDIDOS_PROCESAR = 5;//valor maximo por defecto
        public string Valor { get; set; }
        public string Descripcion { get; set; }
        public Configuracion()
        {
            Id = Valor = Descripcion = string.Empty;
        }
    }
}
