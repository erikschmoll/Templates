﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDAManagement.Presentation.Layer.Models
{
    public class FiltrosBuscarActualizaciones
    {
        public string? IdPlanta { get; set; }

        public string? IdPatente { get; set; }

        public string? IdChofer { get; set; }

        public string? IdEstado { get; set; }

        public bool Activos { get; set; }
    }
}
