﻿using HandHeld.PDAManagement.Business.Layer.DataContracts;
using HandHeld.PDAManagement.Business.Layer.Services.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Reponse;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Request;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.WebServices;
using HandHeld.PDAManagement.DataAccess.Layer.UnitOfWork.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer.Utilities;
using HandHeld.PDAManagement.Presentation.Layer.Models;
using HandHeld.Shared.Abstractions.Models;
using HandHeld.Shared.Infrastructure.Services.Interfaces;
using Microsoft.Extensions.Logging;
using System.Linq;

namespace HandHeld.PDAManagement.Business.Layer.Services.Implementations
{
    public class InicializadorService : IInicializadorService
    {
        private readonly IConfiguracionRepository _configuracionRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IInstalacionRepository _instalacionRepository;
        private readonly IColaPendientesRepository _colaPendientesRepository;
        private readonly IInicializadorDataAccess _inicializadorDataAccess;
        private readonly IStorageService _storageService;
        private readonly ILogger<InicializadorService> _logger;
        private readonly IIdentityService _identityService;
        public InicializadorService(IConfiguracionRepository configuracionRepository,
            IInstalacionRepository instalacionRepository,
            IColaPendientesRepository colaPendientesRepository,
            IInicializadorDataAccess inicializadorDataAccess,
            IUnitOfWork unitOfWork,
            IStorageService storageService,
            ILogger<InicializadorService> logger,
            IIdentityService identityService)
        {
            _configuracionRepository = configuracionRepository;
            _instalacionRepository = instalacionRepository;
             _colaPendientesRepository = colaPendientesRepository;
            _inicializadorDataAccess = inicializadorDataAccess;
            _unitOfWork = unitOfWork;
            _storageService = storageService;
            _logger = logger;
            _identityService = identityService;
        }
        public async Task ProcesarPendientes()
        {
            IEnumerable<Actualizacion> actualizacionesPendientes = _colaPendientesRepository.GetPendientesConTope();
            if (actualizacionesPendientes.Any())
            {
                foreach (var actualizacionPendiente in actualizacionesPendientes)
                {
                    await procesarPendiente(actualizacionPendiente);
                }
            }
        }

        private async Task procesarPendiente(Actualizacion actualizacionPendiente)
        {
            try
            {
                string chofer = _identityService.UserName();
                _logger.LogTrace("Creando el directorio para almacenar temporalmente el sqlite.db");
                var path = FileManagerUtility.CreateNewPath("sqlite");
                var name = $"{DateTimeOffset.UtcNow.ToString("yyyyMMddTHHmmssfffffffZ")}.db";
                _logger.LogTrace("Creando la base sqlite.db");
                _inicializadorDataAccess.CrearBaseSqlite(path, name);
                _logger.LogTrace("Se obtiene la nueva versión");
                int vr = _configuracionRepository.ValorEntero32("vr");
                long version = await _unitOfWork.actualizacion.NuevaVersion(vr, chofer);
                _logger.LogTrace("Guardando datos en la base sqlite.db");
                await _inicializadorDataAccess.GenerarBaseSqlite(actualizacionPendiente, version);
                _logger.LogTrace("Subiendo el archivo al storage");
                actualizacionPendiente.Url = await _storageService.PushToStorageAsync(path, name);
                _logger.LogTrace("Borrando directorio temporal");
                FileManagerUtility.DeleteFile(path, name);
                actualizacionPendiente.IdEstado = EstadoActualizacion.LISTO_PARA_SINCRONIZAR;
                actualizacionPendiente.NroActualizacion = Generator.PIN();
                actualizacionPendiente.Version = version;
                _unitOfWork.actualizacion.Update(actualizacionPendiente);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message, actualizacionPendiente);
                actualizacionPendiente.IdEstado = EstadoActualizacion.ERROR;
            }
            finally
            {
                _unitOfWork.SaveChanges();
            }
        }

        public async Task<byte[]> Descargar(int nroActualizacion, long version, string? dispositivo)
        {
            byte[] result;
            try
            {
                string chofer = _identityService.UserName();
                Actualizacion? actualizacion = await _unitOfWork.actualizacion.GetAsync(chofer, nroActualizacion);
                if (actualizacion is not null)
                {
                    string mensaje = validacionDescarga(actualizacion, nroActualizacion, version);
                    if (!string.IsNullOrEmpty(mensaje))
                    {
                        throw new ShowException(mensaje, ShowException.BAD_REQUEST);
                    }
                    Instalacion instalacion = new();
                    instalacion.IdActualizacion = actualizacion.Id;
                    instalacion.Dispositivo = dispositivo ?? string.Empty;
                    instalacion.Chofer = chofer;
                    instalacion.NroActualizacionUsado = nroActualizacion;
                    _instalacionRepository.Insert(instalacion);
                    result = await _storageService.GetStorageAsync(actualizacion.Url);
                    _unitOfWork.SaveChanges();
                    return result;
                }
                else
                {
                    throw new ShowException("La actualización no existe", ShowException.BAD_REQUEST);
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
        }

        private string validacionDescarga(Actualizacion actualizacion, int nroActualizacion, long version)
        {
            string mensaje = string.Empty;
            int instalaciones = _instalacionRepository.CantDeInstalaciones(actualizacion.Id, nroActualizacion);
            int cpina = _configuracionRepository.ValorEntero32("cpina");
            if (actualizacion.Url is null
            || !actualizacion.IdEstado.Equals(EstadoActualizacion.LISTO_PARA_SINCRONIZAR))
            {
                mensaje = "La actualización aún no está disponible";
            }
            if (actualizacion.Version <= version)
            {
                mensaje = "No hay una versión para actualizar";
            }
            if (instalaciones >= cpina)
            {
                mensaje = "El número de actualización fue rechazado";
            }
            return mensaje;
        }

        #region Actualizaciones

        public async Task<Actualizacion?> AltaActualizacionesAsync(AltaActualizaciones model)
        {
            string id = _unitOfWork.actualizacion.AltaActualizacionesAsync(model);
            await _unitOfWork.SaveChangesAsync();
            var actualizacion = await GetByIdAsync(id,false);
            _unitOfWork.Dispose();
            return actualizacion;
        }

        public async Task<Actualizacion> BajaActualizacionAsync(string id)
        {
            await _unitOfWork.actualizacion.BajaActualizacionesByIdAsync(id);
            await _unitOfWork.SaveChangesAsync();
            var actualizacion =await GetByIdAsync(id, true);
            _unitOfWork.Dispose();
            return actualizacion;
        }

        public async Task<Actualizacion?> BlanqueoNroActualizacion(string id)
        {
            await _unitOfWork.actualizacion.BlanqueoNroActualizacion(id);
            await _unitOfWork.SaveChangesAsync();
            var actualizacion = await GetByIdAsync(id, false);
            _unitOfWork.Dispose();
            return actualizacion;
        }

        public async Task<Actualizacion> BuscarActualizacionPorIdAsync(string id)
        {
            return await _unitOfWork.actualizacion.BuscarActualizacionesByIdAsync(id);
        }

        public async Task<Actualizaciones?> BuscarActualizacionesPorFiltrosAsync(FiltrosBuscarActualizaciones? filtros, int limite, int pagina, string? order, string? tipoOrder)
        {
            return await _unitOfWork.actualizacion.BuscarActualizacionesPorFiltrosAsync(filtros, limite, pagina, order, tipoOrder);
        }

        public async Task<Actualizacion> ModificarActualizacionAsync(string id, ModificarActualizaciones model)
        {
            await _unitOfWork.actualizacion.ModificarActualizacionAsync(id,model);
            await _unitOfWork.SaveChangesAsync();
            var actualizacion = await GetByIdAsync(id, false);
            _unitOfWork.Dispose();
            return actualizacion;
        }

        #endregion

        public async Task<IEnumerable<Usuarios>?> BuscarUsuarios(string patron)
        {
            return await _unitOfWork.actualizacion.BuscarUsuarios(patron);
        }

        public async Task<IEnumerable<dynamic>?> BuscarPatentes(string? patron)
        {
            var data = await _unitOfWork.actualizacion.BuscarPatentes(patron);

            List<Select> patentes = new();

            foreach (var tabla in data)
            {
                List<object> columnas = new();

                foreach (var column in tabla)
                {
                    columnas.Add(column.Value);
                }

                patentes.Add(
                    new Select()
                    {
                        Id = int.Parse(columnas[0].ToString()),
                        Nombre = (string)columnas[1]
                    });
            }
            return patentes;
        }

        public async Task<IEnumerable<dynamic>?> BuscarPlantas()
        {
            var data = await _unitOfWork.actualizacion.BuscarPlantas();

            List<Select> patentes = new();

            foreach (var tabla in data)
            {
                List<object> columnas = new();

                foreach (var column in tabla)
                {
                    columnas.Add(column.Value);
                }

                patentes.Add(
                    new Select()
                    {
                        Id = int.Parse(columnas[0].ToString()),
                        Nombre = (string)columnas[1]
                    });
            }
            return patentes;
        }

        public async Task<IEnumerable<EstadoActualizacionDto>> BuscarEstados()
        {
            return await _unitOfWork.actualizacion.BuscarEstados();
        }

        private async Task<Actualizacion?> GetByIdAsync(string id, bool del)
        {
            return await _unitOfWork.actualizacion.GetByIdAsync(id, del);
        }
    }
}
