﻿
using HandHeld.PDAManagement.DataAccess.Layer.Models.Business;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Reponse;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core.Request;
using HandHeld.PDAManagement.Presentation.Layer.Models;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace HandHeld.PDAManagement.Business.Layer.Services.Interfaces
{
    public interface IInicializadorService
    {
        Task ProcesarPendientes();
        Task<byte[]> Descargar(int nroActualizacion, long version, string? dispositivo);
        Task<IEnumerable<dynamic>?> BuscarPatentes(string? patron);
        Task<IEnumerable<dynamic>?> BuscarPlantas();
        Task<Actualizaciones?> BuscarActualizacionesPorFiltrosAsync(FiltrosBuscarActualizaciones? filtros, int limite, int pagina, string? order, string? tipoOrder);
        Task<Actualizacion> BuscarActualizacionPorIdAsync(string id);
        Task<Actualizacion?> AltaActualizacionesAsync(AltaActualizaciones model);
        Task<Actualizacion> BajaActualizacionAsync(string id);
        Task<Actualizacion> ModificarActualizacionAsync(string id, ModificarActualizaciones model);
        Task<Actualizacion?> BlanqueoNroActualizacion(string id);
        Task<IEnumerable<Usuarios>?> BuscarUsuarios(string patron);
        Task<IEnumerable<EstadoActualizacionDto>> BuscarEstados();
    }
}
