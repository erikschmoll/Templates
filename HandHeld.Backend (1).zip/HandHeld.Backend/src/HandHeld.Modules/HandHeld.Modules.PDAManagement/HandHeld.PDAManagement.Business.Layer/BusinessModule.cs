﻿using HandHeld.PDAManagement.Business.Layer.Services.Implementations;
using HandHeld.PDAManagement.Business.Layer.Services.Interfaces;
using HandHeld.PDAManagement.DataAccess.Layer;
using HandHeld.PDAManagement.DataAccess.Layer.Models.Core;
using HandHeld.PDAManagement.DataAccess.Layer.Repositories.Interfaces.DataBase.YPFGas;
using Hangfire;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("HandHeld.PDAManagement.Presentation.Layer")]
namespace HandHeld.PDAManagement.Business.Layer
{
    internal static class BusinessModule
    {
        public static IServiceCollection AddBusinessModule(this IServiceCollection services, IConfiguration configuration)
        {
            

            string connectionString = configuration.GetConnectionString("Default");
            services.AddHangfire(x => x.UseSqlServerStorage(connectionString));
            services.AddHangfireServer();

            services.AddDataAccessModule(configuration);
            return services;
        }
        public static IApplicationBuilder UseBusinessModule(this IApplicationBuilder app, IConfiguration configuration)
        {
            app.UseHangfireDashboard();
            scheduler(configuration);
            return app;
        }


        private static void scheduler(IConfiguration configuration)
        {
            var CRON = configuration.GetSection("CRONDB").Value ?? "*/10 * * * *";
            RecurringJob.AddOrUpdate<InicializadorService>
                ("Inicializador", (ini) => ini.ProcesarPendientes(), CRON);
        }
    }
}

