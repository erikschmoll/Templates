﻿
namespace HandHeld.PDAManagement.Business.Layer.DataContracts
{
    public class Select
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
    }
}
