﻿using HandHeld.PDA.DataAccess.Layer;
using HandHeld.PDA.DataAccess.Layer.Repositories.Implementations.WebServices;
using HandHeld.PDA.DataAccess.Layer.Repositories.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("HandHeld.PDA.Presentation.Layer")]
namespace HandHeld.PDA.Business.Layer
{
    internal static class BusinessModule
    {
        public static IServiceCollection AddBusinessModule(this IServiceCollection services, IConfiguration configuration)
        {
            #region Services
            

            #endregion
            services.AddDataAccessModule(configuration);
            return services;
        }
    }
}
