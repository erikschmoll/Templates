﻿using HandHeld.PDA.Business.Layer;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace HandHeld.PDA.Presentation.Layer
{
    public static class PDAModule
    {
        public static IServiceCollection AddPDAModule(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddBusinessModule(configuration);
            return services;
        }
        public static IApplicationBuilder UsePDAModule(this IApplicationBuilder app)
        {

            return app;
        }
    }
}
