﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HandHeld.PDA.Presentation.Layer.Controllers
{
    [Route(BasePath)]
    public class HomeController : BaseController
    {
        //[Authorize(AuthenticationSchemes = "Azure,Custom")]
        [HttpGet]
        public ActionResult<string> Get() => "Modulo de PDA's";
    }
}
