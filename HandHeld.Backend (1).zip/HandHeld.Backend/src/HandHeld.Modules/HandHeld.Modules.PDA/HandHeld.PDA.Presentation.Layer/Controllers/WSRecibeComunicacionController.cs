﻿using Microsoft.AspNetCore.Mvc;
using RecibeComunicacionTesting;
using HandHeld.PDA.DataAccess.Layer.Repositories.Interfaces;

namespace HandHeld.PDA.Presentation.Layer.Controllers
{

    public class WSRecibeComunicacionController : BaseController
    {

        private readonly IRecibeComunicacionService _rcs;

        public WSRecibeComunicacionController(IRecibeComunicacionService recibeComunicacionServ)
        {
            _rcs = recibeComunicacionServ;
        }

        #region Notes
        //Endpoints eliminados:
        //public void ConfirmaRendicionSAP(string NroViaje)
        //public void CierraCasoDesdeSAP()
        //public Apertura ConfirmaAperturaDeViajeExtendida(string IDViaje, string IDPlanta, string IDPatente, string IDChofer)
        //public Respuesta AnulaAperturaDeViaje(string IDViaje)
        //public void Generica(string Clave)
        //public void ActualizaPatentes()
        //public Respuesta VerificaComunicacionConBDSC()
        //public Respuesta VerificaComunicacionConBDINC()
        //public Respuesta VerificaComunicacionConSAP()
        //public Respuesta VerificaVersion()

        //Endpoints que aparecen en el servicio, pero no en el código:
        //ActualizarGpsXCRS
        //RecibeCierreDeViaje -> Agregado
        //VerificaComunicacionConTipificaciones


        //ToDO: Falta agregar el selector de Mock o ambiente "Real" (En DataAccessModule.cs)

        #endregion

        /// <summary>
        /// Este entry point es llamado por el botón "Siguiente" de la pantalla "Consulta/entregar/documento"/
        /// </summary>
        /// <param name="oEntregaHH">Debe enviarse el objeto JSON en el body del siguiente endpoint: "https://localhost:7297/api/modulo-gestion-pda/WSRecibeComunicacion/RecibeEntrega"</param>
        /// <returns>Devuelve un objeto "Respuesta"</returns>
        /// <exception cref="Exception">Sí es valor del parámetro es 0 o está vacío</exception>
        [HttpPut("/api/modulo-gestion-pda/WSRecibeComunicacion/RecibeEntrega")]
        public async Task<Respuesta> RecibeEntrega(Entrega oEntregaHH)
        {
            if (oEntregaHH == null)
            {
                throw new Exception("Error: hay parámetros nulos");
            }

            Respuesta res = await _rcs.RecibeEntrega(oEntregaHH);

            return res;
        }

        /// <summary>
        /// Este entry point es llamado por el botón  "Cerrar" de la pantalla "Transporte/Cierre stock final"/
        /// </summary>
        /// <param name="oCierreViajeHH">Debe enviarse el objeto JSON en el body del siguiente endpoint: "https://localhost:7297/api/modulo-gestion-pda/WSRecibeComunicacion/RecibeCierreDeViaje"</param>
        /// <returns>Devuelve un objeto "Respuesta"</returns>
        /// <exception cref="Exception">Sí es valor del parámetro es 0 o está vacío</exception>
        [HttpPut("/api/modulo-gestion-pda/WSRecibeComunicacion/RecibeCierreDeViaje")]
        public async Task<Respuesta> RecibeCierreDeViaje(CierreViaje oCierreViajeHH)
        {

            if (oCierreViajeHH == null)
            {
                throw new Exception("Error: hay parámetros nulos");
            }

            Respuesta res = await _rcs.RecibeCierreDeViaje(oCierreViajeHH);

            return res;
        }


        /// <summary>
        /// Este entry point es llamado por el botón  "Más pedidos" de la pantalla "Transporte/Consulta pedidos"/
        /// </summary>
        /// <param name="IDTransporte, IDPedido">Debe enviarse en la query de la siguiente manera: "https://localhost:7297/api/modulo-gestion-pda/WSRecibeComunicacion/BuscaPedidoPorID?IDTransporte=1&IDPedido=1"</param>
        /// <returns>Devuelve un objeto "PedidoLista"</returns>
        /// <exception cref="Exception">Sí algunos de los valores de parámetro está vacío</exception>
        [HttpGet("/api/modulo-gestion-pda/WSRecibeComunicacion/BuscaPedidoPorID")]
        public async Task<PedidoLista> BuscaPedidoPorID(string IDTransporte, string IDPedido)
        {

            if (IDTransporte == null | IDPedido == null)
            {
                throw new Exception("Error: hay parámetros nulos");
            }

            PedidoLista res = await _rcs.BuscaPedidoPorID(IDTransporte, IDPedido);

            return res;
        }

        /// <summary>
        /// Este entry point es llamado por el botón sincronizar de la pantalla Transporte/
        /// </summary>
        /// <param name="IDViaje">Debe enviarse en la query de la siguiente manera: "https://server:port/api/modulo-pda/WSRecibeComuinicacion/SolicitaNovedadTransporte?IDViaje=0"
        /// El parámetro es de tipo long</param>
        /// <returns>Devuelve un objeto "Respuesta"</returns>
        /// <exception cref="Exception">Sí es valor del parámetro es 0 o está vacío</exception>
        [HttpPut("/api/modulo-gestion-pda/WSRecibeComunicacion/SolicitaNovedadTransporte")]
        public async Task<Respuesta> SolicitaNovedadTransporte(long IDViaje)
        {

            if (IDViaje == null| IDViaje == 0)
            {
                throw new Exception("Error: hay parámetros nulos");
            }

            Respuesta res = await _rcs.SolicitaNovedadTransporte(IDViaje);

            return res;
        }


        //[HttpPut("AnulaDocumento")]
        //public async Task<Respuesta> AnulaDocumento(Anulacion oAnulacion)
        //{

        //    if (oAnulacion == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    Respuesta res = await _rcs.AnulaDocumento(oAnulacion);

        //    return res;

        //}


        //[HttpPut("RecibeApertura")]
        //public async Task<Respuesta> RecibeApertura(InicioViaje oInicioViaje)
        //{

        //    if (oInicioViaje == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    Respuesta res = await _rcs.RecibeApertura(oInicioViaje);

        //    return res;
        //}

        //[HttpPut("RecibeRNA")]
        //public async Task<Respuesta> RecibeRNA(RazonDeNoAbastecido oRazonDeNoAbastecido)
        //{

        //    if (oRazonDeNoAbastecido == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    Respuesta res = await _rcs.RecibeRNA(oRazonDeNoAbastecido);

        //    return res;
        //}



        //[HttpPut("RecibeCobranza")]
        //public async Task<Respuesta> RecibeCobranza(Recibo oReciboHH)
        //{

        //    if (oReciboHH == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    Respuesta res = await _rcs.RecibeCobranza(oReciboHH);

        //    return res;
        //}

        //[HttpPut("RecibeIncidencia")]
        //public async Task<Respuesta> RecibeIncidencia(Incidencia oInicidenciaHH)
        //{

        //    if (oInicidenciaHH == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    Respuesta res = await _rcs.RecibeIncidencia(oInicidenciaHH);

        //    return res;
        //}

        //[HttpPut("RecibeFactura")]
        //public async Task<Respuesta> RecibeFactura(Factura oFacturaHH)
        //{

        //    if (oFacturaHH == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    Respuesta res = await _rcs.RecibeFactura(oFacturaHH);

        //    return res;
        //}

        //[HttpPut("RecibePedido")]
        //public async Task<Respuesta> RecibePedido(Pedido oPedidoHH)
        //{

        //    if (oPedidoHH == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    Respuesta res = await _rcs.RecibePedido(oPedidoHH);

        //    return res;
        //}





        //[HttpPut("RecibeMovimientoStock")]
        //public async Task<Respuesta> RecibeMovimientoStock(MovimientoStock oMovimientoStockHH)
        //{

        //    if (oMovimientoStockHH == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    Respuesta res = await _rcs.RecibeMovimientoStock(oMovimientoStockHH);

        //    return res;
        //}

        //[HttpGet("VerificaComunicacion")]
        //public async Task<Respuesta> VerificaComunicacion()
        //{

        //    Respuesta res = await _rcs.VerificaComunicacion();

        //    return res;
        //}

        //[HttpGet("FechaServidor")]
        //public async Task<FechaActual> FechaServidor()
        //{

        //    FechaActual res = await _rcs.FechaServidor();

        //    return res;
        //}

        //[HttpGet("BuscaPedidoPorID")]
        //public async Task<PedidoLista> BuscaPedidoPorID(string IDTransporte, string IDPedido)
        //{

        //    if (IDTransporte == null | IDPedido == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    PedidoLista res = await _rcs.BuscaPedidoPorID(IDTransporte, IDPedido);


        //    return res;
        //}

        //[HttpGet("BuscaPedidoPorBoca")]
        //public async Task<PedidoLista> BuscaPedidoPorBoca(string IDTransporte, string IDBoca)
        //{

        //    if (IDTransporte == null | IDBoca == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    PedidoLista res = await _rcs.BuscaPedidoPorBoca(IDTransporte, IDBoca);

        //    return res;
        //}

        //[HttpGet("BuscaTransporte")]
        //public async Task<ViajeLista> BuscaTransporte(string IDPlanta, string IDPatente, string IDChofer, string IDTipoViaje)
        //{

        //    if (IDPlanta == null | IDPatente == null | IDChofer == null | IDTipoViaje == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    ViajeLista res = await _rcs.BuscaTransporte(IDPlanta, IDPatente, IDChofer, IDTipoViaje);

        //    return res;
        //}

        //[HttpGet("BuscaTransporteSeleccionado")]
        //public async Task<ViajeSeleccionado> BuscaTransporteSeleccionado(string IDViaje, string IDPlanta, string IDPatente, string IDChofer)
        //{

        //    if (IDViaje == null | IDPlanta == null | IDPatente == null | IDChofer == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    ViajeSeleccionado res = await _rcs.BuscaTransporteSeleccionado(IDViaje, IDPlanta, IDPatente, IDChofer);

        //    return res;
        //}

        //[HttpPut("ConfirmaAperturaDeViaje")]
        //public async Task<Apertura> ConfirmaAperturaDeViaje(string IDViaje, string IDPlanta, string IDPatente, string IDChofer)
        //{

        //    if (IDViaje == null | IDPlanta == null | IDPatente == null | IDChofer == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    Apertura res = await _rcs.ConfirmaAperturaDeViaje(IDViaje, IDPlanta, IDPatente, IDChofer);

        //    return res;
        //}

        //[HttpGet("BuscaCliente")]
        //public async Task<Cliente> BuscaCliente(string IDBoca)
        //{

        //    if (IDBoca == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    Cliente res = await _rcs.BuscaCliente(IDBoca);

        //    return res;
        //}

        //[HttpGet("ObtenerPesadaFinal")]
        //public async Task<Pesada> ObtenerPesadaFinal(string IDPatente)
        //{

        //    if (IDPatente == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    Pesada res = await _rcs.ObtenerPesadaFinal(IDPatente);

        //    return res;
        //}


        //[HttpPut("ConfirmaAperturaDeViajeComprimida")]
        //public async Task<byte[]> ConfirmaAperturaDeViajeComprimida(string IDViaje, string IDPlanta, string IDPatente, string IDChofer)
        //{

        //    if (IDViaje == null | IDPlanta == null | IDPatente == null | IDChofer == null)
        //    {
        //        throw new Exception("Error: hay parámetros nulos");
        //    }

        //    byte[] res = await _rcs.ConfirmaAperturaDeViajeComprimida(IDViaje, IDPlanta, IDPatente, IDChofer);

        //    return res;
        //}
    }

}
