﻿using HandHeld.PDA.DataAccess.Layer.Repositories.Implementations.WebServices;
using HandHeld.PDA.DataAccess.Layer.Repositories.Interfaces;
using HandHeld.PDA.DataAccess.Layer.UnitOfWork;
using HandHeld.Shared.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Runtime.CompilerServices;


[assembly: InternalsVisibleTo("HandHeld.PDA.Business.Layer")]
namespace HandHeld.PDA.DataAccess.Layer
{
    internal static class DataAccessModule
    {
        public static IServiceCollection AddDataAccessModule(this IServiceCollection services, IConfiguration configuration)
        {
            string connectionString = configuration.GetConnectionString("Default");
            services.AddDbContext<PDADbContext>(options => options.UseSqlServer(connectionString));
            
            services.AddScoped<IUnitOfWork, UnitOfWork.UnitOfWork>();


          
            if (InfrastructureModule.GetEnvironment().Equals("Development"))
            {
                services.AddScoped<IRecibeComunicacionService, RecibeComunicacionMockService>();
            }
            else
            {
                services.AddScoped<IRecibeComunicacionService, RecibeComunicacionTestingService>();
            }

            return services;
        }
    }
}
