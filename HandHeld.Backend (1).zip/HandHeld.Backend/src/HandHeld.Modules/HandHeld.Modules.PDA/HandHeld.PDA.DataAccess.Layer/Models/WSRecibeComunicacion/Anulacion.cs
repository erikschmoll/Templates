﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Anulacion
    {
        public List<EntregaAnulada>? entregasField { get; set; }
        public List<FacturaAnulada>? facturasField { get; set; }
        public List<ReciboAnulado>? recibosField { get; set; }
        public List<MovimientoStockAnulado>? movimientosStockField { get; set; }

    }
}
