﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Recibo
    {
        public long iDReciboField { get; set; }
        public string? iDViajeField { get; set; }
        public string? serieField { get; set; }
        public long numeroField { get; set; }
        public DateTime fechaField { get; set; }
        public decimal importeField { get; set; }
        public string? iDUnidadImporteField { get; set; }
        public string? iDBocaField { get; set; }
        public GeoPosicion? geoPosicionField { get; set; }
        public List<Aplicacion>? aplicacionesField { get; set; }
        public List<Valor>? valoresField { get; set; }

    }
}
