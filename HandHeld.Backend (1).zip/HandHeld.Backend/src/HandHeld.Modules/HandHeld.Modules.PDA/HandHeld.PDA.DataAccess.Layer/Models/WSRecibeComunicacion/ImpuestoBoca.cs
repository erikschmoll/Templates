﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class ImpuestoBoca
    {
        public string? iDImpuestoField { get; set; }
        public DateTime fechaSujetoDesdeField { get; set; }
        public DateTime fechaSujetoHastaField { get; set; }
        public DateTime fechaExentoHastaField { get; set; }
        public int baseCalculoField { get; set; }
        public decimal porcentajeImpuestoField { get; set; }
        public decimal importeMinimoField { get; set; }
        public decimal porcentajeExentoField { get; set; }
        public string? iDUnidadImporteMinimoField { get; set; }

    }
}
