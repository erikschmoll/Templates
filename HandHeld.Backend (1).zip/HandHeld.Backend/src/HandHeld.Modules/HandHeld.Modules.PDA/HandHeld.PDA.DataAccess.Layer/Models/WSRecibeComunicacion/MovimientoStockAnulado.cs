﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class MovimientoStockAnulado
    {
        public long iDMovimientoField { get; set; }
        public string? iDViajeField { get; set; }
        public DateTime fechaAnulacionField { get; set; }
        public GeoPosicion? geoPosicionField { get; set; }

    }
}
