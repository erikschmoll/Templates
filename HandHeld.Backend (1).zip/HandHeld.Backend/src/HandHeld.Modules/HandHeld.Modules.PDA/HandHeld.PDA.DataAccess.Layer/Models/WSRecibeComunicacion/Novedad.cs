﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Novedad
    {
        public List<Patente>? patentesField { get; set; }
        public List<Usuario>? usuariosField { get; set; }
        public List<Titular>? titularesField { get; set; }
        public List<Boca>? bocasField { get; set; }
        public List<Feriado>? feriadosField { get; set; }
        public List<Banco>? bancosField { get; set; }
        public List<Sucursal>? sucursalesField { get; set; }

    }
}
