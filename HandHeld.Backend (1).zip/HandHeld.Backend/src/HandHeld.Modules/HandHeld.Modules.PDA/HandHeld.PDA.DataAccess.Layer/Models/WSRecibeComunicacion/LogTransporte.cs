﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class LogTransporte
    {
        public string? iDPedidoField { get; set; }
        public string? iDViajeField { get; set; }
        public string? operacionField { get; set; }

    }
}
