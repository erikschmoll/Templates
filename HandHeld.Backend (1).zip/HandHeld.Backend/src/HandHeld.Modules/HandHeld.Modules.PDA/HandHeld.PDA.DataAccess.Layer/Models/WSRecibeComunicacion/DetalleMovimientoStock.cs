﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class DetalleMovimientoStock
    {
        public long iDMovimientoField { get; set; }
        public string? iDViajeField { get; set; }
        public string? iDArticuloField { get; set; }
        public decimal cantidadField { get; set; }
        public decimal densidadField { get; set; }
        public string? iDUnidadField { get; set; }

    }
}
