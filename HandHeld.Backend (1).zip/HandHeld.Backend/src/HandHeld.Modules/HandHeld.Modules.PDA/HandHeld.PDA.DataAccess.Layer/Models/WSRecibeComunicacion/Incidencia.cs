﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Incidencia
    {
        public string? iDViajeField { get; set; }
        public long iDIncidenciaField { get; set; }
        public DateTime fechaField { get; set; }
        public string? observacionesField { get; set; }
        public string? iDTipoIncidenciaField { get; set; }
        public string? iDBocaField { get; set; }
        public GeoPosicion? geoPosicionField { get; set; }

    }
}
