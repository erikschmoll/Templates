﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Numerador
    {
        public string? tipoDocumentoField { get; set; }
        public string? serieField { get; set; }
        public long numeroDesdeField { get; set; }
        public long numeroHastaField { get; set; }

    }
}
