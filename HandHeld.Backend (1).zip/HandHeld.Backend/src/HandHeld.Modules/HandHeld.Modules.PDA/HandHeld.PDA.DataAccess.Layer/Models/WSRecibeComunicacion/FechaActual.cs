﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class FechaActual
    {
        public DateTime? fechaField { get; set; }
        public Respuesta? respuestaField { get; set; }

    }
}
