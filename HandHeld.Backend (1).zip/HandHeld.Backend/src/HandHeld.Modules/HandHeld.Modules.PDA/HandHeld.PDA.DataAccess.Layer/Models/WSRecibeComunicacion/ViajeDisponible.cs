﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class ViajeDisponible
    {
        public string? iDViajeField { get; set; }
        public DateTime fechaPlanificacionField { get; set; }

    }
}
