﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Sucursal
    {
        public string? iDSucursalField { get; set; }
        public string? sucursal1Field { get; set; }
        public string? iDBancoField { get; set; }

    }
}
