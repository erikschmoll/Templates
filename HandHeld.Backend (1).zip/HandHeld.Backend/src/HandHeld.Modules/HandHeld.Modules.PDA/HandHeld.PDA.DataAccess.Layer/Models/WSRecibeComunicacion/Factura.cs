﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Factura
    {
        public long iDDocumentoFacturaField { get; set; }
        public string? iDViajeField { get; set; }
        public long numeroField { get; set; }
        public string? serieField { get; set; }
        public string? letraField { get; set; }
        public decimal bonificacionProntoPagoField { get; set; }
        public int diasProntoPagoField { get; set; }
        public int diasSegundoVencimientoField { get; set; }
        public DateTime fechaField { get; set; }
        public DateTime fechaVencimientoField { get; set; }
        public decimal interesSegundoVencimientoField { get; set; }
        public decimal montoNetoField { get; set; }
        public decimal montoTotalField { get; set; }
        public long iDEntregaField { get; set; }
        public GeoPosicion? geoPosicionField { get; set; }
        public List<DetalleFactura>? detalleFacturaField { get; set; }

    }
}
