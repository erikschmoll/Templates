﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class InicioViaje
    {
        public string? iDViajeField { get; set; }
        public decimal temperaturaField { get; set; }
        public decimal densidadField { get; set; }
        public decimal litradorField { get; set; }
        public long kilometrosField { get; set; }
        public decimal rotaryField { get; set; }
        public decimal presionField { get; set; }

    }
}
