﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Precio
    {
        public string? iDArticuloField { get; set; }
        public string? iDBocaField { get; set; }
        public decimal precio1Field { get; set; }
        public string? iDUnidadPrecioNetoField { get; set; }
        public DateTime vigenciaDesdeField { get; set; }

    }
}
