﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class CuentaCorriente
    {
        public string? nroDocumentoSAPField { get; set; }
        public int ejercicioField { get; set; }
        public int posicionField { get; set; }
        public string? iDBocaField { get; set; }
        public string? claseDocumentoSAPField { get; set; }
        public string? serieField { get; set; }
        public string? letraField { get; set; }
        public long numeroField { get; set; }
        public int tieneAplicacionParcialField { get; set; }
        public DateTime fechaVencimientoField { get; set; }
        public decimal importeField { get; set; }
        public DateTime fechaSegundoVencimientoField { get; set; }
        public decimal importeSegundoVencimientoField { get; set; }
        public DateTime fechaProntoPagoField { get; set; }
        public decimal importeProntoPagoField { get; set; }
        public string? idMonedaImporteField { get; set; }

    }
}
