﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Usuario
    {
        public string? iDUsuarioField { get; set; }
        public string? claveField { get; set; }
        public string? nombreField { get; set; }

    }
}
