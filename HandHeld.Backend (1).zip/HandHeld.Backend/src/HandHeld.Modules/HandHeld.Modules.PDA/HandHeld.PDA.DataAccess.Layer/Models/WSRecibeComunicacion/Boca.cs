﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Boca
    {
        public string? iDBocaField { get; set; }
        public string? iDPlantaField { get; set; }
        public string? direccionField { get; set; }
        public string? poblacionField { get; set; }
        public string? telefonoField { get; set; }
        public string? iDTitularField { get; set; }
        public string? codigoPostalField { get; set; }
        public string? instruccionesDeAccesoField { get; set; }
        public string? iDZonaField { get; set; }
        public int usaSegundoVencimientoField { get; set; }
        public int usaProntoPagoField { get; set; }
        public string? iDProntoPagoField { get; set; }
        public int estaEnZonaFrancaField { get; set; }
        public string? razonSocialField { get; set; }
        public int diasPlazoPagoField { get; set; }
        public int usaDebitoAutomaticoField { get; set; }
        public int esFacturableField { get; set; }
        public string? iDRegionComercialField { get; set; }
        public string? iDTipoRegionComercialField { get; set; }
        public int estadoField { get; set; }
        public string? resolucionDGEField { get; set; }
        public List<Tanque>? tanquesField { get; set; }
        public List<ImpuestoBoca>? impuestosBocaField { get; set; }
        public List<CuentaCorriente>? cuentaCorrienteField { get; set; }
        public List<Precio>? preciosEspecialesField { get; set; }

    }
}
