﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class NovedadPlanificacion
    {
        public List<Pedido>? pedidosField { get; set; }
        public List<Titular>? titularesField { get; set; }
        public List<Boca>? bocasField { get; set; }
        public List<LogTransporte>? logTransporteField { get; set; }

    }
}
