﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class EntregaAnulada
    {
        public long iDEntregaField { get; set; }
        public string? iDViajeField { get; set; }
        public DateTime fechaAnulacionField { get; set; }
        public GeoPosicion? geoPosicionField { get; set; }

    }
}
