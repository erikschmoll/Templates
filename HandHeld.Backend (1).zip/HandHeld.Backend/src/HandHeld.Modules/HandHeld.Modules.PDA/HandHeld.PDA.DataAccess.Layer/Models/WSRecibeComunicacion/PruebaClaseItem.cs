﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class PruebaClaseItem
    {
        public string strIdItem { get; set; }
        public string strDataItem { get; set; }

    }
}
