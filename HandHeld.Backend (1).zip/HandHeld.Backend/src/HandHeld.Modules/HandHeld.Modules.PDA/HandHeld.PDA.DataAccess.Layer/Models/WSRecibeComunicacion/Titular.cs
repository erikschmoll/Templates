﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Titular
    {
        public string? iDTitularField { get; set; }
        public string? direccionField { get; set; }
        public string? poblacionField { get; set; }
        public string? titular1Field { get; set; }
        public string? codigoPostalField { get; set; }
        public string? iDFiscalField { get; set; }
        public string? iDTipoFiscalField { get; set; }
        public string? iDCategoriaFiscalField { get; set; }
        public string? iDRegionField { get; set; }
        public string? iDTipoRegionField { get; set; }

    }
}
