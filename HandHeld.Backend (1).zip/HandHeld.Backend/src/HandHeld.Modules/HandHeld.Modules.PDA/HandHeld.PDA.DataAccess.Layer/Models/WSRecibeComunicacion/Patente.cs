﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Patente
    {
        public string? iDPatenteField { get; set; }
        public string? tipoVehiculoField { get; set; }
        public int tieneMasicoField { get; set; }
        public string? empresaTransportistaField { get; set; }
        public double capacidadDeCargaField { get; set; }

    }
}
