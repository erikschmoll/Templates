﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Apertura
    {
        public string? iDTransporteField { get; set; }
        public string? tipoDeViajeField { get; set; }
        public string? iDPatenteField { get; set; }
        public string? iDPlantaField { get; set; }
        public string? iDChoferField { get; set; }
        public string? empresaTransportistaField { get; set; }
        public decimal pesadaInicialField { get; set; }
        public decimal densidadField { get; set; }
        public List<Stock>? stocksField { get; set; }
        public List<NumeradorAutomatico>? numeradoresAutomaticosField { get; set; }
        public List<NumeradorManual>? numeradoresManualesField { get; set; }
        public List<Pedido>? pedidosField { get; set; }
        public List<Titular>? titularesField { get; set; }
        public List<Boca>? bocasField { get; set; }
        public List<CuentaCorriente>? cuentasCorrientesField { get; set; }
        public Novedad? novedadesField { get; set; }
        public Respuesta? respuestaField { get; set; }

    }
}
