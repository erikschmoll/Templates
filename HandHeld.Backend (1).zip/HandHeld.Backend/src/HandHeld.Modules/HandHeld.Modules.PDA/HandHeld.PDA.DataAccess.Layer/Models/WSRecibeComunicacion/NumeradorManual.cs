﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class NumeradorManual
    {
        public string? tipoDocumentoField { get; set; }
        public string? serieField { get; set; }
        public long numeroDisponibleField { get; set; }
        public string? iDBocaField { get; set; }

    }
}
