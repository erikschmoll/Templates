﻿

namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class DetallePedido
    {
        public decimal cantidadField { get; set; }
        public string? iDArticuloField { get; set; }
        public decimal importeField { get; set; }

    }
}
