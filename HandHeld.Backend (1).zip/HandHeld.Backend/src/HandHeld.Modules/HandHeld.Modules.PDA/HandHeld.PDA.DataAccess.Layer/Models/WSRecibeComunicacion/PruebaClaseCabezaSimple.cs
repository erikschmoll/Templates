﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class PruebaClaseCabezaSimple
    {
        public string strIdCabeza { get; set; }
        public string strDataCabeza { get; set; }

        public PruebaClaseItem pruebaClaseItemField { get; set; }
    }
}
