﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Zona
    {
        public string? iDZonaField { get; set; }
        public string? zona1Field { get; set; }

    }
}
