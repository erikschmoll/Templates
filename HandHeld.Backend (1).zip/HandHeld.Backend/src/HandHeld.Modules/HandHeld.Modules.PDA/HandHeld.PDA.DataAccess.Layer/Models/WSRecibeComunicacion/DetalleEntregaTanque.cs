﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class DetalleEntregaTanque
    {
        public string? iDTanqueField { get; set; }
        public decimal porcentajeFinalField { get; set; }
        public string? precintoNuevoField { get; set; }

    }
}
