﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class PedidoLista
    {
        public List<Pedido>? pedidosField { get; set; }
        public Respuesta? respuestaField { get; set; }

    }
}
