﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class DetalleEntrega
    {
        public string? iDArticuloField { get; set; }
        public decimal cantidadField { get; set; }
        public decimal densidadField { get; set; }
        public string? iDUnidadCantidadField { get; set; }

    }
}
