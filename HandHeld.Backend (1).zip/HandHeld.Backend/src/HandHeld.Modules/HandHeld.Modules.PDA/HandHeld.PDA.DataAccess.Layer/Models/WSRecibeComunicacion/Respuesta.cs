﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Respuesta
    {
        public int codigoField { get; set; }
        public string? descripcionField { get; set; }
        public NovedadPlanificacion? novedadesPlanificacionField { get; set; }

    }
}
