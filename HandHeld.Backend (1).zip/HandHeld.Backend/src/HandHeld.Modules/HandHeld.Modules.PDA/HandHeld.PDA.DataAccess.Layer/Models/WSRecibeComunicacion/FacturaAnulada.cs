﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class FacturaAnulada
    {
        public long iDDocumentoFacturaField { get; set; }
        public string? iDViajeField { get; set; }
        public DateTime fechaAnulacionField { get; set; }
        public GeoPosicion? geoPosicionField { get; set; }

    }
}
