﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class RazonDeNoAbastecido
    {
        public string? iDViajeField { get; set; }
        public string? iDPedidoField { get; set; }
        public int secuenciaField { get; set; }
        public DateTime fechaField { get; set; }
        public string? observacionesField { get; set; }
        public string? iDTipoRazonDeNoAbastecidoField { get; set; }
        public GeoPosicion? geoPosicionField { get; set; }

    }
}
