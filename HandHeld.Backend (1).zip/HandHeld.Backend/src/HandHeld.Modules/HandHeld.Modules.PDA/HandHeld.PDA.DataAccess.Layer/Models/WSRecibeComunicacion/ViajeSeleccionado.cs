﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class ViajeSeleccionado
    {
        public string? iDViajeField { get; set; }
        public string? tipoDeViajeField { get; set; }
        public string? iDPatenteField { get; set; }
        public string? iDPlantaField { get; set; }
        public string? iDChoferField { get; set; }
        public string? empresaTransportistaField { get; set; }
        public decimal pesadaInicialField { get; set; }
        public List<Stock>? stocksField { get; set; }
        public List<Numerador>? numeradoresField { get; set; }
        public List<Zona>? zonasField { get; set; }
        public Respuesta? respuestaField { get; set; }

    }
}
