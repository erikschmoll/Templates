﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Entrega
    {
        public long iDEntregaField { get; set; }
        public string? iDViajeField { get; set; }
        public long numeroField { get; set; }
        public string? serieField { get; set; }
        public int kilometrosField { get; set; }
        public decimal kilosFinalField { get; set; }
        public decimal kilosInicialField { get; set; }
        public decimal litrajeFinalField { get; set; }
        public decimal litrajeInicialField { get; set; }
        public DateTime fechaField { get; set; }
        public string? iDPedidoField { get; set; }
        public string? iDBocaField { get; set; }
        public GeoPosicion? geoPosicionInicialField { get; set; }
        public GeoPosicion? geoPosicionFinalField { get; set; }
        public List<DetalleEntrega>? detallesEntregaField { get; set; }
        public List<DetalleEntregaTanque>? detalleEntregaTanqueField { get; set; }

    }
}
