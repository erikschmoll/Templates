﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Cliente
    {
        public Titular? titularField { get; set; }
        public Boca? bocaField { get; set; }
        public Respuesta? respuestaField { get; set; }

    }
}
