﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Pesada
    {
        public string? iDPatenteField { get; set; }
        public decimal pesadaFinalField { get; set; }
        public Respuesta? respuestaField { get; set; }

    }
}
