﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class GeoPosicion
    {
        public long iDGeoPosicionField { get; set; }
        public decimal latitudField { get; set; }
        public decimal longitudField { get; set; }
        public DateTime tiempoLocalField { get; set; }
        public DateTime tiempoGPSField { get; set; }

    }
}
