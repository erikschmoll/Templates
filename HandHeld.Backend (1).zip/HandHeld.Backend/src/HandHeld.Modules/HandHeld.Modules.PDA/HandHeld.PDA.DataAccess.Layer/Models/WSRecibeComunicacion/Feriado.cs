﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Feriado
    {
        public DateTime fechaField { get; set; }

    }
}
