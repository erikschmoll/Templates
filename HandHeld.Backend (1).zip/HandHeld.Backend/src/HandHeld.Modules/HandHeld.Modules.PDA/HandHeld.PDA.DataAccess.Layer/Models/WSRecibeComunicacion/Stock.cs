﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Stock
    {
        public string? iDArticuloField { get; set; }
        public decimal cantidadField { get; set; }

    }
}
