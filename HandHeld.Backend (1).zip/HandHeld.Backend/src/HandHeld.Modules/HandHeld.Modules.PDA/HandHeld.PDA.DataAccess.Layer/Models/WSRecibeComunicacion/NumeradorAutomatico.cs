﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class NumeradorAutomatico
    {
        public string? tipoDocumentoField { get; set; }
        public string? serieField { get; set; }
        public long ultimoNumeroUsadoField { get; set; }
        public string? numeroCAIField { get; set; }
        public DateTime fechaVencimientoCAIField { get; set; }
        public DateTime fechaInicioActividadesField { get; set; }

    }
}
