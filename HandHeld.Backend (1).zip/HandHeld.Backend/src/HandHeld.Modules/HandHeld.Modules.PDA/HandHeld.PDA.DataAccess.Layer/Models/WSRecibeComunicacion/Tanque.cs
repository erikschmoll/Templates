﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Tanque
    {
        public string? iDTanqueField { get; set; }
        public decimal capacidadField { get; set; }
        public string? iDUnidadCapacidadField { get; set; }
        public string? iDArticuloField { get; set; }
        public string? matriculaField { get; set; }

    }
}
