﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Valor
    {
        public long iDReciboField { get; set; }
        public long iDViajeField { get; set; }
        public long iDValorField { get; set; }
        public DateTime fechaEmisionField { get; set; }
        public DateTime fechaVencimientoField { get; set; }
        public decimal importeField { get; set; }
        public string? numeroField { get; set; }
        public string? iDUnidadImporteField { get; set; }
        public string? iDViaDePagoField { get; set; }
        public string? iDSucursalField { get; set; }
        public string? iDBancoField { get; set; }

    }
}
