﻿
using System.Xml.Serialization;

namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
     public class Aplicacion
    {
        public long iDReciboField { get; set; }
        public long iDDocumentoField { get; set; }
        public string? nroDocumentoSAPField { get; set; }
        public int ejercicioField { get; set; }
        public int posicionField { get; set; }
        public int ordenField { get; set; }
        public decimal importeField { get; set; }
        public string? estadoField { get; set; }

    }
}
