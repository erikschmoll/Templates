﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class MovimientoStock
    {
        public long iDMovimientoField { get; set; }
        public string? iDViajeField { get; set; }
        public string? codOperacionField { get; set; }
        public string? iDBocaDespachoField { get; set; }
        public string? iDAlmacenField { get; set; }
        public string? iDPlantaField { get; set; }
        public string? serieField { get; set; }
        public long numeroField { get; set; }
        public string? patenteTanqueField { get; set; }
        public string? patenteTractorField { get; set; }
        public DateTime fechaOperacionInicialField { get; set; }
        public DateTime fechaOperacionFinalField { get; set; }
        public DateTime fechaMovimientoField { get; set; }
        public string? remitoReferenciaField { get; set; }
        public int kilometrosField { get; set; }
        public decimal kilosFinalField { get; set; }
        public decimal kilosInicialField { get; set; }
        public decimal litrajeFinalField { get; set; }
        public decimal litrajeInicialField { get; set; }
        public decimal temperaturaField { get; set; }
        public GeoPosicion? geoPosicionField { get; set; }
        public List<DetalleMovimientoStock>? detallesMovimientoStockField { get; set; }

    }
}
