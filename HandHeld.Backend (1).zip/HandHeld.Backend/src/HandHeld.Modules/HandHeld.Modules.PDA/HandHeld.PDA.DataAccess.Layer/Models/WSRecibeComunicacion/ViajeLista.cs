﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class ViajeLista
    {
        public List<ViajeDisponible>? viajesField { get; set; }
        public Respuesta? respuestaField { get; set; }

    }
}
