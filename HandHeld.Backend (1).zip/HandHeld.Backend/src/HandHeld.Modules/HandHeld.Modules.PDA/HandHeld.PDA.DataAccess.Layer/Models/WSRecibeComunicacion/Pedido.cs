﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Pedido
    {
        public string? iDPedidoField { get; set; }
        public string? iDBocaField { get; set; }
        public string? iDPlantaField { get; set; }
        public DateTime fechaEntregaPreferenteField { get; set; }
        public string? horaDesdeField { get; set; }
        public string? horaHastaField { get; set; }
        public string? observacionesField { get; set; }
        public decimal importeCobroAnticipadoField { get; set; }
        public string? tipoDeCargaField { get; set; }
        public string? iDTipoPedidoField { get; set; }
        public int esFacturableField { get; set; }
        public string? condicionDePagoField { get; set; }
        public string? codigoExpressField { get; set; }
        public int esPlanificadoField { get; set; }
        public List<DetallePedido>? detallePedidosField { get; set; }

    }
}
