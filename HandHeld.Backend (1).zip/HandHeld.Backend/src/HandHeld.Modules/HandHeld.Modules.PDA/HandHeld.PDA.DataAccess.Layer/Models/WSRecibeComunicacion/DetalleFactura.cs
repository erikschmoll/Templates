﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class DetalleFactura
    {
        public string? iDViajeField { get; set; }
        public int iDDocumentoFacturaField { get; set; }
        public string? iDArticuloField { get; set; }
        public decimal cantidadField { get; set; }
        public string? iDUnidadCantidadField { get; set; }

    }
}
