﻿
namespace HandHeld.PDA.DataAccess.Layer.Models.WSRecibeComunicacion
{
    public class Banco
    {
        public string? iDBancoField { get; set; }
        public string? banco1Field { get; set; }

    }
}
