using Microsoft.EntityFrameworkCore;

namespace HandHeld.PDA.DataAccess.Layer
{
    public class PDADbContext : DbContext
    {
        public PDADbContext(DbContextOptions<PDADbContext> options) : base(options) 
        {
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }

    }
}
