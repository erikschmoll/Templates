﻿
namespace HandHeld.PDA.DataAccess.Layer.UnitOfWork
{
    public interface IUnitOfWork
    {
        void Dispose();
        void SaveChanges();
    }
}
