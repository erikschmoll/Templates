﻿
namespace HandHeld.PDA.DataAccess.Layer.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly PDADbContext _context;
        public UnitOfWork(PDADbContext context)
        {
            _context = context;
        }
        public void Dispose()
        {
            _context.Dispose();
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
