﻿using RecibeComunicacionTesting;
using HandHeld.PDA.DataAccess.Layer.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace HandHeld.PDA.DataAccess.Layer.Repositories.Implementations.WebServices
{
    public class RecibeComunicacionMockService: IRecibeComunicacionService
    {

		#region Variables Mock
		string RespuestaMockSimple = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<Respuesta>
    <Codigo>1</Codigo>
    <Descripcion>CORRECTO</Descripcion>
    <NovedadesPlanificacion>
        <Pedidos/>
        <Titulares/>
        <Bocas/>
        <LogTransporte/>
    </NovedadesPlanificacion>
</Respuesta>";

        string RespuestaMock = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<Respuesta>
	<codigoField>1234</codigoField>
	<descripcionField>Descrpicion</descripcionField>
	<novedadesPlanificacionField>
		<pedidosField>
			<Pedido>
				<iDPedidoField>ID123</iDPedidoField>
				<iDBocaField>IDBoca123</iDBocaField>
				<iDPlantaField>IDPlanta</iDPlantaField>
				<fechaEntregaPreferenteField>2022-09-01</fechaEntregaPreferenteField>
				<horaDesdeField>10:30</horaDesdeField>
				<horaHastaField>14:00</horaHastaField>
				<observacionesField>Observacion</observacionesField>
				<importeCobroAnticipadoField>9999</importeCobroAnticipadoField>
				<tipoDeCargaField>CargaA</tipoDeCargaField>
				<iDTipoPedidoField>PedidoTipo1</iDTipoPedidoField>
				<esFacturableField>1</esFacturableField>
				<condicionDePagoField>Contado</condicionDePagoField>
				<codigoExpressField>NO</codigoExpressField>
				<esPlanificadoField>1</esPlanificadoField>
				<detallePedidosField>
					<DetallePedido>
						<cantidadField>5</cantidadField>
						<iDArticuloField>ART001</iDArticuloField>
						<importeField>99999</importeField>
					</DetallePedido>
				</detallePedidosField>
			</Pedido>
		</pedidosField>
		<titularesField>
			<Titular>
				<iDTitularField>IDTitular123</iDTitularField>
				<direccionField>direccion123</direccionField>
				<poblacionField>poblacion</poblacionField>
				<titular1Field>titular1</titular1Field>
				<codigoPostalField>CP1234</codigoPostalField>
				<iDFiscalField>iDFiscal123</iDFiscalField>
				<iDTipoFiscalField>Tipo123</iDTipoFiscalField>
				<iDCategoriaFiscalField>Categoria123</iDCategoriaFiscalField>
				<iDRegionField>Region123</iDRegionField>
				<iDTipoRegionField>TipoReg123</iDTipoRegionField>
			</Titular>
		</titularesField>
		<bocasField>
			<Boca>
				<iDBocaField>Boca123</iDBocaField>
				<iDPlantaField>Planta123</iDPlantaField>
				<direccionField>Direccion123</direccionField>
				<poblacionField>poblacion</poblacionField>
				<telefonoField>011-1234-1234</telefonoField>
				<iDTitularField>Titular123</iDTitularField>
				<codigoPostalField>CP1234</codigoPostalField>
				<instruccionesDeAccesoField>Acceder por 123</instruccionesDeAccesoField>
				<iDZonaField>Zona123</iDZonaField>
				<usaSegundoVencimientoField>0</usaSegundoVencimientoField>
				<usaProntoPagoField>0</usaProntoPagoField>
				<iDProntoPagoField>NO</iDProntoPagoField>
				<estaEnZonaFrancaField>0</estaEnZonaFrancaField>
				<razonSocialField>RazonSocial</razonSocialField>
				<diasPlazoPagoField>60</diasPlazoPagoField>
				<usaDebitoAutomaticoField>0</usaDebitoAutomaticoField>
				<esFacturableField>1</esFacturableField>
				<iDRegionComercialField>RegionCom123</iDRegionComercialField>
				<iDTipoRegionComercialField>TipoRC123</iDTipoRegionComercialField>
				<estadoField>1</estadoField>
				<resolucionDGEField>REsDGEF</resolucionDGEField>
				<tanquesField>
					<Tanque>
						<iDTanqueField>string</iDTanqueField>
						<capacidadField>100</capacidadField>
						<iDUnidadCapacidadField>UnidadKG</iDUnidadCapacidadField>
						<iDArticuloField>Articulo123</iDArticuloField>
						<matriculaField>Matricula123</matriculaField>
					</Tanque>
				</tanquesField>
				<impuestosBocaField>
					<ImpuestoBoca>
						<iDImpuestoField>ID123</iDImpuestoField>
						<fechaSujetoDesdeField>2020-01-01</fechaSujetoDesdeField>
						<fechaSujetoHastaField>2030-01-01</fechaSujetoHastaField>
						<fechaExentoHastaField>2022-08-01</fechaExentoHastaField>
						<baseCalculoField>10</baseCalculoField>
						<porcentajeImpuestoField>21</porcentajeImpuestoField>
						<importeMinimoField>100</importeMinimoField>
						<porcentajeExentoField>10</porcentajeExentoField>
						<iDUnidadImporteMinimoField>Unidad123</iDUnidadImporteMinimoField>
					</ImpuestoBoca>
				</impuestosBocaField>
				<cuentaCorrienteField>
					<CuentaCorriente>
						<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
						<ejercicioField>2022</ejercicioField>
						<posicionField>150</posicionField>
						<iDBocaField>Boca123 </iDBocaField>
						<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
						<serieField>Serie1</serieField>
						<letraField>LetraA</letraField>
						<numeroField>999</numeroField>
						<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
						<fechaVencimientoField>2022-09-01</fechaVencimientoField>
						<importeField>9879</importeField>
						<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
						<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
						<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
						<importeProntoPagoField>1500</importeProntoPagoField>
						<idMonedaImporteField>ARS</idMonedaImporteField>
					</CuentaCorriente>
				</cuentaCorrienteField>
				<preciosEspecialesField>
					<Precio>
						<iDArticuloField>Articulo123</iDArticuloField>
						<iDBocaField>Boca123</iDBocaField>
						<precio1Field>520</precio1Field>
						<iDUnidadPrecioNetoField>Kg</iDUnidadPrecioNetoField>
						<vigenciaDesdeField>2022-01-01</vigenciaDesdeField>
					</Precio>
				</preciosEspecialesField>
			</Boca>
		</bocasField>
		<logTransporteField>
			<LogTransporte>
				<iDPedidoField>Pedido123</iDPedidoField>
				<iDViajeField>Viaje123</iDViajeField>
				<operacionField>Entrega</operacionField>
			</LogTransporte>
		</logTransporteField>
	</novedadesPlanificacionField>
</Respuesta>";

        string fechaActualMock = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<FechaActual>
	<fechaField>2022-08-01</fechaField>
	<respuestaField>
		<codigoField>1234</codigoField>
		<descripcionField>Descrpicion</descripcionField>
		<novedadesPlanificacionField>
			<pedidosField>
				<Pedido>
					<iDPedidoField>ID123</iDPedidoField>
					<iDBocaField>IDBoca123</iDBocaField>
					<iDPlantaField>IDPlanta</iDPlantaField>
					<fechaEntregaPreferenteField>2022-09-01</fechaEntregaPreferenteField>
					<horaDesdeField>10:30</horaDesdeField>
					<horaHastaField>14:00</horaHastaField>
					<observacionesField>Observacion</observacionesField>
					<importeCobroAnticipadoField>9999</importeCobroAnticipadoField>
					<tipoDeCargaField>CargaA</tipoDeCargaField>
					<iDTipoPedidoField>PedidoTipo1</iDTipoPedidoField>
					<esFacturableField>1</esFacturableField>
					<condicionDePagoField>Contado</condicionDePagoField>
					<codigoExpressField>NO</codigoExpressField>
					<esPlanificadoField>1</esPlanificadoField>
					<detallePedidosField>
						<DetallePedido>
							<cantidadField>5</cantidadField>
							<iDArticuloField>ART001</iDArticuloField>
							<importeField>99999</importeField>
						</DetallePedido>
					</detallePedidosField>
				</Pedido>
			</pedidosField>
			<titularesField>
				<Titular>
					<iDTitularField>IDTitular123</iDTitularField>
					<direccionField>direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<titular1Field>titular1</titular1Field>
					<codigoPostalField>CP1234</codigoPostalField>
					<iDFiscalField>iDFiscal123</iDFiscalField>
					<iDTipoFiscalField>Tipo123</iDTipoFiscalField>
					<iDCategoriaFiscalField>Categoria123</iDCategoriaFiscalField>
					<iDRegionField>Region123</iDRegionField>
					<iDTipoRegionField>TipoReg123</iDTipoRegionField>
				</Titular>
			</titularesField>
			<bocasField>
				<Boca>
					<iDBocaField>Boca123</iDBocaField>
					<iDPlantaField>Planta123</iDPlantaField>
					<direccionField>Direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<telefonoField>011-1234-1234</telefonoField>
					<iDTitularField>Titular123</iDTitularField>
					<codigoPostalField>CP1234</codigoPostalField>
					<instruccionesDeAccesoField>Acceder por 123</instruccionesDeAccesoField>
					<iDZonaField>Zona123</iDZonaField>
					<usaSegundoVencimientoField>0</usaSegundoVencimientoField>
					<usaProntoPagoField>0</usaProntoPagoField>
					<iDProntoPagoField>NO</iDProntoPagoField>
					<estaEnZonaFrancaField>0</estaEnZonaFrancaField>
					<razonSocialField>RazonSocial</razonSocialField>
					<diasPlazoPagoField>60</diasPlazoPagoField>
					<usaDebitoAutomaticoField>0</usaDebitoAutomaticoField>
					<esFacturableField>1</esFacturableField>
					<iDRegionComercialField>RegionCom123</iDRegionComercialField>
					<iDTipoRegionComercialField>TipoRC123</iDTipoRegionComercialField>
					<estadoField>1</estadoField>
					<resolucionDGEField>REsDGEF</resolucionDGEField>
					<tanquesField>
						<Tanque>
							<iDTanqueField>string</iDTanqueField>
							<capacidadField>100</capacidadField>
							<iDUnidadCapacidadField>UnidadKG</iDUnidadCapacidadField>
							<iDArticuloField>Articulo123</iDArticuloField>
							<matriculaField>Matricula123</matriculaField>
						</Tanque>
					</tanquesField>
					<impuestosBocaField>
						<ImpuestoBoca>
							<iDImpuestoField>ID123</iDImpuestoField>
							<fechaSujetoDesdeField>2020-01-01</fechaSujetoDesdeField>
							<fechaSujetoHastaField>2030-01-01</fechaSujetoHastaField>
							<fechaExentoHastaField>2022-08-01</fechaExentoHastaField>
							<baseCalculoField>10</baseCalculoField>
							<porcentajeImpuestoField>21</porcentajeImpuestoField>
							<importeMinimoField>100</importeMinimoField>
							<porcentajeExentoField>10</porcentajeExentoField>
							<iDUnidadImporteMinimoField>Unidad123</iDUnidadImporteMinimoField>
						</ImpuestoBoca>
					</impuestosBocaField>
					<cuentaCorrienteField>
						<CuentaCorriente>
							<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
							<ejercicioField>2022</ejercicioField>
							<posicionField>150</posicionField>
							<iDBocaField>Boca123 </iDBocaField>
							<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
							<serieField>Serie1</serieField>
							<letraField>LetraA</letraField>
							<numeroField>999</numeroField>
							<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
							<fechaVencimientoField>2022-09-01</fechaVencimientoField>
							<importeField>9879</importeField>
							<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
							<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
							<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
							<importeProntoPagoField>1500</importeProntoPagoField>
							<idMonedaImporteField>ARS</idMonedaImporteField>
						</CuentaCorriente>
					</cuentaCorrienteField>
					<preciosEspecialesField>
						<Precio>
							<iDArticuloField>Articulo123</iDArticuloField>
							<iDBocaField>Boca123</iDBocaField>
							<precio1Field>520</precio1Field>
							<iDUnidadPrecioNetoField>Kg</iDUnidadPrecioNetoField>
							<vigenciaDesdeField>2022-01-01</vigenciaDesdeField>
						</Precio>
					</preciosEspecialesField>
				</Boca>
			</bocasField>
			<logTransporteField>
				<LogTransporte>
					<iDPedidoField>Pedido123</iDPedidoField>
					<iDViajeField>Viaje123</iDViajeField>
					<operacionField>Entrega</operacionField>
				</LogTransporte>
			</logTransporteField>
		</novedadesPlanificacionField>
	</respuestaField>
</FechaActual>";

        string pedidoListaMock = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<PedidoLista>
	<pedidosField>
		<Pedido>
			<iDPedidoField>idPedid123</iDPedidoField>
			<iDBocaField>iDBoca123</iDBocaField>
			<iDPlantaField>iDPlanta23</iDPlantaField>
			<fechaEntregaPreferenteField>2022-09-01</fechaEntregaPreferenteField>
			<horaDesdeField>09</horaDesdeField>
			<horaHastaField>18</horaHastaField>
			<observacionesField>Observaciones</observacionesField>
			<importeCobroAnticipadoField>1000</importeCobroAnticipadoField>
			<tipoDeCargaField>Gas</tipoDeCargaField>
			<iDTipoPedidoField>idTipoPedido123</iDTipoPedidoField>
			<esFacturableField>1</esFacturableField>
			<condicionDePagoField>Contado</condicionDePagoField>
			<codigoExpressField>CodigoExpress123</codigoExpressField>
			<esPlanificadoField>1</esPlanificadoField>
			<detallePedidosField>
				<DetallePedido>
					<cantidadField>10</cantidadField>
					<iDArticuloField>Articulo123</iDArticuloField>
					<importeField>10000</importeField>
				</DetallePedido>
			</detallePedidosField>
		</Pedido>
	</pedidosField>
	<respuestaField>
		<codigoField>1234</codigoField>
		<descripcionField>Descrpicion</descripcionField>
		<novedadesPlanificacionField>
			<pedidosField>
				<Pedido>
					<iDPedidoField>ID123</iDPedidoField>
					<iDBocaField>IDBoca123</iDBocaField>
					<iDPlantaField>IDPlanta</iDPlantaField>
					<fechaEntregaPreferenteField>2022-09-01</fechaEntregaPreferenteField>
					<horaDesdeField>10:30</horaDesdeField>
					<horaHastaField>14:00</horaHastaField>
					<observacionesField>Observacion</observacionesField>
					<importeCobroAnticipadoField>9999</importeCobroAnticipadoField>
					<tipoDeCargaField>CargaA</tipoDeCargaField>
					<iDTipoPedidoField>PedidoTipo1</iDTipoPedidoField>
					<esFacturableField>1</esFacturableField>
					<condicionDePagoField>Contado</condicionDePagoField>
					<codigoExpressField>NO</codigoExpressField>
					<esPlanificadoField>1</esPlanificadoField>
					<detallePedidosField>
						<DetallePedido>
							<cantidadField>5</cantidadField>
							<iDArticuloField>ART001</iDArticuloField>
							<importeField>99999</importeField>
						</DetallePedido>
					</detallePedidosField>
				</Pedido>
			</pedidosField>
			<titularesField>
				<Titular>
					<iDTitularField>IDTitular123</iDTitularField>
					<direccionField>direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<titular1Field>titular1</titular1Field>
					<codigoPostalField>CP1234</codigoPostalField>
					<iDFiscalField>iDFiscal123</iDFiscalField>
					<iDTipoFiscalField>Tipo123</iDTipoFiscalField>
					<iDCategoriaFiscalField>Categoria123</iDCategoriaFiscalField>
					<iDRegionField>Region123</iDRegionField>
					<iDTipoRegionField>TipoReg123</iDTipoRegionField>
				</Titular>
			</titularesField>
			<bocasField>
				<Boca>
					<iDBocaField>Boca123</iDBocaField>
					<iDPlantaField>Planta123</iDPlantaField>
					<direccionField>Direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<telefonoField>011-1234-1234</telefonoField>
					<iDTitularField>Titular123</iDTitularField>
					<codigoPostalField>CP1234</codigoPostalField>
					<instruccionesDeAccesoField>Acceder por 123</instruccionesDeAccesoField>
					<iDZonaField>Zona123</iDZonaField>
					<usaSegundoVencimientoField>0</usaSegundoVencimientoField>
					<usaProntoPagoField>0</usaProntoPagoField>
					<iDProntoPagoField>NO</iDProntoPagoField>
					<estaEnZonaFrancaField>0</estaEnZonaFrancaField>
					<razonSocialField>RazonSocial</razonSocialField>
					<diasPlazoPagoField>60</diasPlazoPagoField>
					<usaDebitoAutomaticoField>0</usaDebitoAutomaticoField>
					<esFacturableField>1</esFacturableField>
					<iDRegionComercialField>RegionCom123</iDRegionComercialField>
					<iDTipoRegionComercialField>TipoRC123</iDTipoRegionComercialField>
					<estadoField>1</estadoField>
					<resolucionDGEField>REsDGEF</resolucionDGEField>
					<tanquesField>
						<Tanque>
							<iDTanqueField>string</iDTanqueField>
							<capacidadField>100</capacidadField>
							<iDUnidadCapacidadField>UnidadKG</iDUnidadCapacidadField>
							<iDArticuloField>Articulo123</iDArticuloField>
							<matriculaField>Matricula123</matriculaField>
						</Tanque>
					</tanquesField>
					<impuestosBocaField>
						<ImpuestoBoca>
							<iDImpuestoField>ID123</iDImpuestoField>
							<fechaSujetoDesdeField>2020-01-01</fechaSujetoDesdeField>
							<fechaSujetoHastaField>2030-01-01</fechaSujetoHastaField>
							<fechaExentoHastaField>2022-08-01</fechaExentoHastaField>
							<baseCalculoField>10</baseCalculoField>
							<porcentajeImpuestoField>21</porcentajeImpuestoField>
							<importeMinimoField>100</importeMinimoField>
							<porcentajeExentoField>10</porcentajeExentoField>
							<iDUnidadImporteMinimoField>Unidad123</iDUnidadImporteMinimoField>
						</ImpuestoBoca>
					</impuestosBocaField>
					<cuentaCorrienteField>
						<CuentaCorriente>
							<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
							<ejercicioField>2022</ejercicioField>
							<posicionField>150</posicionField>
							<iDBocaField>Boca123 </iDBocaField>
							<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
							<serieField>Serie1</serieField>
							<letraField>LetraA</letraField>
							<numeroField>999</numeroField>
							<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
							<fechaVencimientoField>2022-09-01</fechaVencimientoField>
							<importeField>9879</importeField>
							<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
							<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
							<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
							<importeProntoPagoField>1500</importeProntoPagoField>
							<idMonedaImporteField>ARS</idMonedaImporteField>
						</CuentaCorriente>
					</cuentaCorrienteField>
					<preciosEspecialesField>
						<Precio>
							<iDArticuloField>Articulo123</iDArticuloField>
							<iDBocaField>Boca123</iDBocaField>
							<precio1Field>520</precio1Field>
							<iDUnidadPrecioNetoField>Kg</iDUnidadPrecioNetoField>
							<vigenciaDesdeField>2022-01-01</vigenciaDesdeField>
						</Precio>
					</preciosEspecialesField>
				</Boca>
			</bocasField>
			<logTransporteField>
				<LogTransporte>
					<iDPedidoField>Pedido123</iDPedidoField>
					<iDViajeField>Viaje123</iDViajeField>
					<operacionField>Entrega</operacionField>
				</LogTransporte>
			</logTransporteField>
		</novedadesPlanificacionField>
	</respuestaField>
</PedidoLista>";

        string viajeListaMock = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<ViajeLista>
	<viajesField>
		<ViajeDisponible>
			<iDViajeField>iDViaje123</iDViajeField>
			<fechaPlanificacionField>2022-09-01</fechaPlanificacionField>
		</ViajeDisponible>
	</viajesField>
	<respuestaField>
		<codigoField>1234</codigoField>
		<descripcionField>Descrpicion</descripcionField>
		<novedadesPlanificacionField>
			<pedidosField>
				<Pedido>
					<iDPedidoField>ID123</iDPedidoField>
					<iDBocaField>IDBoca123</iDBocaField>
					<iDPlantaField>IDPlanta</iDPlantaField>
					<fechaEntregaPreferenteField>2022-09-01</fechaEntregaPreferenteField>
					<horaDesdeField>10:30</horaDesdeField>
					<horaHastaField>14:00</horaHastaField>
					<observacionesField>Observacion</observacionesField>
					<importeCobroAnticipadoField>9999</importeCobroAnticipadoField>
					<tipoDeCargaField>CargaA</tipoDeCargaField>
					<iDTipoPedidoField>PedidoTipo1</iDTipoPedidoField>
					<esFacturableField>1</esFacturableField>
					<condicionDePagoField>Contado</condicionDePagoField>
					<codigoExpressField>NO</codigoExpressField>
					<esPlanificadoField>1</esPlanificadoField>
					<detallePedidosField>
						<DetallePedido>
							<cantidadField>5</cantidadField>
							<iDArticuloField>ART001</iDArticuloField>
							<importeField>99999</importeField>
						</DetallePedido>
					</detallePedidosField>
				</Pedido>
			</pedidosField>
			<titularesField>
				<Titular>
					<iDTitularField>IDTitular123</iDTitularField>
					<direccionField>direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<titular1Field>titular1</titular1Field>
					<codigoPostalField>CP1234</codigoPostalField>
					<iDFiscalField>iDFiscal123</iDFiscalField>
					<iDTipoFiscalField>Tipo123</iDTipoFiscalField>
					<iDCategoriaFiscalField>Categoria123</iDCategoriaFiscalField>
					<iDRegionField>Region123</iDRegionField>
					<iDTipoRegionField>TipoReg123</iDTipoRegionField>
				</Titular>
			</titularesField>
			<bocasField>
				<Boca>
					<iDBocaField>Boca123</iDBocaField>
					<iDPlantaField>Planta123</iDPlantaField>
					<direccionField>Direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<telefonoField>011-1234-1234</telefonoField>
					<iDTitularField>Titular123</iDTitularField>
					<codigoPostalField>CP1234</codigoPostalField>
					<instruccionesDeAccesoField>Acceder por 123</instruccionesDeAccesoField>
					<iDZonaField>Zona123</iDZonaField>
					<usaSegundoVencimientoField>0</usaSegundoVencimientoField>
					<usaProntoPagoField>0</usaProntoPagoField>
					<iDProntoPagoField>NO</iDProntoPagoField>
					<estaEnZonaFrancaField>0</estaEnZonaFrancaField>
					<razonSocialField>RazonSocial</razonSocialField>
					<diasPlazoPagoField>60</diasPlazoPagoField>
					<usaDebitoAutomaticoField>0</usaDebitoAutomaticoField>
					<esFacturableField>1</esFacturableField>
					<iDRegionComercialField>RegionCom123</iDRegionComercialField>
					<iDTipoRegionComercialField>TipoRC123</iDTipoRegionComercialField>
					<estadoField>1</estadoField>
					<resolucionDGEField>REsDGEF</resolucionDGEField>
					<tanquesField>
						<Tanque>
							<iDTanqueField>string</iDTanqueField>
							<capacidadField>100</capacidadField>
							<iDUnidadCapacidadField>UnidadKG</iDUnidadCapacidadField>
							<iDArticuloField>Articulo123</iDArticuloField>
							<matriculaField>Matricula123</matriculaField>
						</Tanque>
					</tanquesField>
					<impuestosBocaField>
						<ImpuestoBoca>
							<iDImpuestoField>ID123</iDImpuestoField>
							<fechaSujetoDesdeField>2020-01-01</fechaSujetoDesdeField>
							<fechaSujetoHastaField>2030-01-01</fechaSujetoHastaField>
							<fechaExentoHastaField>2022-08-01</fechaExentoHastaField>
							<baseCalculoField>10</baseCalculoField>
							<porcentajeImpuestoField>21</porcentajeImpuestoField>
							<importeMinimoField>100</importeMinimoField>
							<porcentajeExentoField>10</porcentajeExentoField>
							<iDUnidadImporteMinimoField>Unidad123</iDUnidadImporteMinimoField>
						</ImpuestoBoca>
					</impuestosBocaField>
					<cuentaCorrienteField>
						<CuentaCorriente>
							<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
							<ejercicioField>2022</ejercicioField>
							<posicionField>150</posicionField>
							<iDBocaField>Boca123 </iDBocaField>
							<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
							<serieField>Serie1</serieField>
							<letraField>LetraA</letraField>
							<numeroField>999</numeroField>
							<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
							<fechaVencimientoField>2022-09-01</fechaVencimientoField>
							<importeField>9879</importeField>
							<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
							<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
							<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
							<importeProntoPagoField>1500</importeProntoPagoField>
							<idMonedaImporteField>ARS</idMonedaImporteField>
						</CuentaCorriente>
					</cuentaCorrienteField>
					<preciosEspecialesField>
						<Precio>
							<iDArticuloField>Articulo123</iDArticuloField>
							<iDBocaField>Boca123</iDBocaField>
							<precio1Field>520</precio1Field>
							<iDUnidadPrecioNetoField>Kg</iDUnidadPrecioNetoField>
							<vigenciaDesdeField>2022-01-01</vigenciaDesdeField>
						</Precio>
					</preciosEspecialesField>
				</Boca>
			</bocasField>
			<logTransporteField>
				<LogTransporte>
					<iDPedidoField>Pedido123</iDPedidoField>
					<iDViajeField>Viaje123</iDViajeField>
					<operacionField>Entrega</operacionField>
				</LogTransporte>
			</logTransporteField>
		</novedadesPlanificacionField>
	</respuestaField>
</ViajeLista>";

		string viajeSeleccionadoMock = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<ViajeSeleccionado>
	<iDViajeField>idViaje123</iDViajeField>
    <tipoDeViajeField>Entrega</tipoDeViajeField>
    <iDPatenteField>ABL123</iDPatenteField>
	<iDPlantaField>idPlanta123</iDPlantaField>
	<iDChoferField>idChofer123</iDChoferField>
	<empresaTransportistaField>empresa123</empresaTransportistaField>
	<pesadaInicialField>1000</pesadaInicialField>
	<stocksField>
		<Stock>
			<iDArticuloField>Articulo123</iDArticuloField>
			<cantidadField>10</cantidadField>
		</Stock>
	</stocksField>
	<numeradoresField>
		<Numerador>
			<tipoDocumentoField>Factura</tipoDocumentoField>
			<serieField>003</serieField>
			<numeroDesdeField>2214</numeroDesdeField>
			<numeroHastaField>5000</numeroHastaField>
		</Numerador>
	</numeradoresField>
	<zonasField>
		<Zona>
			<iDZonaField>idZona123</iDZonaField>
			<zona1Field>ZonaAlpha</zona1Field>
		</Zona>
	</zonasField>
	<respuestaField>
		<codigoField>1234</codigoField>
		<descripcionField>Descrpicion</descripcionField>
		<novedadesPlanificacionField>
			<pedidosField>
				<Pedido>
					<iDPedidoField>ID123</iDPedidoField>
					<iDBocaField>IDBoca123</iDBocaField>
					<iDPlantaField>IDPlanta</iDPlantaField>
					<fechaEntregaPreferenteField>2022-09-01</fechaEntregaPreferenteField>
					<horaDesdeField>10:30</horaDesdeField>
					<horaHastaField>14:00</horaHastaField>
					<observacionesField>Observacion</observacionesField>
					<importeCobroAnticipadoField>9999</importeCobroAnticipadoField>
					<tipoDeCargaField>CargaA</tipoDeCargaField>
					<iDTipoPedidoField>PedidoTipo1</iDTipoPedidoField>
					<esFacturableField>1</esFacturableField>
					<condicionDePagoField>Contado</condicionDePagoField>
					<codigoExpressField>NO</codigoExpressField>
					<esPlanificadoField>1</esPlanificadoField>
					<detallePedidosField>
						<DetallePedido>
							<cantidadField>5</cantidadField>
							<iDArticuloField>ART001</iDArticuloField>
							<importeField>99999</importeField>
						</DetallePedido>
					</detallePedidosField>
				</Pedido>
			</pedidosField>
			<titularesField>
				<Titular>
					<iDTitularField>IDTitular123</iDTitularField>
					<direccionField>direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<titular1Field>titular1</titular1Field>
					<codigoPostalField>CP1234</codigoPostalField>
					<iDFiscalField>iDFiscal123</iDFiscalField>
					<iDTipoFiscalField>Tipo123</iDTipoFiscalField>
					<iDCategoriaFiscalField>Categoria123</iDCategoriaFiscalField>
					<iDRegionField>Region123</iDRegionField>
					<iDTipoRegionField>TipoReg123</iDTipoRegionField>
				</Titular>
			</titularesField>
			<bocasField>
				<Boca>
					<iDBocaField>Boca123</iDBocaField>
					<iDPlantaField>Planta123</iDPlantaField>
					<direccionField>Direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<telefonoField>011-1234-1234</telefonoField>
					<iDTitularField>Titular123</iDTitularField>
					<codigoPostalField>CP1234</codigoPostalField>
					<instruccionesDeAccesoField>Acceder por 123</instruccionesDeAccesoField>
					<iDZonaField>Zona123</iDZonaField>
					<usaSegundoVencimientoField>0</usaSegundoVencimientoField>
					<usaProntoPagoField>0</usaProntoPagoField>
					<iDProntoPagoField>NO</iDProntoPagoField>
					<estaEnZonaFrancaField>0</estaEnZonaFrancaField>
					<razonSocialField>RazonSocial</razonSocialField>
					<diasPlazoPagoField>60</diasPlazoPagoField>
					<usaDebitoAutomaticoField>0</usaDebitoAutomaticoField>
					<esFacturableField>1</esFacturableField>
					<iDRegionComercialField>RegionCom123</iDRegionComercialField>
					<iDTipoRegionComercialField>TipoRC123</iDTipoRegionComercialField>
					<estadoField>1</estadoField>
					<resolucionDGEField>REsDGEF</resolucionDGEField>
					<tanquesField>
						<Tanque>
							<iDTanqueField>string</iDTanqueField>
							<capacidadField>100</capacidadField>
							<iDUnidadCapacidadField>UnidadKG</iDUnidadCapacidadField>
							<iDArticuloField>Articulo123</iDArticuloField>
							<matriculaField>Matricula123</matriculaField>
						</Tanque>
					</tanquesField>
					<impuestosBocaField>
						<ImpuestoBoca>
							<iDImpuestoField>ID123</iDImpuestoField>
							<fechaSujetoDesdeField>2020-01-01</fechaSujetoDesdeField>
							<fechaSujetoHastaField>2030-01-01</fechaSujetoHastaField>
							<fechaExentoHastaField>2022-08-01</fechaExentoHastaField>
							<baseCalculoField>10</baseCalculoField>
							<porcentajeImpuestoField>21</porcentajeImpuestoField>
							<importeMinimoField>100</importeMinimoField>
							<porcentajeExentoField>10</porcentajeExentoField>
							<iDUnidadImporteMinimoField>Unidad123</iDUnidadImporteMinimoField>
						</ImpuestoBoca>
					</impuestosBocaField>
					<cuentaCorrienteField>
						<CuentaCorriente>
							<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
							<ejercicioField>2022</ejercicioField>
							<posicionField>150</posicionField>
							<iDBocaField>Boca123 </iDBocaField>
							<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
							<serieField>Serie1</serieField>
							<letraField>LetraA</letraField>
							<numeroField>999</numeroField>
							<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
							<fechaVencimientoField>2022-09-01</fechaVencimientoField>
							<importeField>9879</importeField>
							<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
							<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
							<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
							<importeProntoPagoField>1500</importeProntoPagoField>
							<idMonedaImporteField>ARS</idMonedaImporteField>
						</CuentaCorriente>
					</cuentaCorrienteField>
					<preciosEspecialesField>
						<Precio>
							<iDArticuloField>Articulo123</iDArticuloField>
							<iDBocaField>Boca123</iDBocaField>
							<precio1Field>520</precio1Field>
							<iDUnidadPrecioNetoField>Kg</iDUnidadPrecioNetoField>
							<vigenciaDesdeField>2022-01-01</vigenciaDesdeField>
						</Precio>
					</preciosEspecialesField>
				</Boca>
			</bocasField>
			<logTransporteField>
				<LogTransporte>
					<iDPedidoField>Pedido123</iDPedidoField>
					<iDViajeField>Viaje123</iDViajeField>
					<operacionField>Entrega</operacionField>
				</LogTransporte>
			</logTransporteField>
		</novedadesPlanificacionField>
	</respuestaField>
</ViajeSeleccionado>";

		string aperturaMock = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<Apertura>
	<iDTransporteField>iDTransporte123</iDTransporteField>
	<tipoDeViajeField>Entrega</tipoDeViajeField>
	<iDPatenteField>PAT123</iDPatenteField>
	<iDPlantaField>idPlanta123</iDPlantaField>
	<iDChoferField>idChofer123</iDChoferField>
	<empresaTransportistaField>Empresa123</empresaTransportistaField>
	<pesadaInicialField>1000</pesadaInicialField>
	<densidadField>10</densidadField>
	<stocksField>
		<Stock>
			<iDArticuloField>Articulo123</iDArticuloField>
			<cantidadField>10</cantidadField>
		</Stock>
	</stocksField>
	<numeradoresAutomaticosField>
		<NumeradorAutomatico>
			<tipoDocumentoField>Factura</tipoDocumentoField>
			<serieField>SerieA</serieField>
			<ultimoNumeroUsadoField>5000</ultimoNumeroUsadoField>
			<numeroCAIField>CAI123456</numeroCAIField>
			<fechaVencimientoCAIField>2022-09-01</fechaVencimientoCAIField>
			<fechaInicioActividadesField>1920-01-01</fechaInicioActividadesField>
		</NumeradorAutomatico>
	</numeradoresAutomaticosField>
	<numeradoresManualesField>
		<NumeradorManual>
			<tipoDocumentoField>Remitos</tipoDocumentoField>
			<serieField>002</serieField>
			<numeroDisponibleField>1234</numeroDisponibleField>
			<iDBocaField>idBoca123</iDBocaField>
		</NumeradorManual>
	</numeradoresManualesField>
	<pedidosField>
		<Pedido>
			<iDPedidoField>ID123</iDPedidoField>
			<iDBocaField>IDBoca123</iDBocaField>
			<iDPlantaField>IDPlanta</iDPlantaField>
			<fechaEntregaPreferenteField>2022-09-01</fechaEntregaPreferenteField>
			<horaDesdeField>10:30</horaDesdeField>
			<horaHastaField>14:00</horaHastaField>
			<observacionesField>Observacion</observacionesField>
			<importeCobroAnticipadoField>9999</importeCobroAnticipadoField>
			<tipoDeCargaField>CargaA</tipoDeCargaField>
			<iDTipoPedidoField>PedidoTipo1</iDTipoPedidoField>
			<esFacturableField>1</esFacturableField>
			<condicionDePagoField>Contado</condicionDePagoField>
			<codigoExpressField>NO</codigoExpressField>
			<esPlanificadoField>1</esPlanificadoField>
			<detallePedidosField>
				<DetallePedido>
					<cantidadField>5</cantidadField>
					<iDArticuloField>ART001</iDArticuloField>
					<importeField>99999</importeField>
				</DetallePedido>
			</detallePedidosField>
		</Pedido>
	</pedidosField>
	<titularesField>
		<Titular>
			<iDTitularField>IDTitular123</iDTitularField>
			<direccionField>direccion123</direccionField>
			<poblacionField>poblacion</poblacionField>
			<titular1Field>titular1</titular1Field>
			<codigoPostalField>CP1234</codigoPostalField>
			<iDFiscalField>iDFiscal123</iDFiscalField>
			<iDTipoFiscalField>Tipo123</iDTipoFiscalField>
			<iDCategoriaFiscalField>Categoria123</iDCategoriaFiscalField>
			<iDRegionField>Region123</iDRegionField>
			<iDTipoRegionField>TipoReg123</iDTipoRegionField>
		</Titular>
	</titularesField>
	<bocasField>
		<Boca>
			<iDBocaField>Boca123</iDBocaField>
			<iDPlantaField>Planta123</iDPlantaField>
			<direccionField>Direccion123</direccionField>
			<poblacionField>poblacion</poblacionField>
			<telefonoField>011-1234-1234</telefonoField>
			<iDTitularField>Titular123</iDTitularField>
			<codigoPostalField>CP1234</codigoPostalField>
			<instruccionesDeAccesoField>Acceder por 123</instruccionesDeAccesoField>
			<iDZonaField>Zona123</iDZonaField>
			<usaSegundoVencimientoField>0</usaSegundoVencimientoField>
			<usaProntoPagoField>0</usaProntoPagoField>
			<iDProntoPagoField>NO</iDProntoPagoField>
			<estaEnZonaFrancaField>0</estaEnZonaFrancaField>
			<razonSocialField>RazonSocial</razonSocialField>
			<diasPlazoPagoField>60</diasPlazoPagoField>
			<usaDebitoAutomaticoField>0</usaDebitoAutomaticoField>
			<esFacturableField>1</esFacturableField>
			<iDRegionComercialField>RegionCom123</iDRegionComercialField>
			<iDTipoRegionComercialField>TipoRC123</iDTipoRegionComercialField>
			<estadoField>1</estadoField>
			<resolucionDGEField>REsDGEF</resolucionDGEField>
			<tanquesField>
				<Tanque>
					<iDTanqueField>string</iDTanqueField>
					<capacidadField>100</capacidadField>
					<iDUnidadCapacidadField>UnidadKG</iDUnidadCapacidadField>
					<iDArticuloField>Articulo123</iDArticuloField>
					<matriculaField>Matricula123</matriculaField>
				</Tanque>
			</tanquesField>
			<impuestosBocaField>
				<ImpuestoBoca>
					<iDImpuestoField>ID123</iDImpuestoField>
					<fechaSujetoDesdeField>2020-01-01</fechaSujetoDesdeField>
					<fechaSujetoHastaField>2030-01-01</fechaSujetoHastaField>
					<fechaExentoHastaField>2022-08-01</fechaExentoHastaField>
					<baseCalculoField>10</baseCalculoField>
					<porcentajeImpuestoField>21</porcentajeImpuestoField>
					<importeMinimoField>100</importeMinimoField>
					<porcentajeExentoField>10</porcentajeExentoField>
					<iDUnidadImporteMinimoField>Unidad123</iDUnidadImporteMinimoField>
				</ImpuestoBoca>
			</impuestosBocaField>
			<cuentaCorrienteField>
				<CuentaCorriente>
					<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
					<ejercicioField>2022</ejercicioField>
					<posicionField>150</posicionField>
					<iDBocaField>Boca123 </iDBocaField>
					<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
					<serieField>Serie1</serieField>
					<letraField>LetraA</letraField>
					<numeroField>999</numeroField>
					<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
					<fechaVencimientoField>2022-09-01</fechaVencimientoField>
					<importeField>9879</importeField>
					<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
					<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
					<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
					<importeProntoPagoField>1500</importeProntoPagoField>
					<idMonedaImporteField>ARS</idMonedaImporteField>
				</CuentaCorriente>
			</cuentaCorrienteField>
			<preciosEspecialesField>
				<Precio>
					<iDArticuloField>Articulo123</iDArticuloField>
					<iDBocaField>Boca123</iDBocaField>
					<precio1Field>520</precio1Field>
					<iDUnidadPrecioNetoField>Kg</iDUnidadPrecioNetoField>
					<vigenciaDesdeField>2022-01-01</vigenciaDesdeField>
				</Precio>
			</preciosEspecialesField>
		</Boca>	
	</bocasField>
	<cuentasCorrientesField>
		<CuentaCorriente>
			<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
			<ejercicioField>2022</ejercicioField>
			<posicionField>150</posicionField>
			<iDBocaField>Boca123 </iDBocaField>
			<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
			<serieField>Serie1</serieField>
			<letraField>LetraA</letraField>
			<numeroField>999</numeroField>
			<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
			<fechaVencimientoField>2022-09-01</fechaVencimientoField>
			<importeField>9879</importeField>
			<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
			<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
			<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
			<importeProntoPagoField>1500</importeProntoPagoField>
			<idMonedaImporteField>ARS</idMonedaImporteField>
		</CuentaCorriente>
	</cuentasCorrientesField>
	<novedadesField>
		<patentesField>
			<Patente>
				<iDPatenteField>ABV123</iDPatenteField>
				<tipoVehiculoField>CamionCarga</tipoVehiculoField>
				<tieneMasicoField>1</tieneMasicoField>
				<empresaTransportistaField>Empresa123</empresaTransportistaField>
				<capacidadDeCargaField>1000</capacidadDeCargaField>
			</Patente>
		</patentesField>
		<usuariosField>
			<Usuario>
				<iDUsuarioField>Usuario123</iDUsuarioField>
				<claveField>Clave123</claveField>
				<nombreField>Juan Perez</nombreField>
			</Usuario>
		</usuariosField>
		<titularesField>
			<Titular>
				<iDTitularField>IDTitular123</iDTitularField>
				<direccionField>direccion123</direccionField>
				<poblacionField>poblacion</poblacionField>
				<titular1Field>titular1</titular1Field>
				<codigoPostalField>CP1234</codigoPostalField>
				<iDFiscalField>iDFiscal123</iDFiscalField>
				<iDTipoFiscalField>Tipo123</iDTipoFiscalField>
				<iDCategoriaFiscalField>Categoria123</iDCategoriaFiscalField>
				<iDRegionField>Region123</iDRegionField>
				<iDTipoRegionField>TipoReg123</iDTipoRegionField>
			</Titular>
		</titularesField>
		<bocasField>
			<Boca>
				<iDBocaField>Boca123</iDBocaField>
				<iDPlantaField>Planta123</iDPlantaField>
				<direccionField>Direccion123</direccionField>
				<poblacionField>poblacion</poblacionField>
				<telefonoField>011-1234-1234</telefonoField>
				<iDTitularField>Titular123</iDTitularField>
				<codigoPostalField>CP1234</codigoPostalField>
				<instruccionesDeAccesoField>Acceder por 123</instruccionesDeAccesoField>
				<iDZonaField>Zona123</iDZonaField>
				<usaSegundoVencimientoField>0</usaSegundoVencimientoField>
				<usaProntoPagoField>0</usaProntoPagoField>
				<iDProntoPagoField>NO</iDProntoPagoField>
				<estaEnZonaFrancaField>0</estaEnZonaFrancaField>
				<razonSocialField>RazonSocial</razonSocialField>
				<diasPlazoPagoField>60</diasPlazoPagoField>
				<usaDebitoAutomaticoField>0</usaDebitoAutomaticoField>
				<esFacturableField>1</esFacturableField>
				<iDRegionComercialField>RegionCom123</iDRegionComercialField>
				<iDTipoRegionComercialField>TipoRC123</iDTipoRegionComercialField>
				<estadoField>1</estadoField>
				<resolucionDGEField>REsDGEF</resolucionDGEField>
				<tanquesField>
					<Tanque>
						<iDTanqueField>string</iDTanqueField>
						<capacidadField>100</capacidadField>
						<iDUnidadCapacidadField>UnidadKG</iDUnidadCapacidadField>
						<iDArticuloField>Articulo123</iDArticuloField>
						<matriculaField>Matricula123</matriculaField>
					</Tanque>
				</tanquesField>
				<impuestosBocaField>
					<ImpuestoBoca>
						<iDImpuestoField>ID123</iDImpuestoField>
						<fechaSujetoDesdeField>2020-01-01</fechaSujetoDesdeField>
						<fechaSujetoHastaField>2030-01-01</fechaSujetoHastaField>
						<fechaExentoHastaField>2022-08-01</fechaExentoHastaField>
						<baseCalculoField>10</baseCalculoField>
						<porcentajeImpuestoField>21</porcentajeImpuestoField>
						<importeMinimoField>100</importeMinimoField>
						<porcentajeExentoField>10</porcentajeExentoField>
						<iDUnidadImporteMinimoField>Unidad123</iDUnidadImporteMinimoField>
					</ImpuestoBoca>
				</impuestosBocaField>
				<cuentaCorrienteField>
					<CuentaCorriente>
						<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
						<ejercicioField>2022</ejercicioField>
						<posicionField>150</posicionField>
						<iDBocaField>Boca123 </iDBocaField>
						<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
						<serieField>Serie1</serieField>
						<letraField>LetraA</letraField>
						<numeroField>999</numeroField>
						<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
						<fechaVencimientoField>2022-09-01</fechaVencimientoField>
						<importeField>9879</importeField>
						<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
						<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
						<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
						<importeProntoPagoField>1500</importeProntoPagoField>
						<idMonedaImporteField>ARS</idMonedaImporteField>
					</CuentaCorriente>
				</cuentaCorrienteField>
				<preciosEspecialesField>
					<Precio>
						<iDArticuloField>Articulo123</iDArticuloField>
						<iDBocaField>Boca123</iDBocaField>
						<precio1Field>520</precio1Field>
						<iDUnidadPrecioNetoField>Kg</iDUnidadPrecioNetoField>
						<vigenciaDesdeField>2022-01-01</vigenciaDesdeField>
					</Precio>
				</preciosEspecialesField>
			</Boca>
		</bocasField>
		<feriadosField>
			<Feriado>
				<fechaField>2022-10-12</fechaField>
			</Feriado>
		</feriadosField>
		<bancosField>
			<Banco>
				<iDBancoField>BancoID123</iDBancoField>
				<banco1Field>Banco123</banco1Field>
			</Banco>
		</bancosField>
		<sucursalesField>
			<Sucursal>
				<iDSucursalField>SucursalID123</iDSucursalField>
				<sucursal1Field>Sucursal123</sucursal1Field>
				<iDBancoField>BancoID123</iDBancoField>
			</Sucursal>
		</sucursalesField>
	</novedadesField>
	<respuestaField>
		<codigoField>1234</codigoField>
		<descripcionField>Descrpicion</descripcionField>
		<novedadesPlanificacionField>
			<pedidosField>
				<Pedido>
					<iDPedidoField>ID123</iDPedidoField>
					<iDBocaField>IDBoca123</iDBocaField>
					<iDPlantaField>IDPlanta</iDPlantaField>
					<fechaEntregaPreferenteField>2022-09-01</fechaEntregaPreferenteField>
					<horaDesdeField>10:30</horaDesdeField>
					<horaHastaField>14:00</horaHastaField>
					<observacionesField>Observacion</observacionesField>
					<importeCobroAnticipadoField>9999</importeCobroAnticipadoField>
					<tipoDeCargaField>CargaA</tipoDeCargaField>
					<iDTipoPedidoField>PedidoTipo1</iDTipoPedidoField>
					<esFacturableField>1</esFacturableField>
					<condicionDePagoField>Contado</condicionDePagoField>
					<codigoExpressField>NO</codigoExpressField>
					<esPlanificadoField>1</esPlanificadoField>
					<detallePedidosField>
						<DetallePedido>
							<cantidadField>5</cantidadField>
							<iDArticuloField>ART001</iDArticuloField>
							<importeField>99999</importeField>
						</DetallePedido>
					</detallePedidosField>
				</Pedido>
			</pedidosField>
			<titularesField>
				<Titular>
					<iDTitularField>IDTitular123</iDTitularField>
					<direccionField>direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<titular1Field>titular1</titular1Field>
					<codigoPostalField>CP1234</codigoPostalField>
					<iDFiscalField>iDFiscal123</iDFiscalField>
					<iDTipoFiscalField>Tipo123</iDTipoFiscalField>
					<iDCategoriaFiscalField>Categoria123</iDCategoriaFiscalField>
					<iDRegionField>Region123</iDRegionField>
					<iDTipoRegionField>TipoReg123</iDTipoRegionField>
				</Titular>
			</titularesField>
			<bocasField>
				<Boca>
					<iDBocaField>Boca123</iDBocaField>
					<iDPlantaField>Planta123</iDPlantaField>
					<direccionField>Direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<telefonoField>011-1234-1234</telefonoField>
					<iDTitularField>Titular123</iDTitularField>
					<codigoPostalField>CP1234</codigoPostalField>
					<instruccionesDeAccesoField>Acceder por 123</instruccionesDeAccesoField>
					<iDZonaField>Zona123</iDZonaField>
					<usaSegundoVencimientoField>0</usaSegundoVencimientoField>
					<usaProntoPagoField>0</usaProntoPagoField>
					<iDProntoPagoField>NO</iDProntoPagoField>
					<estaEnZonaFrancaField>0</estaEnZonaFrancaField>
					<razonSocialField>RazonSocial</razonSocialField>
					<diasPlazoPagoField>60</diasPlazoPagoField>
					<usaDebitoAutomaticoField>0</usaDebitoAutomaticoField>
					<esFacturableField>1</esFacturableField>
					<iDRegionComercialField>RegionCom123</iDRegionComercialField>
					<iDTipoRegionComercialField>TipoRC123</iDTipoRegionComercialField>
					<estadoField>1</estadoField>
					<resolucionDGEField>REsDGEF</resolucionDGEField>
					<tanquesField>
						<Tanque>
							<iDTanqueField>string</iDTanqueField>
							<capacidadField>100</capacidadField>
							<iDUnidadCapacidadField>UnidadKG</iDUnidadCapacidadField>
							<iDArticuloField>Articulo123</iDArticuloField>
							<matriculaField>Matricula123</matriculaField>
						</Tanque>
					</tanquesField>
					<impuestosBocaField>
						<ImpuestoBoca>
							<iDImpuestoField>ID123</iDImpuestoField>
							<fechaSujetoDesdeField>2020-01-01</fechaSujetoDesdeField>
							<fechaSujetoHastaField>2030-01-01</fechaSujetoHastaField>
							<fechaExentoHastaField>2022-08-01</fechaExentoHastaField>
							<baseCalculoField>10</baseCalculoField>
							<porcentajeImpuestoField>21</porcentajeImpuestoField>
							<importeMinimoField>100</importeMinimoField>
							<porcentajeExentoField>10</porcentajeExentoField>
							<iDUnidadImporteMinimoField>Unidad123</iDUnidadImporteMinimoField>
						</ImpuestoBoca>
					</impuestosBocaField>
					<cuentaCorrienteField>
						<CuentaCorriente>
							<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
							<ejercicioField>2022</ejercicioField>
							<posicionField>150</posicionField>
							<iDBocaField>Boca123 </iDBocaField>
							<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
							<serieField>Serie1</serieField>
							<letraField>LetraA</letraField>
							<numeroField>999</numeroField>
							<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
							<fechaVencimientoField>2022-09-01</fechaVencimientoField>
							<importeField>9879</importeField>
							<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
							<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
							<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
							<importeProntoPagoField>1500</importeProntoPagoField>
							<idMonedaImporteField>ARS</idMonedaImporteField>
						</CuentaCorriente>
					</cuentaCorrienteField>
					<preciosEspecialesField>
						<Precio>
							<iDArticuloField>Articulo123</iDArticuloField>
							<iDBocaField>Boca123</iDBocaField>
							<precio1Field>520</precio1Field>
							<iDUnidadPrecioNetoField>Kg</iDUnidadPrecioNetoField>
							<vigenciaDesdeField>2022-01-01</vigenciaDesdeField>
						</Precio>
					</preciosEspecialesField>
				</Boca>
			</bocasField>
			<logTransporteField>
				<LogTransporte>
					<iDPedidoField>Pedido123</iDPedidoField>
					<iDViajeField>Viaje123</iDViajeField>
					<operacionField>Entrega</operacionField>
				</LogTransporte>
			</logTransporteField>
		</novedadesPlanificacionField>
	</respuestaField>
</Apertura>";

		string clienteMock = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<Cliente>
	<titularField>
		<iDTitularField>IDTitular123</iDTitularField>
		<direccionField>direccion123</direccionField>
		<poblacionField>poblacion</poblacionField>
		<titular1Field>titular1</titular1Field>
		<codigoPostalField>CP1234</codigoPostalField>
		<iDFiscalField>iDFiscal123</iDFiscalField>
		<iDTipoFiscalField>Tipo123</iDTipoFiscalField>
		<iDCategoriaFiscalField>Categoria123</iDCategoriaFiscalField>
		<iDRegionField>Region123</iDRegionField>
		<iDTipoRegionField>TipoReg123</iDTipoRegionField>
	</titularField>
	<bocaField>
		<iDBocaField>Boca123</iDBocaField>
		<iDPlantaField>Planta123</iDPlantaField>
		<direccionField>Direccion123</direccionField>
		<poblacionField>poblacion</poblacionField>
		<telefonoField>011-1234-1234</telefonoField>
		<iDTitularField>Titular123</iDTitularField>
		<codigoPostalField>CP1234</codigoPostalField>
		<instruccionesDeAccesoField>Acceder por 123</instruccionesDeAccesoField>
		<iDZonaField>Zona123</iDZonaField>
		<usaSegundoVencimientoField>0</usaSegundoVencimientoField>
		<usaProntoPagoField>0</usaProntoPagoField>
		<iDProntoPagoField>NO</iDProntoPagoField>
		<estaEnZonaFrancaField>0</estaEnZonaFrancaField>
		<razonSocialField>RazonSocial</razonSocialField>
		<diasPlazoPagoField>60</diasPlazoPagoField>
		<usaDebitoAutomaticoField>0</usaDebitoAutomaticoField>
		<esFacturableField>1</esFacturableField>
		<iDRegionComercialField>RegionCom123</iDRegionComercialField>
		<iDTipoRegionComercialField>TipoRC123</iDTipoRegionComercialField>
		<estadoField>1</estadoField>
		<resolucionDGEField>REsDGEF</resolucionDGEField>
		<tanquesField>
			<Tanque>
				<iDTanqueField>string</iDTanqueField>
				<capacidadField>100</capacidadField>
				<iDUnidadCapacidadField>UnidadKG</iDUnidadCapacidadField>
				<iDArticuloField>Articulo123</iDArticuloField>
				<matriculaField>Matricula123</matriculaField>
			</Tanque>
		</tanquesField>
		<impuestosBocaField>
			<ImpuestoBoca>
				<iDImpuestoField>ID123</iDImpuestoField>
				<fechaSujetoDesdeField>2020-01-01</fechaSujetoDesdeField>
				<fechaSujetoHastaField>2030-01-01</fechaSujetoHastaField>
				<fechaExentoHastaField>2022-08-01</fechaExentoHastaField>
				<baseCalculoField>10</baseCalculoField>
				<porcentajeImpuestoField>21</porcentajeImpuestoField>
				<importeMinimoField>100</importeMinimoField>
				<porcentajeExentoField>10</porcentajeExentoField>
				<iDUnidadImporteMinimoField>Unidad123</iDUnidadImporteMinimoField>
			</ImpuestoBoca>
		</impuestosBocaField>
		<cuentaCorrienteField>
			<CuentaCorriente>
				<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
				<ejercicioField>2022</ejercicioField>
				<posicionField>150</posicionField>
				<iDBocaField>Boca123 </iDBocaField>
				<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
				<serieField>Serie1</serieField>
				<letraField>LetraA</letraField>
				<numeroField>999</numeroField>
				<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
				<fechaVencimientoField>2022-09-01</fechaVencimientoField>
				<importeField>9879</importeField>
				<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
				<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
				<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
				<importeProntoPagoField>1500</importeProntoPagoField>
				<idMonedaImporteField>ARS</idMonedaImporteField>
			</CuentaCorriente>
		</cuentaCorrienteField>
		<preciosEspecialesField>
			<Precio>
				<iDArticuloField>Articulo123</iDArticuloField>
				<iDBocaField>Boca123</iDBocaField>
				<precio1Field>520</precio1Field>
				<iDUnidadPrecioNetoField>Kg</iDUnidadPrecioNetoField>
				<vigenciaDesdeField>2022-01-01</vigenciaDesdeField>
			</Precio>
		</preciosEspecialesField>
	</bocaField>
	<respuestaField>
		<codigoField>1234</codigoField>
		<descripcionField>Descrpicion</descripcionField>
		<novedadesPlanificacionField>
			<pedidosField>
				<Pedido>
					<iDPedidoField>ID123</iDPedidoField>
					<iDBocaField>IDBoca123</iDBocaField>
					<iDPlantaField>IDPlanta</iDPlantaField>
					<fechaEntregaPreferenteField>2022-09-01</fechaEntregaPreferenteField>
					<horaDesdeField>10:30</horaDesdeField>
					<horaHastaField>14:00</horaHastaField>
					<observacionesField>Observacion</observacionesField>
					<importeCobroAnticipadoField>9999</importeCobroAnticipadoField>
					<tipoDeCargaField>CargaA</tipoDeCargaField>
					<iDTipoPedidoField>PedidoTipo1</iDTipoPedidoField>
					<esFacturableField>1</esFacturableField>
					<condicionDePagoField>Contado</condicionDePagoField>
					<codigoExpressField>NO</codigoExpressField>
					<esPlanificadoField>1</esPlanificadoField>
					<detallePedidosField>
						<DetallePedido>
							<cantidadField>5</cantidadField>
							<iDArticuloField>ART001</iDArticuloField>
							<importeField>99999</importeField>
						</DetallePedido>
					</detallePedidosField>
				</Pedido>
			</pedidosField>
			<titularesField>
				<Titular>
					<iDTitularField>IDTitular123</iDTitularField>
					<direccionField>direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<titular1Field>titular1</titular1Field>
					<codigoPostalField>CP1234</codigoPostalField>
					<iDFiscalField>iDFiscal123</iDFiscalField>
					<iDTipoFiscalField>Tipo123</iDTipoFiscalField>
					<iDCategoriaFiscalField>Categoria123</iDCategoriaFiscalField>
					<iDRegionField>Region123</iDRegionField>
					<iDTipoRegionField>TipoReg123</iDTipoRegionField>
				</Titular>
			</titularesField>
			<bocasField>
				<Boca>
					<iDBocaField>Boca123</iDBocaField>
					<iDPlantaField>Planta123</iDPlantaField>
					<direccionField>Direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<telefonoField>011-1234-1234</telefonoField>
					<iDTitularField>Titular123</iDTitularField>
					<codigoPostalField>CP1234</codigoPostalField>
					<instruccionesDeAccesoField>Acceder por 123</instruccionesDeAccesoField>
					<iDZonaField>Zona123</iDZonaField>
					<usaSegundoVencimientoField>0</usaSegundoVencimientoField>
					<usaProntoPagoField>0</usaProntoPagoField>
					<iDProntoPagoField>NO</iDProntoPagoField>
					<estaEnZonaFrancaField>0</estaEnZonaFrancaField>
					<razonSocialField>RazonSocial</razonSocialField>
					<diasPlazoPagoField>60</diasPlazoPagoField>
					<usaDebitoAutomaticoField>0</usaDebitoAutomaticoField>
					<esFacturableField>1</esFacturableField>
					<iDRegionComercialField>RegionCom123</iDRegionComercialField>
					<iDTipoRegionComercialField>TipoRC123</iDTipoRegionComercialField>
					<estadoField>1</estadoField>
					<resolucionDGEField>REsDGEF</resolucionDGEField>
					<tanquesField>
						<Tanque>
							<iDTanqueField>string</iDTanqueField>
							<capacidadField>100</capacidadField>
							<iDUnidadCapacidadField>UnidadKG</iDUnidadCapacidadField>
							<iDArticuloField>Articulo123</iDArticuloField>
							<matriculaField>Matricula123</matriculaField>
						</Tanque>
					</tanquesField>
					<impuestosBocaField>
						<ImpuestoBoca>
							<iDImpuestoField>ID123</iDImpuestoField>
							<fechaSujetoDesdeField>2020-01-01</fechaSujetoDesdeField>
							<fechaSujetoHastaField>2030-01-01</fechaSujetoHastaField>
							<fechaExentoHastaField>2022-08-01</fechaExentoHastaField>
							<baseCalculoField>10</baseCalculoField>
							<porcentajeImpuestoField>21</porcentajeImpuestoField>
							<importeMinimoField>100</importeMinimoField>
							<porcentajeExentoField>10</porcentajeExentoField>
							<iDUnidadImporteMinimoField>Unidad123</iDUnidadImporteMinimoField>
						</ImpuestoBoca>
					</impuestosBocaField>
					<cuentaCorrienteField>
						<CuentaCorriente>
							<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
							<ejercicioField>2022</ejercicioField>
							<posicionField>150</posicionField>
							<iDBocaField>Boca123 </iDBocaField>
							<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
							<serieField>Serie1</serieField>
							<letraField>LetraA</letraField>
							<numeroField>999</numeroField>
							<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
							<fechaVencimientoField>2022-09-01</fechaVencimientoField>
							<importeField>9879</importeField>
							<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
							<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
							<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
							<importeProntoPagoField>1500</importeProntoPagoField>
							<idMonedaImporteField>ARS</idMonedaImporteField>
						</CuentaCorriente>
					</cuentaCorrienteField>
					<preciosEspecialesField>
						<Precio>
							<iDArticuloField>Articulo123</iDArticuloField>
							<iDBocaField>Boca123</iDBocaField>
							<precio1Field>520</precio1Field>
							<iDUnidadPrecioNetoField>Kg</iDUnidadPrecioNetoField>
							<vigenciaDesdeField>2022-01-01</vigenciaDesdeField>
						</Precio>
					</preciosEspecialesField>
				</Boca>
			</bocasField>
			<logTransporteField>
				<LogTransporte>
					<iDPedidoField>Pedido123</iDPedidoField>
					<iDViajeField>Viaje123</iDViajeField>
					<operacionField>Entrega</operacionField>
				</LogTransporte>
			</logTransporteField>
		</novedadesPlanificacionField>
	</respuestaField>
</Cliente>";

		string pesadaMock = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<Pesada>
	<iDPatenteField>ABC123</iDPatenteField>
	<pesadaFinalField>1000</pesadaFinalField>
	<respuestaField>
		<codigoField>1234</codigoField>
		<descripcionField>Descrpicion</descripcionField>
		<novedadesPlanificacionField>
			<pedidosField>
				<Pedido>
					<iDPedidoField>ID123</iDPedidoField>
					<iDBocaField>IDBoca123</iDBocaField>
					<iDPlantaField>IDPlanta</iDPlantaField>
					<fechaEntregaPreferenteField>2022-09-01</fechaEntregaPreferenteField>
					<horaDesdeField>10:30</horaDesdeField>
					<horaHastaField>14:00</horaHastaField>
					<observacionesField>Observacion</observacionesField>
					<importeCobroAnticipadoField>9999</importeCobroAnticipadoField>
					<tipoDeCargaField>CargaA</tipoDeCargaField>
					<iDTipoPedidoField>PedidoTipo1</iDTipoPedidoField>
					<esFacturableField>1</esFacturableField>
					<condicionDePagoField>Contado</condicionDePagoField>
					<codigoExpressField>NO</codigoExpressField>
					<esPlanificadoField>1</esPlanificadoField>
					<detallePedidosField>
						<DetallePedido>
							<cantidadField>5</cantidadField>
							<iDArticuloField>ART001</iDArticuloField>
							<importeField>99999</importeField>
						</DetallePedido>
					</detallePedidosField>
				</Pedido>
			</pedidosField>
			<titularesField>
				<Titular>
					<iDTitularField>IDTitular123</iDTitularField>
					<direccionField>direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<titular1Field>titular1</titular1Field>
					<codigoPostalField>CP1234</codigoPostalField>
					<iDFiscalField>iDFiscal123</iDFiscalField>
					<iDTipoFiscalField>Tipo123</iDTipoFiscalField>
					<iDCategoriaFiscalField>Categoria123</iDCategoriaFiscalField>
					<iDRegionField>Region123</iDRegionField>
					<iDTipoRegionField>TipoReg123</iDTipoRegionField>
				</Titular>
			</titularesField>
			<bocasField>
				<Boca>
					<iDBocaField>Boca123</iDBocaField>
					<iDPlantaField>Planta123</iDPlantaField>
					<direccionField>Direccion123</direccionField>
					<poblacionField>poblacion</poblacionField>
					<telefonoField>011-1234-1234</telefonoField>
					<iDTitularField>Titular123</iDTitularField>
					<codigoPostalField>CP1234</codigoPostalField>
					<instruccionesDeAccesoField>Acceder por 123</instruccionesDeAccesoField>
					<iDZonaField>Zona123</iDZonaField>
					<usaSegundoVencimientoField>0</usaSegundoVencimientoField>
					<usaProntoPagoField>0</usaProntoPagoField>
					<iDProntoPagoField>NO</iDProntoPagoField>
					<estaEnZonaFrancaField>0</estaEnZonaFrancaField>
					<razonSocialField>RazonSocial</razonSocialField>
					<diasPlazoPagoField>60</diasPlazoPagoField>
					<usaDebitoAutomaticoField>0</usaDebitoAutomaticoField>
					<esFacturableField>1</esFacturableField>
					<iDRegionComercialField>RegionCom123</iDRegionComercialField>
					<iDTipoRegionComercialField>TipoRC123</iDTipoRegionComercialField>
					<estadoField>1</estadoField>
					<resolucionDGEField>REsDGEF</resolucionDGEField>
					<tanquesField>
						<Tanque>
							<iDTanqueField>string</iDTanqueField>
							<capacidadField>100</capacidadField>
							<iDUnidadCapacidadField>UnidadKG</iDUnidadCapacidadField>
							<iDArticuloField>Articulo123</iDArticuloField>
							<matriculaField>Matricula123</matriculaField>
						</Tanque>
					</tanquesField>
					<impuestosBocaField>
						<ImpuestoBoca>
							<iDImpuestoField>ID123</iDImpuestoField>
							<fechaSujetoDesdeField>2020-01-01</fechaSujetoDesdeField>
							<fechaSujetoHastaField>2030-01-01</fechaSujetoHastaField>
							<fechaExentoHastaField>2022-08-01</fechaExentoHastaField>
							<baseCalculoField>10</baseCalculoField>
							<porcentajeImpuestoField>21</porcentajeImpuestoField>
							<importeMinimoField>100</importeMinimoField>
							<porcentajeExentoField>10</porcentajeExentoField>
							<iDUnidadImporteMinimoField>Unidad123</iDUnidadImporteMinimoField>
						</ImpuestoBoca>
					</impuestosBocaField>
					<cuentaCorrienteField>
						<CuentaCorriente>
							<nroDocumentoSAPField>SAPDocNo123</nroDocumentoSAPField>
							<ejercicioField>2022</ejercicioField>
							<posicionField>150</posicionField>
							<iDBocaField>Boca123 </iDBocaField>
							<claseDocumentoSAPField>SAP Factura</claseDocumentoSAPField>
							<serieField>Serie1</serieField>
							<letraField>LetraA</letraField>
							<numeroField>999</numeroField>
							<tieneAplicacionParcialField>0</tieneAplicacionParcialField>
							<fechaVencimientoField>2022-09-01</fechaVencimientoField>
							<importeField>9879</importeField>
							<fechaSegundoVencimientoField>2022-09-15</fechaSegundoVencimientoField>
							<importeSegundoVencimientoField>1234</importeSegundoVencimientoField>
							<fechaProntoPagoField>2022-08-15</fechaProntoPagoField>
							<importeProntoPagoField>1500</importeProntoPagoField>
							<idMonedaImporteField>ARS</idMonedaImporteField>
						</CuentaCorriente>
					</cuentaCorrienteField>
					<preciosEspecialesField>
						<Precio>
							<iDArticuloField>Articulo123</iDArticuloField>
							<iDBocaField>Boca123</iDBocaField>
							<precio1Field>520</precio1Field>
							<iDUnidadPrecioNetoField>Kg</iDUnidadPrecioNetoField>
							<vigenciaDesdeField>2022-01-01</vigenciaDesdeField>
						</Precio>
					</preciosEspecialesField>
				</Boca>
			</bocasField>
			<logTransporteField>
				<LogTransporte>
					<iDPedidoField>Pedido123</iDPedidoField>
					<iDViajeField>Viaje123</iDViajeField>
					<operacionField>Entrega</operacionField>
				</LogTransporte>
			</logTransporteField>
		</novedadesPlanificacionField>
	</respuestaField>
</Pesada>";
		#endregion


        //los que retornan Respuesta
        #region ReturnRespuesta
  //      public async Task<Respuesta> AnulaDocumento(Anulacion oAnulacion)
		//{

		//	string datoXml = RespuestaMock;

  //          XmlReaderSettings settings = new XmlReaderSettings
  //          {
  //              Async = true
  //          };
  //          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
  //          await xmlReader.ReadAsync();

  //          var mySerializer = new XmlSerializer(typeof(Respuesta));
		//	var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

		//	if (myObject == null)
		//	{
		//		throw new Exception("Error");
		//	}

		//	return myObject;
		//}

  //      public async Task<Respuesta> RecibeApertura(InicioViaje oInicioViaje)
  //      {
  //          string datoXml = RespuestaMock;

  //          XmlReaderSettings settings = new XmlReaderSettings
  //          {
  //              Async = true
  //          };
  //          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
  //          await xmlReader.ReadAsync();
  //          var mySerializer = new XmlSerializer(typeof(Respuesta));
  //          var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

  //          if (myObject == null)
  //          {
  //              throw new Exception("Error");
  //          }

  //          return myObject;
  //      }

  //      public async Task<Respuesta> RecibeRNA(RazonDeNoAbastecido oRazonDeNoAbastecido)
  //      {
  //          string datoXml = RespuestaMock;

  //          XmlReaderSettings settings = new XmlReaderSettings
  //          {
  //              Async = true
  //          };
  //          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
  //          await xmlReader.ReadAsync();

  //          var mySerializer = new XmlSerializer(typeof(Respuesta));
  //          var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

  //          if (myObject == null)
  //          {
  //              throw new Exception("Error");
  //          }

  //          return myObject;
  //      }

        public async Task<Respuesta> RecibeEntrega(Entrega oEntregaHH)
        {
            string datoXml = RespuestaMockSimple;

            XmlReaderSettings settings = new XmlReaderSettings
			{
				Async = true
			};
			XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
			await xmlReader.ReadAsync();

			Respuesta res = new Respuesta();
			res.Codigo = 1;
			res.Descripcion = "OK - Success";
			return res;

            //string datoXml = RespuestaMockSimple;

            //XmlReaderSettings settings = new XmlReaderSettings
            //{
            //    Async = true
            //};
            //XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
            //await xmlReader.ReadAsync();
            //var mySerializer = new XmlSerializer(typeof(Respuesta));
            //var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

            //if (myObject == null)
            //{
            //    throw new Exception("Error");
            //}

            //return myObject;
        }

              public async Task<Respuesta> RecibeCierreDeViaje(CierreViaje oCierreViajeHH)
        {
            string datoXml = RespuestaMock;

            XmlReaderSettings settings = new XmlReaderSettings
            {
                Async = true
            };
            XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
            await xmlReader.ReadAsync();
            //var mySerializer = new XmlSerializer(typeof(Respuesta));
            //var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

            //if (myObject == null)
            //{
            //    throw new Exception("Error");
            //}

            //return myObject;

            Respuesta res = new Respuesta();
            res.Codigo = 1;
            res.Descripcion = "OK - Success";
            return res;
        }

        public async Task<Respuesta> SolicitaNovedadTransporte(long IDViaje)
        {
            string datoXml = RespuestaMock;

            XmlReaderSettings settings = new XmlReaderSettings
            {
                Async = true
            };
            XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
            await xmlReader.ReadAsync();
            //var mySerializer = new XmlSerializer(typeof(Respuesta));
            //var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

            //if (myObject == null)
            //{
            //    throw new Exception("Error");
            //}

            //return myObject;

            Respuesta res = new Respuesta();
            res.Codigo = 1;
            res.Descripcion = "OK - Success";
            return res;

        }

		//      public async Task<Respuesta> RecibeCobranza(Recibo oReciboHH)
		//      {
		//          string datoXml = RespuestaMock;

		//          XmlReaderSettings settings = new XmlReaderSettings
		//          {
		//              Async = true
		//          };
		//          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
		//          await xmlReader.ReadAsync();
		//          var mySerializer = new XmlSerializer(typeof(Respuesta));
		//          var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

		//          if (myObject == null)
		//          {
		//              throw new Exception("Error");
		//          }

		//          return myObject;
		//      }

		//      public async Task<Respuesta> RecibeIncidencia(Incidencia oInicidenciaHH)
		//      {
		//          string datoXml = RespuestaMock;

		//          XmlReaderSettings settings = new XmlReaderSettings
		//          {
		//              Async = true
		//          };
		//          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
		//          await xmlReader.ReadAsync();
		//          var mySerializer = new XmlSerializer(typeof(Respuesta));
		//          var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

		//          if (myObject == null)
		//          {
		//              throw new Exception("Error");
		//          }

		//          return myObject;
		//      }

		//      public async Task<Respuesta> RecibeFactura(Factura oFacturaHH)
		//      {
		//          string datoXml = RespuestaMock;

		//          XmlReaderSettings settings = new XmlReaderSettings
		//          {
		//              Async = true
		//          };
		//          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
		//          await xmlReader.ReadAsync();
		//          var mySerializer = new XmlSerializer(typeof(Respuesta));
		//          var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

		//          if (myObject == null)
		//          {
		//              throw new Exception("Error");
		//          }

		//          return myObject;
		//      }


		//      public async Task<Respuesta> RecibeMovimientoStock(MovimientoStock oMovimientoStockHH)
		//      {
		//          string datoXml = RespuestaMock;

		//          XmlReaderSettings settings = new XmlReaderSettings
		//          {
		//              Async = true
		//          };
		//          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
		//          await xmlReader.ReadAsync();
		//          var mySerializer = new XmlSerializer(typeof(Respuesta));
		//          var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

		//          if (myObject == null)
		//          {
		//              throw new Exception("Error");
		//          }

		//          return myObject;
		//      }

		//      public async Task<Respuesta> RecibePedido(Pedido oPedidoHH)
		//      {
		//          string datoXml = RespuestaMock;

		//          XmlReaderSettings settings = new XmlReaderSettings
		//          {
		//              Async = true
		//          };
		//          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
		//          await xmlReader.ReadAsync();
		//          var mySerializer = new XmlSerializer(typeof(Respuesta));
		//          var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

		//          if (myObject == null)
		//          {
		//              throw new Exception("Error");
		//          }

		//          return myObject;
		//      }

		//      public async Task<Respuesta> VerificaComunicacion()
		//      {
		//          string datoXml = RespuestaMock;

		//          XmlReaderSettings settings = new XmlReaderSettings
		//          {
		//              Async = true
		//          };
		//          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
		//          await xmlReader.ReadAsync();
		//          var mySerializer = new XmlSerializer(typeof(Respuesta));
		//          var myObject = mySerializer.Deserialize(xmlReader) as Respuesta;

		//          if (myObject == null)
		//          {
		//              throw new Exception("Error");
		//          }

		//          return myObject;
		//      }



		#endregion

		//      public async Task<FechaActual> FechaServidor()
		//      {
		//          string datoXml = fechaActualMock;

		//          XmlReaderSettings settings = new XmlReaderSettings
		//          {
		//              Async = true
		//          };
		//          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
		//          await xmlReader.ReadAsync();
		//          var mySerializer = new XmlSerializer(typeof(FechaActual));
		//          var myObject = mySerializer.Deserialize(xmlReader) as FechaActual;

		//          if (myObject == null)
		//          {
		//              throw new Exception("Error");
		//          }

		//          return myObject;
		//      }

		public async Task<PedidoLista> BuscaPedidoPorID(string? IDTransporte, string? IDPedido)
		{
			string datoXml = pedidoListaMock;

			XmlReaderSettings settings = new XmlReaderSettings
			{
				Async = true
			};
			XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
			await xmlReader.ReadAsync();
			var mySerializer = new XmlSerializer(typeof(PedidoLista));
			var myObject = mySerializer.Deserialize(xmlReader) as PedidoLista;

			if (myObject == null)
			{
				throw new Exception("Error");
			}

			PedidoLista pedLista = new PedidoLista();

			pedLista.Pedidos = new Pedido[1];
			pedLista.Pedidos[0] = new Pedido {
				IDPedido = "80000",
				IDBoca = "200000",
				IDPlanta = "1111",
				FechaEntregaPreferente = DateTime.Now,
				HoraDesde = "10:00",
				HoraHasta = "13:00",
				Observaciones = "sin observaciones",
				ImporteCobroAnticipado = 10000,
				TipoDeCarga = "Gas",
				IDTipoPedido = "2",
				EsFacturable = 1,
				CondicionDePago = "CONTADO",
				CodigoExpress = "123",
				EsPlanificado = 1 };
			pedLista.Pedidos[0].DetallePedidos = new DetallePedido[2];
			pedLista.Pedidos[0].DetallePedidos[0] = new DetallePedido {
				Cantidad = 100,
				IDArticulo = "111",
				Importe = 100000};
            pedLista.Pedidos[0].DetallePedidos[1] = new DetallePedido
            {
                Cantidad = 50,
                IDArticulo = "120",
                Importe = 50000
            };
            pedLista.Respuesta = new Respuesta { Codigo = '1', Descripcion = "OK - Success" };

			return pedLista;
            //return myObject;
        }

        //      public async Task<PedidoLista> BuscaPedidoPorBoca(string? IDTransporte, string? IDBoca)
        //      {
        //          string datoXml = pedidoListaMock;

        //          XmlReaderSettings settings = new XmlReaderSettings
        //          {
        //              Async = true
        //          };
        //          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
        //          await xmlReader.ReadAsync();
        //          var mySerializer = new XmlSerializer(typeof(PedidoLista));
        //          var myObject = mySerializer.Deserialize(xmlReader) as PedidoLista;

        //          if (myObject == null)
        //          {
        //              throw new Exception("Error");
        //          }

        //          return myObject;
        //      }

        //      public async Task<ViajeLista> BuscaTransporte(string? IDPlanta, string? IDPatente, string? IDChofer, string? IDTipoViaje)
        //{

        //              string datoXml = viajeListaMock;

        //          XmlReaderSettings settings = new XmlReaderSettings
        //          {
        //              Async = true
        //          };
        //          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
        //          await xmlReader.ReadAsync();
        //          var mySerializer = new XmlSerializer(typeof(ViajeLista));
        //              var myObject = mySerializer.Deserialize(xmlReader) as ViajeLista;

        //              if (myObject == null)
        //              {
        //                  throw new Exception("Error");
        //              }

        //              return myObject;
        //       }

        //public async Task<ViajeSeleccionado> BuscaTransporteSeleccionado(string? IDViaje, string? IDPlanta, string? IDPatente, string? IDChofer)
        //      {

        //          string datoXml = viajeSeleccionadoMock;

        //          XmlReaderSettings settings = new XmlReaderSettings
        //          {
        //              Async = true
        //          };
        //          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
        //          await xmlReader.ReadAsync();
        //          var mySerializer = new XmlSerializer(typeof(ViajeSeleccionado));
        //          var myObject = mySerializer.Deserialize(xmlReader) as ViajeSeleccionado;

        //          if (myObject == null)
        //          {
        //              throw new Exception("Error");
        //          }

        //          return myObject;
        //      }

        //public async Task<Apertura> ConfirmaAperturaDeViaje(string? IDViaje, string? IDPlanta, string? IDPatente, string? IDChofer)
        //      {

        //          string datoXml = aperturaMock;

        //          XmlReaderSettings settings = new XmlReaderSettings
        //          {
        //              Async = true
        //          };
        //          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
        //          await xmlReader.ReadAsync();
        //          var mySerializer = new XmlSerializer(typeof(Apertura));
        //          var myObject = mySerializer.Deserialize(xmlReader) as Apertura;

        //          if (myObject == null)
        //          {
        //              throw new Exception("Error");
        //          }

        //          return myObject;
        //      }

        //      public async Task<Cliente> BuscaCliente(string? IDBoca)
        //      {

        //          string datoXml = clienteMock;

        //          XmlReaderSettings settings = new XmlReaderSettings
        //          {
        //              Async = true
        //          };
        //          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
        //          await xmlReader.ReadAsync();
        //          var mySerializer = new XmlSerializer(typeof(Cliente));
        //          var myObject = mySerializer.Deserialize(xmlReader) as Cliente;

        //          if (myObject == null)
        //          {
        //              throw new Exception("Error");
        //          }

        //          return myObject;
        //      }

        //      public async Task<Pesada> ObtenerPesadaFinal(string? IDPatente)
        //      {

        //          string datoXml = pesadaMock;

        //          XmlReaderSettings settings = new XmlReaderSettings
        //          {
        //              Async = true
        //          };
        //          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
        //          await xmlReader.ReadAsync();
        //          var mySerializer = new XmlSerializer(typeof(Pesada));
        //          var myObject = mySerializer.Deserialize(xmlReader) as Pesada;

        //          if (myObject == null)
        //          {
        //              throw new Exception("Error");
        //          }

        //          return myObject;
        //      }

        //public async Task<byte[]> ConfirmaAperturaDeViajeComprimida(string? IDViaje, string? IDPlanta, string? IDPatente, string? IDChofer)
        //{

        //          string datoXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>
        //	<numbers type=""array"">
        //		<value>0</value>
        //		<value>1</value>
        //		<value>1</value>
        //	</numbers>";

        //          XmlReaderSettings settings = new XmlReaderSettings
        //          {
        //              Async = true
        //          };
        //          XmlReader xmlReader = XmlReader.Create(new StringReader(datoXml), settings);
        //          await xmlReader.ReadAsync();
        //          //var mySerializer = new XmlSerializer(typeof(byte[]));
        //          //var myObject = mySerializer.Deserialize(xmlReader) as byte[];

        //          //if (myObject == null)
        //          //{
        //          //    throw new Exception("Error");
        //          //}

        //          //return myObject;

        //          byte[] ret = new byte[3] { 0, 1, 1 };

        //          return ret;
        //      }



	}
}
