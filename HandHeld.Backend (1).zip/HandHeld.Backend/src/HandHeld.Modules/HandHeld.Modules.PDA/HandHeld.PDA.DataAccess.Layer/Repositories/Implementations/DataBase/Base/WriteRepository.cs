﻿using HandHeld.PDA.DataAccess.Layer.Models;
using HandHeld.PDA.DataAccess.Layer.Repositories.Interfaces.DataBase.Base;
using Microsoft.EntityFrameworkCore;

namespace HandHeld.PDA.DataAccess.Layer.Repositories.Implementations.DataBase.Base
{
    public class WriteRepository<T> : ReadRepository<T>, IWriteRepository<T> where T: Auditoria
    {
        private readonly DbSet<T> _dbSet;
        public WriteRepository(PDADbContext context): base(context)
        {
            _dbSet = _context.Set<T>();
        }

        public virtual void Insert(T entity)
        {
            _dbSet.Add(entity);
        }
        public virtual void Update(T entity)
        {
            _dbSet.Update(entity);
        }
        public virtual void Delete(object id)
        {
            _dbSet.Remove(Get(id));
        }

        public virtual Task DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }
        public virtual Task InsertAsync(T entity)
        {
            throw new NotImplementedException();
        }


        public virtual Task UpdateAsync(T entity)
        {
            throw new NotImplementedException();
        }
    }
}
