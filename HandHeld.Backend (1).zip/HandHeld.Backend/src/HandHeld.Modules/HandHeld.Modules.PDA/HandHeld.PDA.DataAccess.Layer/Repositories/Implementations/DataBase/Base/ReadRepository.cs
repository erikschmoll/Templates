﻿using HandHeld.PDA.DataAccess.Layer.Models;
using HandHeld.PDA.DataAccess.Layer.Repositories.Interfaces.DataBase.Base;
using Microsoft.EntityFrameworkCore;

namespace HandHeld.PDA.DataAccess.Layer.Repositories.Implementations.DataBase.Base
{
    public abstract class ReadRepository<T> : IReadRepository<T> where T : Auditoria
    {
        protected readonly PDADbContext _context;
        private readonly DbSet<T> _dbSet;
        public ReadRepository(PDADbContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }
        public virtual T Get(object id)
        {
            return _dbSet.Where(t => t.Id.Equals(id)).Single();
        }

        public virtual IEnumerable<T> GetAll()
        {
            return _dbSet.ToList();
        }

        public virtual Task<IEnumerable<T>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public virtual Task<T> GetAsync(int id)
        {
            throw new NotImplementedException();
        }
    }
}
