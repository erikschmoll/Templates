﻿using RecibeComunicacionTesting;
using HandHeld.PDA.DataAccess.Layer.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HandHeld.PDA.DataAccess.Layer.Repositories.Implementations.WebServices
{
    public class RecibeComunicacionTestingService: IRecibeComunicacionService
    {

        private RecibeComunicacionSoapClient recibeComClient;
        public RecibeComunicacionTestingService()
        {
            recibeComClient = new RecibeComunicacionSoapClient(RecibeComunicacionSoapClient.EndpointConfiguration.RecibeComunicacionSoap12);
        }

        public async Task<Respuesta> RecibeEntrega(Entrega oEntregaHH)
        {
            Respuesta ret = await recibeComClient.RecibeEntregaAsync(oEntregaHH);
            return ret;
        }

        public async Task<Respuesta> SolicitaNovedadTransporte(long IDViaje)
        {
            Respuesta ret = await recibeComClient.SolicitaNovedadTransporteAsync(IDViaje);
            return ret;
        }
        
        public async Task<Respuesta> RecibeCierreDeViaje(CierreViaje oCierreViajeHH)
        {
            Respuesta ret = await recibeComClient.RecibeCierreDeViajeAsync(oCierreViajeHH);
            return ret;
        }

        public async Task<PedidoLista> BuscaPedidoPorID(string? IDTransporte, string? IDPedido)
        {
            PedidoLista ret = await recibeComClient.BuscaPedidoPorIDAsync(IDTransporte, IDPedido);
            return ret;
        }

    }
}
