﻿using RecibeComunicacionTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandHeld.PDA.DataAccess.Layer.Repositories.Interfaces
{
    public interface IRecibeComunicacionService
    {
        //Task<PruebaClaseItem> PruebaSimple();
        //PruebaClaseCabezaSimple PruebaConItem();
        //PruebaClaseCabezaLista PruebaConItemLista();


        //Task<Respuesta> AnulaDocumento(Anulacion oAnulacion);
        //Task<Respuesta> RecibeApertura(InicioViaje oInicioViaje);
        //Task<Respuesta> RecibeRNA(RazonDeNoAbastecido oRazonDeNoAbastecido);
        Task<Respuesta> RecibeEntrega(Entrega oEntregaHH);
        //Task<Respuesta> RecibeCobranza(Recibo oReciboHH);
        //Task<Respuesta> RecibeIncidencia(Incidencia oInicidenciaHH);
        //Task<Respuesta> RecibeFactura(Factura oFacturaHH);
        //Task<Respuesta> RecibePedido(Pedido oPedidoHH);
        Task<Respuesta> SolicitaNovedadTransporte(long IDViaje);
        //Task<Respuesta> RecibeMovimientoStock(MovimientoStock oMovimientoStockHH);
        //Task<Respuesta> VerificaComunicacion();
        //Task<FechaActual> FechaServidor();
        Task<PedidoLista> BuscaPedidoPorID(string? IDTransporte, string? IDPedido);
        //Task<PedidoLista> BuscaPedidoPorBoca(string? IDTransporte, string? IDBoca);
        //Task<ViajeLista> BuscaTransporte(string? IDPlanta, string? IDPatente, string? IDChofer, string? IDTipoViaje);
        //Task<ViajeSeleccionado> BuscaTransporteSeleccionado(string? IDViaje, string? IDPlanta, string? IDPatente, string? IDChofer);
        //Task<Apertura> ConfirmaAperturaDeViaje(string? IDViaje, string? IDPlanta, string? IDPatente, string? IDChofer);
        //Task<Cliente> BuscaCliente(string? IDBoca);
        //Task<Pesada> ObtenerPesadaFinal(string? IDPatente);
        //Task<byte[]> ConfirmaAperturaDeViajeComprimida(string? IDViaje, string? IDPlanta, string? IDPatente, string? IDChofer);

        Task<Respuesta> RecibeCierreDeViaje(CierreViaje oCierreViajeHH);

    }

}
