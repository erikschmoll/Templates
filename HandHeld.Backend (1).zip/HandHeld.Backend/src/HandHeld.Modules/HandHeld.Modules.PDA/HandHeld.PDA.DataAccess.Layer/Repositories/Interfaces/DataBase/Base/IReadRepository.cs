﻿using HandHeld.PDA.DataAccess.Layer.Models;

namespace HandHeld.PDA.DataAccess.Layer.Repositories.Interfaces.DataBase.Base
{
    public interface IReadRepository<T> where T : Auditoria
    {
        T Get(object id);//return la query? cuando decidir traer o no las referencias?
        IEnumerable<T> GetAll();
        #region Async
        Task<T> GetAsync(int id);
        Task<IEnumerable<T>> GetAllAsync();
        #endregion
    }
}
