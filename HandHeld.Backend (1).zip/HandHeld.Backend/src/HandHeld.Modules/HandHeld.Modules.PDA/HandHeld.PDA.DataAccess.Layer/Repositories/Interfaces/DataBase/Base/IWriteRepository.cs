﻿using HandHeld.PDA.DataAccess.Layer.Models;

namespace HandHeld.PDA.DataAccess.Layer.Repositories.Interfaces.DataBase.Base
{
    public interface IWriteRepository<T> where T : Auditoria
    {
        void Insert(T entity);
        void Update(T entity);
        void Delete(object id);
        #region Async
        Task InsertAsync(T entity);
        Task UpdateAsync(T entity);
        Task DeleteAsync(int id);
        #endregion
    }
}
