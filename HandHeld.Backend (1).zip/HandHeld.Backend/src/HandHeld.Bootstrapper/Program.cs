using HandHeld.Bootstrapper;
using HandHeld.PDA.Presentation.Layer;
using HandHeld.PDAManagement.Presentation.Layer;
using HandHeld.Shared.Infrastructure;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

var configBuilder = Extension.ConfigurationBuilder();
builder.WebHost.UseConfiguration(configBuilder);

//Serilog
Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(configBuilder).CreateLogger();
builder.Host.UseSerilog();


builder.Services.AddSingleton(_ => builder.Configuration);
#region AddModule
builder.Services.AddInfrastructureModule(builder.Configuration);
builder.Services.AddPDAModule(builder.Configuration);
builder.Services.AddPDAManagementModule(builder.Configuration);
#endregion

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();
var origin = builder.Configuration.GetSection("Origins").Get<string[]>();
app.UseCors(x => x.WithOrigins(origin).AllowAnyMethod().AllowAnyHeader());

//app.UsePathBase("/api"); https://github.com/dotnet/aspnetcore/issues/38448

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();

#region UseModule
app.UseInfrastructureModule();
app.UsePDAModule();
app.UsePDAManagementModule(builder.Configuration);
#endregion

app.MapControllers();
app.MapGet("/", () => "Api Hand Held, Modular Monolith, Asp Net 6.0");

app.Run();
