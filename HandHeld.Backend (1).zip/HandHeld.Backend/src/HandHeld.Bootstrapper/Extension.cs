﻿using HandHeld.Shared.Infrastructure;

namespace HandHeld.Bootstrapper
{
    internal static class Extension
    {
        public static IConfiguration ConfigurationBuilder()
        {
            return new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("Environment\\appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"Environment\\appsettings.{InfrastructureModule.GetEnvironment() ?? "Production"}.json", optional: true)
                .AddEnvironmentVariables()
                .Build();
        }
    }
}
